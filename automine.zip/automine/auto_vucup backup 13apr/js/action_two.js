; /* Start:"a:4:{s:4:"full";s:108:"/local/templates/landing/components/zv/iblock.element.add.form.ajaxfile/calculation/script.js?14895007375601";s:6:"source";s:93:"/local/templates/landing/components/zv/iblock.element.add.form.ajaxfile/calculation/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
// import $ from 'jquery';
// import qq from 'fine-uploader/dist/fine-uploader.core';
// import 'fine-uploader/dist/fine-uploader.css';

class CarValuationComponent extends Component {
    constructor(scope, settings) {
        super(scope, settings);
        var $form = $('form', this.scope);
        var fineUploaderPath = this.settings.templatePath + '/bower_components/fine-uploader/dist';
        var $submitLink = $('.submit', $form);
        var $hiddenSubmit;
        var optionsCache = {};
        var $filesInputData = {};

        const numberFormatter = Application.getInstance().Formatter;
        $('[data-number-formatted]', this.scope).each((i, element) => {
            this[element.name] = element.value;
            $(element).on('keyup change', (e) => {
                let v = e.target.value;
                v = v.replace(/[^\d]/g, '');
                v = parseInt(v);
                v = isNaN(v) ? 0 : v;
                e.target.value = v > 0 ? numberFormatter.format(v) : '';
                return v;
            });
        });

        $('.fine-upload', this.scope).each((i, element) => {
            let hIterator = 0;
            let $requiredMockInput, manualUploader = new qq.FineUploader({
                element: element,
                template: 'qq-template-manual-trigger',
                request: {
                    endpoint: this.settings.componentAjaxUrl
                        /*,
                        						params: {
                        							KEY: element.dataset.inputName,
                        		h					FORM_NAME: $form.prop('name')
                        						}*/
                },
                thumbnails: {
                    placeholders: {
                        waitingPath: '/img/1x1-00000000.png',
                        notAvailablePath: '/img/not_available-generic.png',
                    }
                },
                autoUpload: false,
                debug: false,
                callbacks: {
                    onComplete: (id, name, result) => {
                        if (!result || !result.success) {
                            return;
                        }
                        let uploads = manualUploader.getUploads(),
                            t;
                        if (!$requiredMockInput) {
                            $requiredMockInput = $('input.qq-input-required-mock', element)
                        }
                        t = uploads.filter((item) => {
                            return item.status == 'upload successful';
                        }).map((item) => {
                            return item.id;
                        }).join(',');
                        $requiredMockInput.val(t);

                        $('<input/>', {
                            'type': 'hidden',
                            'name': element.dataset.inputName.replace('#ID#', hIterator++),
                            'value': result.path
                        }).appendTo($form);
                    }
                },
                workarounds: {
                    iosEmptyVideos: false,
                    ios8SafariUploads: true,
                    ios8BrowserCrash: false
                },
                text: {
                    fileInputTitle: 'Нажмите для выбора фото'
                },
                messages: {
                    noFilesError: 'Файлы не выбраны'
                }
            });
            $(element)
                .on('click', '.js-trigger-upload', () => {
                    manualUploader.uploadStoredFiles();
                })
                .filter('[data-required]').find('input.qq-input-required-mock').prop('required', true);
        });
        $('[data-mask]', this.scope).each((i, element) => {
            $(element).mask(element.dataset.mask);
        });

        let brandInput = this.scope.querySelector('.valuation__form-item--PROPERTY_BRAND input[type="text"]'),
            brandDataList = new DatalistElement(brandInput),
            modelInput = this.scope.querySelector('.valuation__form-item--PROPERTY_MODEL input[type="text"]'),
            modelDataList = new DatalistElement(modelInput),
            throttleTime = 300;
        brandInput.parentNode.insertBefore(brandDataList.element, brandInput);

        Rx.Observable.fromEvent(brandInput, 'keyup')
            .throttleTime(throttleTime)
            .map((e) => e.target.value)
            .do((v) => modelInput.disabled = v.length <= 1)
            .filter((v) => v.length > 1)
            .map((v) => {
                return {
                    type: 'brand',
                    query: v
                };
            })
            .switchMap((params) => Rx.Observable.fromPromise(
                $.post(this.settings.ajaxUrl, params, 'json')
            ))
            .map((data) => JSON.parse(data))
            .pluck('ITEMS')
            // .switchMap((items) => Rx.Observable.from(items).defaultIfEmpty([]) )
            // .pluck('NAME')
            // .subscribe((items)=> console.log(items) );
            .subscribe((items) => brandDataList.refresh(_.map(items, 'NAME')));

        // brandInput.addEventListener('keyup', _.debounce((e)=>{
        // 	if(e.target.value.length<=1){
        // 		modelInput.disabled = true;
        // 		return;
        // 	}
        // 	modelInput.disabled = false;
        // 	$.post(
        // 		this.settings.ajaxUrl,
        // 		{
        // 			type: 'brand',
        // 			query: e.target.value
        // 		},
        // 		(data)=>{
        // 			let items =_.get(data, 'ITEMS', []);
        // 			items = _.map(items, 'NAME');
        // 			_.forEach(items, (title)=>brandDataList.append(title));
        // 		},
        // 		'json'
        // 	);
        // }, throttleTime));
        brandInput.addEventListener('input', (e) => {
            modelInput.disabled = !e.target.value.length;
        });

        modelInput.disabled = !brandInput.value;
        modelInput.parentNode.insertBefore(modelDataList.element, modelInput);

        Rx.Observable.fromEvent(modelInput, 'keyup')
            .throttleTime(throttleTime)
            .map((e) => e.target.value)
            .filter((v) => v.length > 1)
            .map((v) => {
                return {
                    type: 'model',
                    parentSection: brandInput.value,
                    query: v
                };
            })
            .switchMap((params) => Rx.Observable.fromPromise(
                $.post(this.settings.ajaxUrl, params, 'json')
            ))
            .map((data) => JSON.parse(data))
            .pluck('ITEMS')
            .subscribe((items) => modelDataList.refresh(_.map(items, 'NAME')));

        // modelInput.addEventListener('keyup', _.debounce((e)=>{
        // 	if(e.target.value.length<=1){
        // 		return;
        // 	}
        // 	$.post(
        // 		this.settings.ajaxUrl,
        // 		{
        // 			type: 'model',
        // 			parentSection: brandInput.value,
        // 			query: e.target.value
        // 		},
        // 		(data)=>{
        // 			modelDataList.clear();
        // 			let items =_.get(data, 'ITEMS', []);
        // 			items = _.map(items, 'NAME');
        // 			_.forEach(items, (title)=>modelDataList.append(title));
        // 		},
        // 		'json'
        // 	);
        // }, throttleTime));
    }
}
/* End */
;; /* Start:"a:4:{s:4:"full";s:105:"/local/templates/landing/bower_components/fine-uploader/dist/jquery.fine-uploader.min.js?1479813372143088";s:6:"source";s:84:"/local/templates/landing/bower_components/fine-uploader/dist/jquery.fine-uploader.js";s:3:"min";s:88:"/local/templates/landing/bower_components/fine-uploader/dist/jquery.fine-uploader.min.js";s:3:"map";s:92:"/local/templates/landing/bower_components/fine-uploader/dist/jquery.fine-uploader.min.js.map";}"*/
// Fine Uploader 5.11.8 - (c) 2013-present Widen Enterprises, Inc. MIT licensed. http://fineuploader.com
! function(global) {
    ! function(e) {
        "use strict";

        function t(e) {
            var t = s(e || {}),
                i = n(t);
            return o(i), a(t, i), d
        }

        function n(e) {
            var t = r("uploaderType"),
                n = r("endpointType");
            return t ? (t = t.charAt(0).toUpperCase() + t.slice(1).toLowerCase(), n ? new qq[n]["FineUploader" + t](e) : new qq["FineUploader" + t](e)) : n ? new qq[n].FineUploader(e) : new qq.FineUploader(e)
        }

        function i(e, t) {
            var n = d.data("fineuploader");
            return t ? (void 0 === n && (n = {}), n[e] = t, d.data("fineuploader", n), void 0) : void 0 === n ? null : n[e]
        }

        function o(e) {
            return i("uploader", e)
        }

        function r(e, t) {
            return i(e, t)
        }

        function a(t, n) {
            var i = t.callbacks = {};
            e.each(n._options.callbacks, function(t, n) {
                var o, r;
                o = /^on(\w+)/.exec(t)[1], o = o.substring(0, 1).toLowerCase() + o.substring(1), r = d, i[t] = function() {
                    var t, i, a = Array.prototype.slice.call(arguments),
                        s = [];
                    e.each(a, function(e, t) {
                        s.push(c(t))
                    }), t = n.apply(this, a);
                    try {
                        i = r.triggerHandler(o, s)
                    } catch (e) {
                        qq.log("Caught error in Fine Uploader jQuery event handler: " + e.message, "error")
                    }
                    return null != t ? t : i
                }
            }), n._options.callbacks = i
        }

        function s(t, n) {
            var i, o;
            if (i = void 0 === n ? "basic" !== t.uploaderType ? {
                    element: d[0]
                } : {} : n, e.each(t, function(t, n) {
                    e.inArray(t, p) >= 0 ? r(t, n) : n instanceof e ? i[t] = n[0] : e.isPlainObject(n) ? (i[t] = {}, s(n, i[t])) : e.isArray(n) ? (o = [], e.each(n, function(t, n) {
                        var i = {};
                        n instanceof e ? e.merge(o, n) : e.isPlainObject(n) ? (s(n, i), o.push(i)) : o.push(n)
                    }), i[t] = o) : i[t] = n
                }), void 0 === n) return i
        }

        function l(t) {
            return "string" === e.type(t) && !t.match(/^_/) && void 0 !== o()[t]
        }

        function u(e) {
            var t, n = [],
                i = Array.prototype.slice.call(arguments, 1);
            return s(i, n), t = o()[e].apply(o(), n), c(t)
        }

        function c(t) {
            var n = t;
            return null == t || "object" != typeof t || 1 !== t.nodeType && 9 !== t.nodeType || !t.cloneNode || (n = e(t)), n
        }
        var d, p = ["uploaderType", "endpointType"];
        e.fn.fineUploader = function(n) {
            var i = this,
                r = arguments,
                a = [];
            return this.each(function(s, c) {
                if (d = e(c), o() && l(n)) {
                    if (a.push(u.apply(i, r)), 1 === i.length) return !1
                } else "object" != typeof n && n ? e.error("Method " + n + " does not exist on jQuery.fineUploader") : t.apply(i, r)
            }), 1 === a.length ? a[0] : a.length > 1 ? a : this
        }
    }(jQuery);
    var qq = function(e) {
        "use strict";
        return {
            hide: function() {
                return e.style.display = "none", this
            },
            attach: function(t, n) {
                return e.addEventListener ? e.addEventListener(t, n, !1) : e.attachEvent && e.attachEvent("on" + t, n),
                    function() {
                        qq(e).detach(t, n)
                    }
            },
            detach: function(t, n) {
                return e.removeEventListener ? e.removeEventListener(t, n, !1) : e.attachEvent && e.detachEvent("on" + t, n), this
            },
            contains: function(t) {
                return !!t && (e === t || (e.contains ? e.contains(t) : !!(8 & t.compareDocumentPosition(e))))
            },
            insertBefore: function(t) {
                return t.parentNode.insertBefore(e, t), this
            },
            remove: function() {
                return e.parentNode.removeChild(e), this
            },
            css: function(t) {
                if (null == e.style) throw new qq.Error("Can't apply style to node as it is not on the HTMLElement prototype chain!");
                return null != t.opacity && "string" != typeof e.style.opacity && "undefined" != typeof e.filters && (t.filter = "alpha(opacity=" + Math.round(100 * t.opacity) + ")"), qq.extend(e.style, t), this
            },
            hasClass: function(t, n) {
                var i = new RegExp("(^| )" + t + "( |$)");
                return i.test(e.className) || !(!n || !i.test(e.parentNode.className))
            },
            addClass: function(t) {
                return qq(e).hasClass(t) || (e.className += " " + t), this
            },
            removeClass: function(t) {
                var n = new RegExp("(^| )" + t + "( |$)");
                return e.className = e.className.replace(n, " ").replace(/^\s+|\s+$/g, ""), this
            },
            getByClass: function(t, n) {
                var i, o = [];
                return n && e.querySelector ? e.querySelector("." + t) : e.querySelectorAll ? e.querySelectorAll("." + t) : (i = e.getElementsByTagName("*"), qq.each(i, function(e, n) {
                    qq(n).hasClass(t) && o.push(n)
                }), n ? o[0] : o)
            },
            getFirstByClass: function(t) {
                return qq(e).getByClass(t, !0)
            },
            children: function() {
                for (var t = [], n = e.firstChild; n;) 1 === n.nodeType && t.push(n), n = n.nextSibling;
                return t
            },
            setText: function(t) {
                return e.innerText = t, e.textContent = t, this
            },
            clearText: function() {
                return qq(e).setText("")
            },
            hasAttribute: function(t) {
                var n;
                return e.hasAttribute ? !!e.hasAttribute(t) && null == /^false$/i.exec(e.getAttribute(t)) : (n = e[t], void 0 !== n && null == /^false$/i.exec(n))
            }
        }
    };
    ! function() {
        "use strict";
        qq.canvasToBlob = function(e, t, n) {
            return qq.dataUriToBlob(e.toDataURL(t, n))
        }, qq.dataUriToBlob = function(e) {
            var t, n, i, o, r = function(e, t) {
                var n = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder,
                    i = n && new n;
                return i ? (i.append(e), i.getBlob(t)) : new Blob([e], {
                    type: t
                })
            };
            return n = e.split(",")[0].indexOf("base64") >= 0 ? atob(e.split(",")[1]) : decodeURI(e.split(",")[1]), o = e.split(",")[0].split(":")[1].split(";")[0], t = new ArrayBuffer(n.length), i = new Uint8Array(t), qq.each(n, function(e, t) {
                i[e] = t.charCodeAt(0)
            }), r(t, o)
        }, qq.log = function(e, t) {
            window.console && (t && "info" !== t ? window.console[t] ? window.console[t](e) : window.console.log("<" + t + "> " + e) : window.console.log(e))
        }, qq.isObject = function(e) {
            return e && !e.nodeType && "[object Object]" === Object.prototype.toString.call(e)
        }, qq.isFunction = function(e) {
            return "function" == typeof e
        }, qq.isArray = function(e) {
            return "[object Array]" === Object.prototype.toString.call(e) || e && window.ArrayBuffer && e.buffer && e.buffer.constructor === ArrayBuffer
        }, qq.isItemList = function(e) {
            return "[object DataTransferItemList]" === Object.prototype.toString.call(e)
        }, qq.isNodeList = function(e) {
            return "[object NodeList]" === Object.prototype.toString.call(e) || e.item && e.namedItem
        }, qq.isString = function(e) {
            return "[object String]" === Object.prototype.toString.call(e)
        }, qq.trimStr = function(e) {
            return String.prototype.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "")
        }, qq.format = function(e) {
            var t = Array.prototype.slice.call(arguments, 1),
                n = e,
                i = n.indexOf("{}");
            return qq.each(t, function(e, t) {
                var o = n.substring(0, i),
                    r = n.substring(i + 2);
                if (n = o + t + r, i = n.indexOf("{}", i + t.length), i < 0) return !1
            }), n
        }, qq.isFile = function(e) {
            return window.File && "[object File]" === Object.prototype.toString.call(e)
        }, qq.isFileList = function(e) {
            return window.FileList && "[object FileList]" === Object.prototype.toString.call(e)
        }, qq.isFileOrInput = function(e) {
            return qq.isFile(e) || qq.isInput(e)
        }, qq.isInput = function(e, t) {
            var n = function(e) {
                var n = e.toLowerCase();
                return t ? "file" !== n : "file" === n
            };
            return !!(window.HTMLInputElement && "[object HTMLInputElement]" === Object.prototype.toString.call(e) && e.type && n(e.type)) || !!(e.tagName && "input" === e.tagName.toLowerCase() && e.type && n(e.type))
        }, qq.isBlob = function(e) {
            if (window.Blob && "[object Blob]" === Object.prototype.toString.call(e)) return !0
        }, qq.isXhrUploadSupported = function() {
            var e = document.createElement("input");
            return e.type = "file", void 0 !== e.multiple && "undefined" != typeof File && "undefined" != typeof FormData && "undefined" != typeof qq.createXhrInstance().upload
        }, qq.createXhrInstance = function() {
            if (window.XMLHttpRequest) return new XMLHttpRequest;
            try {
                return new ActiveXObject("MSXML2.XMLHTTP.3.0")
            } catch (e) {
                return qq.log("Neither XHR or ActiveX are supported!", "error"), null
            }
        }, qq.isFolderDropSupported = function(e) {
            return e.items && e.items.length > 0 && e.items[0].webkitGetAsEntry
        }, qq.isFileChunkingSupported = function() {
            return !qq.androidStock() && qq.isXhrUploadSupported() && (void 0 !== File.prototype.slice || void 0 !== File.prototype.webkitSlice || void 0 !== File.prototype.mozSlice)
        }, qq.sliceBlob = function(e, t, n) {
            var i = e.slice || e.mozSlice || e.webkitSlice;
            return i.call(e, t, n)
        }, qq.arrayBufferToHex = function(e) {
            var t = "",
                n = new Uint8Array(e);
            return qq.each(n, function(e, n) {
                var i = n.toString(16);
                i.length < 2 && (i = "0" + i), t += i
            }), t
        }, qq.readBlobToHex = function(e, t, n) {
            var i = qq.sliceBlob(e, t, t + n),
                o = new FileReader,
                r = new qq.Promise;
            return o.onload = function() {
                r.success(qq.arrayBufferToHex(o.result))
            }, o.onerror = r.failure, o.readAsArrayBuffer(i), r
        }, qq.extend = function(e, t, n) {
            return qq.each(t, function(t, i) {
                n && qq.isObject(i) ? (void 0 === e[t] && (e[t] = {}), qq.extend(e[t], i, !0)) : e[t] = i
            }), e
        }, qq.override = function(e, t) {
            var n = {},
                i = t(n);
            return qq.each(i, function(t, i) {
                void 0 !== e[t] && (n[t] = e[t]), e[t] = i
            }), e
        }, qq.indexOf = function(e, t, n) {
            if (e.indexOf) return e.indexOf(t, n);
            n = n || 0;
            var i = e.length;
            for (n < 0 && (n += i); n < i; n += 1)
                if (e.hasOwnProperty(n) && e[n] === t) return n;
            return -1
        }, qq.getUniqueId = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                var t = 16 * Math.random() | 0,
                    n = "x" == e ? t : 3 & t | 8;
                return n.toString(16)
            })
        }, qq.ie = function() {
            return navigator.userAgent.indexOf("MSIE") !== -1 || navigator.userAgent.indexOf("Trident") !== -1
        }, qq.ie7 = function() {
            return navigator.userAgent.indexOf("MSIE 7") !== -1
        }, qq.ie8 = function() {
            return navigator.userAgent.indexOf("MSIE 8") !== -1
        }, qq.ie10 = function() {
            return navigator.userAgent.indexOf("MSIE 10") !== -1
        }, qq.ie11 = function() {
            return qq.ie() && navigator.userAgent.indexOf("rv:11") !== -1
        }, qq.edge = function() {
            return navigator.userAgent.indexOf("Edge") >= 0
        }, qq.safari = function() {
            return void 0 !== navigator.vendor && navigator.vendor.indexOf("Apple") !== -1
        }, qq.chrome = function() {
            return void 0 !== navigator.vendor && navigator.vendor.indexOf("Google") !== -1
        }, qq.opera = function() {
            return void 0 !== navigator.vendor && navigator.vendor.indexOf("Opera") !== -1
        }, qq.firefox = function() {
            return !qq.edge() && !qq.ie11() && navigator.userAgent.indexOf("Mozilla") !== -1 && void 0 !== navigator.vendor && "" === navigator.vendor
        }, qq.windows = function() {
            return "Win32" === navigator.platform
        }, qq.android = function() {
            return navigator.userAgent.toLowerCase().indexOf("android") !== -1
        }, qq.androidStock = function() {
            return qq.android() && navigator.userAgent.toLowerCase().indexOf("chrome") < 0
        }, qq.ios6 = function() {
            return qq.ios() && navigator.userAgent.indexOf(" OS 6_") !== -1
        }, qq.ios7 = function() {
            return qq.ios() && navigator.userAgent.indexOf(" OS 7_") !== -1
        }, qq.ios8 = function() {
            return qq.ios() && navigator.userAgent.indexOf(" OS 8_") !== -1
        }, qq.ios800 = function() {
            return qq.ios() && navigator.userAgent.indexOf(" OS 8_0 ") !== -1
        }, qq.ios = function() {
            return navigator.userAgent.indexOf("iPad") !== -1 || navigator.userAgent.indexOf("iPod") !== -1 || navigator.userAgent.indexOf("iPhone") !== -1
        }, qq.iosChrome = function() {
            return qq.ios() && navigator.userAgent.indexOf("CriOS") !== -1
        }, qq.iosSafari = function() {
            return qq.ios() && !qq.iosChrome() && navigator.userAgent.indexOf("Safari") !== -1
        }, qq.iosSafariWebView = function() {
            return qq.ios() && !qq.iosChrome() && !qq.iosSafari()
        }, qq.preventDefault = function(e) {
            e.preventDefault ? e.preventDefault() : e.returnValue = !1
        }, qq.toElement = function() {
            var e = document.createElement("div");
            return function(t) {
                e.innerHTML = t;
                var n = e.firstChild;
                return e.removeChild(n), n
            }
        }(), qq.each = function(e, t) {
            var n, i;
            if (e)
                if (window.Storage && e.constructor === window.Storage)
                    for (n = 0; n < e.length && (i = t(e.key(n), e.getItem(e.key(n))), i !== !1); n++);
                else if (qq.isArray(e) || qq.isItemList(e) || qq.isNodeList(e))
                for (n = 0; n < e.length && (i = t(n, e[n]), i !== !1); n++);
            else if (qq.isString(e))
                for (n = 0; n < e.length && (i = t(n, e.charAt(n)), i !== !1); n++);
            else
                for (n in e)
                    if (Object.prototype.hasOwnProperty.call(e, n) && (i = t(n, e[n]), i === !1)) break
        }, qq.bind = function(e, t) {
            if (qq.isFunction(e)) {
                var n = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var i = qq.extend([], n);
                    return arguments.length && (i = i.concat(Array.prototype.slice.call(arguments))), e.apply(t, i)
                }
            }
            throw new Error("first parameter must be a function!")
        }, qq.obj2url = function(e, t, n) {
            var i = [],
                o = "&",
                r = function(e, n) {
                    var o = t ? /\[\]$/.test(t) ? t : t + "[" + n + "]" : n;
                    "undefined" !== o && "undefined" !== n && i.push("object" == typeof e ? qq.obj2url(e, o, !0) : "[object Function]" === Object.prototype.toString.call(e) ? encodeURIComponent(o) + "=" + encodeURIComponent(e()) : encodeURIComponent(o) + "=" + encodeURIComponent(e))
                };
            return !n && t ? (o = /\?/.test(t) ? /\?$/.test(t) ? "" : "&" : "?", i.push(t), i.push(qq.obj2url(e))) : "[object Array]" === Object.prototype.toString.call(e) && "undefined" != typeof e ? qq.each(e, function(e, t) {
                r(t, e)
            }) : "undefined" != typeof e && null !== e && "object" == typeof e ? qq.each(e, function(e, t) {
                r(t, e)
            }) : i.push(encodeURIComponent(t) + "=" + encodeURIComponent(e)), t ? i.join(o) : i.join(o).replace(/^&/, "").replace(/%20/g, "+")
        }, qq.obj2FormData = function(e, t, n) {
            return t || (t = new FormData), qq.each(e, function(e, i) {
                e = n ? n + "[" + e + "]" : e, qq.isObject(i) ? qq.obj2FormData(i, t, e) : qq.isFunction(i) ? t.append(e, i()) : t.append(e, i)
            }), t
        }, qq.obj2Inputs = function(e, t) {
            var n;
            return t || (t = document.createElement("form")), qq.obj2FormData(e, {
                append: function(e, i) {
                    n = document.createElement("input"), n.setAttribute("name", e), n.setAttribute("value", i), t.appendChild(n)
                }
            }), t
        }, qq.parseJson = function(json) {
            return window.JSON && qq.isFunction(JSON.parse) ? JSON.parse(json) : eval("(" + json + ")")
        }, qq.getExtension = function(e) {
            var t = e.lastIndexOf(".") + 1;
            if (t > 0) return e.substr(t, e.length - t)
        }, qq.getFilename = function(e) {
            return qq.isInput(e) ? e.value.replace(/.*(\/|\\)/, "") : qq.isFile(e) && null !== e.fileName && void 0 !== e.fileName ? e.fileName : e.name
        }, qq.DisposeSupport = function() {
            var e = [];
            return {
                dispose: function() {
                    var t;
                    do t = e.shift(), t && t(); while (t)
                },
                attach: function() {
                    var e = arguments;
                    this.addDisposer(qq(e[0]).attach.apply(this, Array.prototype.slice.call(arguments, 1)))
                },
                addDisposer: function(t) {
                    e.push(t)
                }
            }
        }
    }(),
    function() {
        "use strict";
        "function" == typeof define && define.amd ? define(function() {
            return qq
        }) : "undefined" != typeof module && module.exports ? module.exports = qq : global.qq = qq
    }(),
    function() {
        "use strict";
        qq.Error = function(e) {
            this.message = "[Fine Uploader " + qq.version + "] " + e
        }, qq.Error.prototype = new Error
    }(), qq.version = "5.11.8", qq.supportedFeatures = function() {
            "use strict";

            function e() {
                var e, t = !0;
                try {
                    e = document.createElement("input"), e.type = "file", qq(e).hide(), e.disabled && (t = !1)
                } catch (e) {
                    t = !1
                }
                return t
            }

            function t() {
                return (qq.chrome() || qq.opera()) && void 0 !== navigator.userAgent.match(/Chrome\/[2][1-9]|Chrome\/[3-9][0-9]/)
            }

            function n() {
                return (qq.chrome() || qq.opera()) && void 0 !== navigator.userAgent.match(/Chrome\/[1][4-9]|Chrome\/[2-9][0-9]/)
            }

            function i() {
                if (window.XMLHttpRequest) {
                    var e = qq.createXhrInstance();
                    return void 0 !== e.withCredentials
                }
                return !1
            }

            function o() {
                return void 0 !== window.XDomainRequest
            }

            function r() {
                return !!i() || o()
            }

            function a() {
                return void 0 !== document.createElement("input").webkitdirectory
            }

            function s() {
                try {
                    return !!window.localStorage && qq.isFunction(window.localStorage.setItem)
                } catch (e) {
                    return !1
                }
            }

            function l() {
                var e = document.createElement("span");
                return ("draggable" in e || "ondragstart" in e && "ondrop" in e) && !qq.android() && !qq.ios()
            }
            var u, c, d, p, h, f, q, m, g, _, v, b, y, S, w;
            return u = e(), p = u && qq.isXhrUploadSupported(), c = p && !qq.androidStock(), d = p && l(), h = d && t(), f = p && qq.isFileChunkingSupported(), q = p && f && s(), m = p && n(), g = u && (void 0 !== window.postMessage || p), v = i(), _ = o(), b = r(), y = a(), S = p && void 0 !== window.FileReader, w = function() {
                return !!p && (!qq.androidStock() && !qq.iosChrome())
            }(), {
                ajaxUploading: p,
                blobUploading: c,
                canDetermineSize: p,
                chunking: f,
                deleteFileCors: b,
                deleteFileCorsXdr: _,
                deleteFileCorsXhr: v,
                dialogElement: !!window.HTMLDialogElement,
                fileDrop: d,
                folderDrop: h,
                folderSelection: y,
                imagePreviews: S,
                imageValidation: S,
                itemSizeValidation: p,
                pause: f,
                progressBar: w,
                resume: q,
                scaling: S && c,
                tiffPreviews: qq.safari(),
                unlimitedScaledImageSize: !qq.ios(),
                uploading: u,
                uploadCors: g,
                uploadCustomHeaders: p,
                uploadNonMultipart: p,
                uploadViaPaste: m
            }
        }(), qq.isGenericPromise = function(e) {
            "use strict";
            return !!(e && e.then && qq.isFunction(e.then))
        }, qq.Promise = function() {
            "use strict";
            var e, t, n = [],
                i = [],
                o = [],
                r = 0;
            qq.extend(this, {
                then: function(o, a) {
                    return 0 === r ? (o && n.push(o), a && i.push(a)) : r === -1 ? a && a.apply(null, t) : o && o.apply(null, e), this
                },
                done: function(n) {
                    return 0 === r ? o.push(n) : n.apply(null, void 0 === t ? e : t), this
                },
                success: function() {
                    return r = 1, e = arguments, n.length && qq.each(n, function(t, n) {
                        n.apply(null, e)
                    }), o.length && qq.each(o, function(t, n) {
                        n.apply(null, e)
                    }), this
                },
                failure: function() {
                    return r = -1, t = arguments, i.length && qq.each(i, function(e, n) {
                        n.apply(null, t)
                    }), o.length && qq.each(o, function(e, n) {
                        n.apply(null, t)
                    }), this
                }
            })
        }, qq.BlobProxy = function(e, t) {
            "use strict";
            qq.extend(this, {
                referenceBlob: e,
                create: function() {
                    return t(e)
                }
            })
        }, qq.UploadButton = function(e) {
            "use strict";

            function t() {
                var e = document.createElement("input");
                return e.setAttribute(qq.UploadButton.BUTTON_ID_ATTR_NAME, i), e.setAttribute("title", a.title), o.setMultiple(a.multiple, e), a.folders && qq.supportedFeatures.folderSelection && e.setAttribute("webkitdirectory", ""), a.acceptFiles && e.setAttribute("accept", a.acceptFiles), e.setAttribute("type", "file"), e.setAttribute("name", a.name), qq(e).css({
                    position: "absolute",
                    right: 0,
                    top: 0,
                    fontFamily: "Arial",
                    fontSize: qq.ie() && !qq.ie8() ? "3500px" : "118px",
                    margin: 0,
                    padding: 0,
                    cursor: "pointer",
                    opacity: 0
                }), !qq.ie7() && qq(e).css({
                    height: "100%"
                }), a.element.appendChild(e), r.attach(e, "change", function() {
                    a.onChange(e)
                }), r.attach(e, "mouseover", function() {
                    qq(a.element).addClass(a.hoverClass)
                }), r.attach(e, "mouseout", function() {
                    qq(a.element).removeClass(a.hoverClass)
                }), r.attach(e, "focus", function() {
                    qq(a.element).addClass(a.focusClass)
                }), r.attach(e, "blur", function() {
                    qq(a.element).removeClass(a.focusClass)
                }), e
            }
            var n, i, o = this,
                r = new qq.DisposeSupport,
                a = {
                    acceptFiles: null,
                    element: null,
                    focusClass: "qq-upload-button-focus",
                    folders: !1,
                    hoverClass: "qq-upload-button-hover",
                    ios8BrowserCrashWorkaround: !1,
                    multiple: !1,
                    name: "qqfile",
                    onChange: function(e) {},
                    title: null
                };
            qq.extend(a, e), i = qq.getUniqueId(), qq(a.element).css({
                position: "relative",
                overflow: "hidden",
                direction: "ltr"
            }), qq.extend(this, {
                getInput: function() {
                    return n
                },
                getButtonId: function() {
                    return i
                },
                setMultiple: function(e, t) {
                    var n = t || this.getInput();
                    a.ios8BrowserCrashWorkaround && qq.ios8() && (qq.iosChrome() || qq.iosSafariWebView()) ? n.setAttribute("multiple", "") : e ? n.setAttribute("multiple", "") : n.removeAttribute("multiple")
                },
                setAcceptFiles: function(e) {
                    e !== a.acceptFiles && n.setAttribute("accept", e)
                },
                reset: function() {
                    n.parentNode && qq(n).remove(), qq(a.element).removeClass(a.focusClass), n = null, n = t()
                }
            }), n = t()
        }, qq.UploadButton.BUTTON_ID_ATTR_NAME = "qq-button-id", qq.UploadData = function(e) {
            "use strict";

            function t(e) {
                if (qq.isArray(e)) {
                    var t = [];
                    return qq.each(e, function(e, n) {
                        t.push(o[n])
                    }), t
                }
                return o[e]
            }

            function n(e) {
                if (qq.isArray(e)) {
                    var t = [];
                    return qq.each(e, function(e, n) {
                        t.push(o[r[n]])
                    }), t
                }
                return o[r[e]]
            }

            function i(e) {
                var t = [],
                    n = [].concat(e);
                return qq.each(n, function(e, n) {
                    var i = a[n];
                    void 0 !== i && qq.each(i, function(e, n) {
                        t.push(o[n])
                    })
                }), t
            }
            var o = [],
                r = {},
                a = {},
                s = {},
                l = {};
            qq.extend(this, {
                addFile: function(t) {
                    var n = t.status || qq.status.SUBMITTING,
                        i = o.push({
                            name: t.name,
                            originalName: t.name,
                            uuid: t.uuid,
                            size: null == t.size ? -1 : t.size,
                            status: n
                        }) - 1;
                    return t.batchId && (o[i].batchId = t.batchId, void 0 === l[t.batchId] && (l[t.batchId] = []), l[t.batchId].push(i)), t.proxyGroupId && (o[i].proxyGroupId = t.proxyGroupId, void 0 === s[t.proxyGroupId] && (s[t.proxyGroupId] = []), s[t.proxyGroupId].push(i)), o[i].id = i, r[t.uuid] = i, void 0 === a[n] && (a[n] = []), a[n].push(i), e.onStatusChange(i, null, n), i
                },
                retrieve: function(e) {
                    return qq.isObject(e) && o.length ? void 0 !== e.id ? t(e.id) : void 0 !== e.uuid ? n(e.uuid) : e.status ? i(e.status) : void 0 : qq.extend([], o, !0)
                },
                reset: function() {
                    o = [], r = {}, a = {}, l = {}
                },
                setStatus: function(t, n) {
                    var i = o[t].status,
                        r = qq.indexOf(a[i], t);
                    a[i].splice(r, 1), o[t].status = n, void 0 === a[n] && (a[n] = []), a[n].push(t), e.onStatusChange(t, i, n)
                },
                uuidChanged: function(e, t) {
                    var n = o[e].uuid;
                    o[e].uuid = t, r[t] = e, delete r[n]
                },
                updateName: function(e, t) {
                    o[e].name = t
                },
                updateSize: function(e, t) {
                    o[e].size = t
                },
                setParentId: function(e, t) {
                    o[e].parentId = t
                },
                getIdsInProxyGroup: function(e) {
                    var t = o[e].proxyGroupId;
                    return t ? s[t] : []
                },
                getIdsInBatch: function(e) {
                    var t = o[e].batchId;
                    return l[t]
                }
            })
        }, qq.status = {
            SUBMITTING: "submitting",
            SUBMITTED: "submitted",
            REJECTED: "rejected",
            QUEUED: "queued",
            CANCELED: "canceled",
            PAUSED: "paused",
            UPLOADING: "uploading",
            UPLOAD_RETRYING: "retrying upload",
            UPLOAD_SUCCESSFUL: "upload successful",
            UPLOAD_FAILED: "upload failed",
            DELETE_FAILED: "delete failed",
            DELETING: "deleting",
            DELETED: "deleted"
        },
        function() {
            "use strict";
            qq.basePublicApi = {
                addBlobs: function(e, t, n) {
                    this.addFiles(e, t, n)
                },
                addInitialFiles: function(e) {
                    var t = this;
                    qq.each(e, function(e, n) {
                        t._addCannedFile(n)
                    })
                },
                addFiles: function(e, t, n) {
                    this._maybeHandleIos8SafariWorkaround();
                    var i = 0 === this._storedIds.length ? qq.getUniqueId() : this._currentBatchId,
                        o = qq.bind(function(e) {
                            this._handleNewFile({
                                blob: e,
                                name: this._options.blobs.defaultName
                            }, i, d)
                        }, this),
                        r = qq.bind(function(e) {
                            this._handleNewFile(e, i, d)
                        }, this),
                        a = qq.bind(function(e) {
                            var t = qq.canvasToBlob(e);
                            this._handleNewFile({
                                blob: t,
                                name: this._options.blobs.defaultName + ".png"
                            }, i, d)
                        }, this),
                        s = qq.bind(function(e) {
                            var t = e.quality && e.quality / 100,
                                n = qq.canvasToBlob(e.canvas, e.type, t);
                            this._handleNewFile({
                                blob: n,
                                name: e.name
                            }, i, d)
                        }, this),
                        l = qq.bind(function(e) {
                            if (qq.isInput(e) && qq.supportedFeatures.ajaxUploading) {
                                var t = Array.prototype.slice.call(e.files),
                                    n = this;
                                qq.each(t, function(e, t) {
                                    n._handleNewFile(t, i, d)
                                })
                            } else this._handleNewFile(e, i, d)
                        }, this),
                        u = function() {
                            qq.isFileList(e) && (e = Array.prototype.slice.call(e)), e = [].concat(e)
                        },
                        c = this,
                        d = [];
                    this._currentBatchId = i, e && (u(), qq.each(e, function(e, t) {
                        qq.isFileOrInput(t) ? l(t) : qq.isBlob(t) ? o(t) : qq.isObject(t) ? t.blob && t.name ? r(t) : t.canvas && t.name && s(t) : t.tagName && "canvas" === t.tagName.toLowerCase() ? a(t) : c.log(t + " is not a valid file container!  Ignoring!", "warn")
                    }), this.log("Received " + d.length + " files."), this._prepareItemsForUpload(d, t, n))
                },
                cancel: function(e) {
                    this._handler.cancel(e)
                },
                cancelAll: function() {
                    var e = [],
                        t = this;
                    qq.extend(e, this._storedIds), qq.each(e, function(e, n) {
                        t.cancel(n)
                    }), this._handler.cancelAll()
                },
                clearStoredFiles: function() {
                    this._storedIds = []
                },
                continueUpload: function(e) {
                    var t = this._uploadData.retrieve({
                        id: e
                    });
                    return !(!qq.supportedFeatures.pause || !this._options.chunking.enabled) && (t.status === qq.status.PAUSED ? (this.log(qq.format("Paused file ID {} ({}) will be continued.  Not paused.", e, this.getName(e))), this._uploadFile(e), !0) : (this.log(qq.format("Ignoring continue for file ID {} ({}).  Not paused.", e, this.getName(e)), "error"), !1))
                },
                deleteFile: function(e) {
                    return this._onSubmitDelete(e)
                },
                doesExist: function(e) {
                    return this._handler.isValid(e)
                },
                drawThumbnail: function(e, t, n, i, o) {
                    var r, a, s = new qq.Promise;
                    return this._imageGenerator ? (r = this._thumbnailUrls[e], a = {
                        customResizeFunction: o,
                        maxSize: n > 0 ? n : null,
                        scale: n > 0
                    }, !i && qq.supportedFeatures.imagePreviews && (r = this.getFile(e)), null == r ? s.failure({
                        container: t,
                        error: "File or URL not found."
                    }) : this._imageGenerator.generate(r, t, a).then(function(e) {
                        s.success(e)
                    }, function(e, t) {
                        s.failure({
                            container: e,
                            error: t || "Problem generating thumbnail"
                        })
                    })) : s.failure({
                        container: t,
                        error: "Missing image generator module"
                    }), s
                },
                getButton: function(e) {
                    return this._getButton(this._buttonIdsForFileIds[e])
                },
                getEndpoint: function(e) {
                    return this._endpointStore.get(e)
                },
                getFile: function(e) {
                    return this._handler.getFile(e) || null
                },
                getInProgress: function() {
                    return this._uploadData.retrieve({
                        status: [qq.status.UPLOADING, qq.status.UPLOAD_RETRYING, qq.status.QUEUED]
                    }).length
                },
                getName: function(e) {
                    return this._uploadData.retrieve({
                        id: e
                    }).name
                },
                getParentId: function(e) {
                    var t = this.getUploads({
                            id: e
                        }),
                        n = null;
                    return t && void 0 !== t.parentId && (n = t.parentId), n
                },
                getResumableFilesData: function() {
                    return this._handler.getResumableFilesData()
                },
                getSize: function(e) {
                    return this._uploadData.retrieve({
                        id: e
                    }).size
                },
                getNetUploads: function() {
                    return this._netUploaded
                },
                getRemainingAllowedItems: function() {
                    var e = this._currentItemLimit;
                    return e > 0 ? e - this._netUploadedOrQueued : null
                },
                getUploads: function(e) {
                    return this._uploadData.retrieve(e)
                },
                getUuid: function(e) {
                    return this._uploadData.retrieve({
                        id: e
                    }).uuid
                },
                log: function(e, t) {
                    !this._options.debug || t && "info" !== t ? t && "info" !== t && qq.log("[Fine Uploader " + qq.version + "] " + e, t) : qq.log("[Fine Uploader " + qq.version + "] " + e)
                },
                pauseUpload: function(e) {
                    var t = this._uploadData.retrieve({
                        id: e
                    });
                    if (!qq.supportedFeatures.pause || !this._options.chunking.enabled) return !1;
                    if (qq.indexOf([qq.status.UPLOADING, qq.status.UPLOAD_RETRYING], t.status) >= 0) {
                        if (this._handler.pause(e)) return this._uploadData.setStatus(e, qq.status.PAUSED), !0;
                        this.log(qq.format("Unable to pause file ID {} ({}).", e, this.getName(e)), "error")
                    } else this.log(qq.format("Ignoring pause for file ID {} ({}).  Not in progress.", e, this.getName(e)), "error");
                    return !1
                },
                reset: function() {
                    this.log("Resetting uploader..."), this._handler.reset(), this._storedIds = [], this._autoRetries = [], this._retryTimeouts = [], this._preventRetries = [], this._thumbnailUrls = [], qq.each(this._buttons, function(e, t) {
                        t.reset()
                    }), this._paramsStore.reset(), this._endpointStore.reset(), this._netUploadedOrQueued = 0, this._netUploaded = 0, this._uploadData.reset(), this._buttonIdsForFileIds = [], this._pasteHandler && this._pasteHandler.reset(), this._options.session.refreshOnReset && this._refreshSessionData(), this._succeededSinceLastAllComplete = [], this._failedSinceLastAllComplete = [], this._totalProgress && this._totalProgress.reset()
                },
                retry: function(e) {
                    return this._manualRetry(e)
                },
                scaleImage: function(e, t) {
                    var n = this;
                    return qq.Scaler.prototype.scaleImage(e, t, {
                        log: qq.bind(n.log, n),
                        getFile: qq.bind(n.getFile, n),
                        uploadData: n._uploadData
                    })
                },
                setCustomHeaders: function(e, t) {
                    this._customHeadersStore.set(e, t)
                },
                setDeleteFileCustomHeaders: function(e, t) {
                    this._deleteFileCustomHeadersStore.set(e, t)
                },
                setDeleteFileEndpoint: function(e, t) {
                    this._deleteFileEndpointStore.set(e, t)
                },
                setDeleteFileParams: function(e, t) {
                    this._deleteFileParamsStore.set(e, t)
                },
                setEndpoint: function(e, t) {
                    this._endpointStore.set(e, t)
                },
                setForm: function(e) {
                    this._updateFormSupportAndParams(e)
                },
                setItemLimit: function(e) {
                    this._currentItemLimit = e
                },
                setName: function(e, t) {
                    this._uploadData.updateName(e, t)
                },
                setParams: function(e, t) {
                    this._paramsStore.set(e, t)
                },
                setUuid: function(e, t) {
                    return this._uploadData.uuidChanged(e, t)
                },
                uploadStoredFiles: function() {
                    0 === this._storedIds.length ? this._itemError("noFilesError") : this._uploadStoredFiles()
                }
            }, qq.basePrivateApi = {
                _addCannedFile: function(e) {
                    var t = this._uploadData.addFile({
                        uuid: e.uuid,
                        name: e.name,
                        size: e.size,
                        status: qq.status.UPLOAD_SUCCESSFUL
                    });
                    return e.deleteFileEndpoint && this.setDeleteFileEndpoint(e.deleteFileEndpoint, t), e.deleteFileParams && this.setDeleteFileParams(e.deleteFileParams, t), e.thumbnailUrl && (this._thumbnailUrls[t] = e.thumbnailUrl), this._netUploaded++, this._netUploadedOrQueued++, t
                },
                _annotateWithButtonId: function(e, t) {
                    qq.isFile(e) && (e.qqButtonId = this._getButtonId(t))
                },
                _batchError: function(e) {
                    this._options.callbacks.onError(null, null, e, void 0)
                },
                _createDeleteHandler: function() {
                    var e = this;
                    return new qq.DeleteFileAjaxRequester({
                        method: this._options.deleteFile.method.toUpperCase(),
                        maxConnections: this._options.maxConnections,
                        uuidParamName: this._options.request.uuidName,
                        customHeaders: this._deleteFileCustomHeadersStore,
                        paramsStore: this._deleteFileParamsStore,
                        endpointStore: this._deleteFileEndpointStore,
                        cors: this._options.cors,
                        log: qq.bind(e.log, e),
                        onDelete: function(t) {
                            e._onDelete(t), e._options.callbacks.onDelete(t)
                        },
                        onDeleteComplete: function(t, n, i) {
                            e._onDeleteComplete(t, n, i), e._options.callbacks.onDeleteComplete(t, n, i)
                        }
                    })
                },
                _createPasteHandler: function() {
                    var e = this;
                    return new qq.PasteSupport({
                        targetElement: this._options.paste.targetElement,
                        callbacks: {
                            log: qq.bind(e.log, e),
                            pasteReceived: function(t) {
                                e._handleCheckedCallback({
                                    name: "onPasteReceived",
                                    callback: qq.bind(e._options.callbacks.onPasteReceived, e, t),
                                    onSuccess: qq.bind(e._handlePasteSuccess, e, t),
                                    identifier: "pasted image"
                                })
                            }
                        }
                    })
                },
                _createStore: function(e, t) {
                    var n = {},
                        i = e,
                        o = {},
                        r = t,
                        a = function(e) {
                            return qq.isObject(e) ? qq.extend({}, e) : e
                        },
                        s = function() {
                            return qq.isFunction(r) ? r() : r
                        },
                        l = function(e, t) {
                            r && qq.isObject(t) && qq.extend(t, s()), o[e] && qq.extend(t, o[e])
                        };
                    return {
                        set: function(e, t) {
                            null == t ? (n = {}, i = a(e)) : n[t] = a(e)
                        },
                        get: function(e) {
                            var t;
                            return t = null != e && n[e] ? n[e] : a(i), l(e, t), a(t)
                        },
                        addReadOnly: function(e, t) {
                            qq.isObject(n) && (null === e ? qq.isFunction(t) ? r = t : (r = r || {}, qq.extend(r, t)) : (o[e] = o[e] || {}, qq.extend(o[e], t)))
                        },
                        remove: function(e) {
                            return delete n[e]
                        },
                        reset: function() {
                            n = {}, o = {}, i = e
                        }
                    }
                },
                _createUploadDataTracker: function() {
                    var e = this;
                    return new qq.UploadData({
                        getName: function(t) {
                            return e.getName(t)
                        },
                        getUuid: function(t) {
                            return e.getUuid(t)
                        },
                        getSize: function(t) {
                            return e.getSize(t)
                        },
                        onStatusChange: function(t, n, i) {
                            e._onUploadStatusChange(t, n, i), e._options.callbacks.onStatusChange(t, n, i), e._maybeAllComplete(t, i), e._totalProgress && setTimeout(function() {
                                e._totalProgress.onStatusChange(t, n, i)
                            }, 0)
                        }
                    })
                },
                _createUploadButton: function(e) {
                    function t() {
                        return !!qq.supportedFeatures.ajaxUploading && (!(i._options.workarounds.iosEmptyVideos && qq.ios() && !qq.ios6() && i._isAllowedExtension(r, ".mov")) && (void 0 === e.multiple ? i._options.multiple : e.multiple))
                    }
                    var n, i = this,
                        o = e.accept || this._options.validation.acceptFiles,
                        r = e.allowedExtensions || this._options.validation.allowedExtensions;
                    return n = new qq.UploadButton({
                        acceptFiles: o,
                        element: e.element,
                        focusClass: this._options.classes.buttonFocus,
                        folders: e.folders,
                        hoverClass: this._options.classes.buttonHover,
                        ios8BrowserCrashWorkaround: this._options.workarounds.ios8BrowserCrash,
                        multiple: t(),
                        name: this._options.request.inputName,
                        onChange: function(e) {
                            i._onInputChange(e)
                        },
                        title: null == e.title ? this._options.text.fileInputTitle : e.title
                    }), this._disposeSupport.addDisposer(function() {
                        n.dispose()
                    }), i._buttons.push(n), n
                },
                _createUploadHandler: function(e, t) {
                    var n = this,
                        i = {},
                        o = {
                            debug: this._options.debug,
                            maxConnections: this._options.maxConnections,
                            cors: this._options.cors,
                            paramsStore: this._paramsStore,
                            endpointStore: this._endpointStore,
                            chunking: this._options.chunking,
                            resume: this._options.resume,
                            blobs: this._options.blobs,
                            log: qq.bind(n.log, n),
                            preventRetryParam: this._options.retry.preventRetryResponseProperty,
                            onProgress: function(e, t, o, r) {
                                o < 0 || r < 0 || (i[e] ? i[e].loaded === o && i[e].total === r || (n._onProgress(e, t, o, r), n._options.callbacks.onProgress(e, t, o, r)) : (n._onProgress(e, t, o, r), n._options.callbacks.onProgress(e, t, o, r)), i[e] = {
                                    loaded: o,
                                    total: r
                                })
                            },
                            onComplete: function(e, t, o, r) {
                                delete i[e];
                                var a, s = n.getUploads({
                                    id: e
                                }).status;
                                s !== qq.status.UPLOAD_SUCCESSFUL && s !== qq.status.UPLOAD_FAILED && (a = n._onComplete(e, t, o, r), a instanceof qq.Promise ? a.done(function() {
                                    n._options.callbacks.onComplete(e, t, o, r)
                                }) : n._options.callbacks.onComplete(e, t, o, r))
                            },
                            onCancel: function(e, t, i) {
                                var o = new qq.Promise;
                                return n._handleCheckedCallback({
                                    name: "onCancel",
                                    callback: qq.bind(n._options.callbacks.onCancel, n, e, t),
                                    onFailure: o.failure,
                                    onSuccess: function() {
                                        i.then(function() {
                                            n._onCancel(e, t)
                                        }), o.success()
                                    },
                                    identifier: e
                                }), o
                            },
                            onUploadPrep: qq.bind(this._onUploadPrep, this),
                            onUpload: function(e, t) {
                                n._onUpload(e, t), n._options.callbacks.onUpload(e, t)
                            },
                            onUploadChunk: function(e, t, i) {
                                n._onUploadChunk(e, i), n._options.callbacks.onUploadChunk(e, t, i)
                            },
                            onUploadChunkSuccess: function(e, t, i, o) {
                                n._options.callbacks.onUploadChunkSuccess.apply(n, arguments)
                            },
                            onResume: function(e, t, i) {
                                return n._options.callbacks.onResume(e, t, i)
                            },
                            onAutoRetry: function(e, t, i, o) {
                                return n._onAutoRetry.apply(n, arguments)
                            },
                            onUuidChanged: function(e, t) {
                                n.log("Server requested UUID change from '" + n.getUuid(e) + "' to '" + t + "'"), n.setUuid(e, t)
                            },
                            getName: qq.bind(n.getName, n),
                            getUuid: qq.bind(n.getUuid, n),
                            getSize: qq.bind(n.getSize, n),
                            setSize: qq.bind(n._setSize, n),
                            getDataByUuid: function(e) {
                                return n.getUploads({
                                    uuid: e
                                })
                            },
                            isQueued: function(e) {
                                var t = n.getUploads({
                                    id: e
                                }).status;
                                return t === qq.status.QUEUED || t === qq.status.SUBMITTED || t === qq.status.UPLOAD_RETRYING || t === qq.status.PAUSED
                            },
                            getIdsInProxyGroup: n._uploadData.getIdsInProxyGroup,
                            getIdsInBatch: n._uploadData.getIdsInBatch
                        };
                    return qq.each(this._options.request, function(e, t) {
                        o[e] = t
                    }), o.customHeaders = this._customHeadersStore, e && qq.each(e, function(e, t) {
                        o[e] = t
                    }), new qq.UploadHandlerController(o, t)
                },
                _fileOrBlobRejected: function(e) {
                    this._netUploadedOrQueued--, this._uploadData.setStatus(e, qq.status.REJECTED)
                },
                _formatSize: function(e) {
                    var t = -1;
                    do e /= 1e3, t++; while (e > 999);
                    return Math.max(e, .1).toFixed(1) + this._options.text.sizeSymbols[t]
                },
                _generateExtraButtonSpecs: function() {
                    var e = this;
                    this._extraButtonSpecs = {}, qq.each(this._options.extraButtons, function(t, n) {
                        var i = n.multiple,
                            o = qq.extend({}, e._options.validation, !0),
                            r = qq.extend({}, n);
                        void 0 === i && (i = e._options.multiple), r.validation && qq.extend(o, n.validation, !0), qq.extend(r, {
                            multiple: i,
                            validation: o
                        }, !0), e._initExtraButton(r)
                    })
                },
                _getButton: function(e) {
                    var t = this._extraButtonSpecs[e];
                    return t ? t.element : e === this._defaultButtonId ? this._options.button : void 0
                },
                _getButtonId: function(e) {
                    var t, n, i = e;
                    if (i instanceof qq.BlobProxy && (i = i.referenceBlob), i && !qq.isBlob(i)) {
                        if (qq.isFile(i)) return i.qqButtonId;
                        if ("input" === i.tagName.toLowerCase() && "file" === i.type.toLowerCase()) return i.getAttribute(qq.UploadButton.BUTTON_ID_ATTR_NAME);
                        if (t = i.getElementsByTagName("input"), qq.each(t, function(e, t) {
                                if ("file" === t.getAttribute("type")) return n = t, !1
                            }), n) return n.getAttribute(qq.UploadButton.BUTTON_ID_ATTR_NAME)
                    }
                },
                _getNotFinished: function() {
                    return this._uploadData.retrieve({
                        status: [qq.status.UPLOADING, qq.status.UPLOAD_RETRYING, qq.status.QUEUED, qq.status.SUBMITTING, qq.status.SUBMITTED, qq.status.PAUSED]
                    }).length
                },
                _getValidationBase: function(e) {
                    var t = this._extraButtonSpecs[e];
                    return t ? t.validation : this._options.validation;
                },
                _getValidationDescriptor: function(e) {
                    return e.file instanceof qq.BlobProxy ? {
                        name: qq.getFilename(e.file.referenceBlob),
                        size: e.file.referenceBlob.size
                    } : {
                        name: this.getUploads({
                            id: e.id
                        }).name,
                        size: this.getUploads({
                            id: e.id
                        }).size
                    }
                },
                _getValidationDescriptors: function(e) {
                    var t = this,
                        n = [];
                    return qq.each(e, function(e, i) {
                        n.push(t._getValidationDescriptor(i))
                    }), n
                },
                _handleCameraAccess: function() {
                    if (this._options.camera.ios && qq.ios()) {
                        var e = "image/*;capture=camera",
                            t = this._options.camera.button,
                            n = t ? this._getButtonId(t) : this._defaultButtonId,
                            i = this._options;
                        n && n !== this._defaultButtonId && (i = this._extraButtonSpecs[n]), i.multiple = !1, null === i.validation.acceptFiles ? i.validation.acceptFiles = e : i.validation.acceptFiles += "," + e, qq.each(this._buttons, function(e, t) {
                            if (t.getButtonId() === n) return t.setMultiple(i.multiple), t.setAcceptFiles(i.acceptFiles), !1
                        })
                    }
                },
                _handleCheckedCallback: function(e) {
                    var t = this,
                        n = e.callback();
                    return qq.isGenericPromise(n) ? (this.log(e.name + " - waiting for " + e.name + " promise to be fulfilled for " + e.identifier), n.then(function(n) {
                        t.log(e.name + " promise success for " + e.identifier), e.onSuccess(n)
                    }, function() {
                        e.onFailure ? (t.log(e.name + " promise failure for " + e.identifier), e.onFailure()) : t.log(e.name + " promise failure for " + e.identifier)
                    })) : (n !== !1 ? e.onSuccess(n) : e.onFailure ? (this.log(e.name + " - return value was 'false' for " + e.identifier + ".  Invoking failure callback."), e.onFailure()) : this.log(e.name + " - return value was 'false' for " + e.identifier + ".  Will not proceed."), n)
                },
                _handleNewFile: function(e, t, n) {
                    var i = this,
                        o = qq.getUniqueId(),
                        r = -1,
                        a = qq.getFilename(e),
                        s = e.blob || e,
                        l = this._customNewFileHandler ? this._customNewFileHandler : qq.bind(i._handleNewFileGeneric, i);
                    !qq.isInput(s) && s.size >= 0 && (r = s.size), l(s, a, o, r, n, t, this._options.request.uuidName, {
                        uploadData: i._uploadData,
                        paramsStore: i._paramsStore,
                        addFileToHandler: function(e, t) {
                            i._handler.add(e, t), i._netUploadedOrQueued++, i._trackButton(e)
                        }
                    })
                },
                _handleNewFileGeneric: function(e, t, n, i, o, r) {
                    var a = this._uploadData.addFile({
                        uuid: n,
                        name: t,
                        size: i,
                        batchId: r
                    });
                    this._handler.add(a, e), this._trackButton(a), this._netUploadedOrQueued++, o.push({
                        id: a,
                        file: e
                    })
                },
                _handlePasteSuccess: function(e, t) {
                    var n = e.type.split("/")[1],
                        i = t;
                    null == i && (i = this._options.paste.defaultName), i += "." + n, this.addFiles({
                        name: i,
                        blob: e
                    })
                },
                _initExtraButton: function(e) {
                    var t = this._createUploadButton({
                        accept: e.validation.acceptFiles,
                        allowedExtensions: e.validation.allowedExtensions,
                        element: e.element,
                        folders: e.folders,
                        multiple: e.multiple,
                        title: e.fileInputTitle
                    });
                    this._extraButtonSpecs[t.getButtonId()] = e
                },
                _initFormSupportAndParams: function() {
                    this._formSupport = qq.FormSupport && new qq.FormSupport(this._options.form, qq.bind(this.uploadStoredFiles, this), qq.bind(this.log, this)), this._formSupport && this._formSupport.attachedToForm ? (this._paramsStore = this._createStore(this._options.request.params, this._formSupport.getFormInputsAsObject), this._options.autoUpload = this._formSupport.newAutoUpload, this._formSupport.newEndpoint && (this._options.request.endpoint = this._formSupport.newEndpoint)) : this._paramsStore = this._createStore(this._options.request.params)
                },
                _isDeletePossible: function() {
                    return !(!qq.DeleteFileAjaxRequester || !this._options.deleteFile.enabled) && (!this._options.cors.expected || (!!qq.supportedFeatures.deleteFileCorsXhr || !(!qq.supportedFeatures.deleteFileCorsXdr || !this._options.cors.allowXdr)))
                },
                _isAllowedExtension: function(e, t) {
                    var n = !1;
                    return !e.length || (qq.each(e, function(e, i) {
                        if (qq.isString(i)) {
                            var o = new RegExp("\\." + i + "$", "i");
                            if (null != t.match(o)) return n = !0, !1
                        }
                    }), n)
                },
                _itemError: function(e, t, n) {
                    function i(e, t) {
                        a = a.replace(e, t)
                    }
                    var o, r, a = this._options.messages[e],
                        s = [],
                        l = [].concat(t),
                        u = l[0],
                        c = this._getButtonId(n),
                        d = this._getValidationBase(c);
                    return qq.each(d.allowedExtensions, function(e, t) {
                        qq.isString(t) && s.push(t)
                    }), o = s.join(", ").toLowerCase(), i("{file}", this._options.formatFileName(u)), i("{extensions}", o), i("{sizeLimit}", this._formatSize(d.sizeLimit)), i("{minSizeLimit}", this._formatSize(d.minSizeLimit)), r = a.match(/(\{\w+\})/g), null !== r && qq.each(r, function(e, t) {
                        i(t, l[e])
                    }), this._options.callbacks.onError(null, u, a, void 0), a
                },
                _manualRetry: function(e, t) {
                    if (this._onBeforeManualRetry(e)) return this._netUploadedOrQueued++, this._uploadData.setStatus(e, qq.status.UPLOAD_RETRYING), t ? t(e) : this._handler.retry(e), !0
                },
                _maybeAllComplete: function(e, t) {
                    var n = this,
                        i = this._getNotFinished();
                    t === qq.status.UPLOAD_SUCCESSFUL ? this._succeededSinceLastAllComplete.push(e) : t === qq.status.UPLOAD_FAILED && this._failedSinceLastAllComplete.push(e), 0 === i && (this._succeededSinceLastAllComplete.length || this._failedSinceLastAllComplete.length) && setTimeout(function() {
                        n._onAllComplete(n._succeededSinceLastAllComplete, n._failedSinceLastAllComplete)
                    }, 0)
                },
                _maybeHandleIos8SafariWorkaround: function() {
                    var e = this;
                    if (this._options.workarounds.ios8SafariUploads && qq.ios800() && qq.iosSafari()) throw setTimeout(function() {
                        window.alert(e._options.messages.unsupportedBrowserIos8Safari)
                    }, 0), new qq.Error(this._options.messages.unsupportedBrowserIos8Safari)
                },
                _maybeParseAndSendUploadError: function(e, t, n, i) {
                    if (!n.success)
                        if (i && 200 !== i.status && !n.error) this._options.callbacks.onError(e, t, "XHR returned response code " + i.status, i);
                        else {
                            var o = n.error ? n.error : this._options.text.defaultResponseError;
                            this._options.callbacks.onError(e, t, o, i)
                        }
                },
                _maybeProcessNextItemAfterOnValidateCallback: function(e, t, n, i, o) {
                    var r = this;
                    if (t.length > n)
                        if (e || !this._options.validation.stopOnFirstInvalidFile) setTimeout(function() {
                            var e = r._getValidationDescriptor(t[n]),
                                a = r._getButtonId(t[n].file),
                                s = r._getButton(a);
                            r._handleCheckedCallback({
                                name: "onValidate",
                                callback: qq.bind(r._options.callbacks.onValidate, r, e, s),
                                onSuccess: qq.bind(r._onValidateCallbackSuccess, r, t, n, i, o),
                                onFailure: qq.bind(r._onValidateCallbackFailure, r, t, n, i, o),
                                identifier: "Item '" + e.name + "', size: " + e.size
                            })
                        }, 0);
                        else if (!e)
                        for (; n < t.length; n++) r._fileOrBlobRejected(t[n].id)
                },
                _onAllComplete: function(e, t) {
                    this._totalProgress && this._totalProgress.onAllComplete(e, t, this._preventRetries), this._options.callbacks.onAllComplete(qq.extend([], e), qq.extend([], t)), this._succeededSinceLastAllComplete = [], this._failedSinceLastAllComplete = []
                },
                _onAutoRetry: function(e, t, n, i, o) {
                    var r = this;
                    if (r._preventRetries[e] = n[r._options.retry.preventRetryResponseProperty], r._shouldAutoRetry(e, t, n)) return r._maybeParseAndSendUploadError.apply(r, arguments), r._options.callbacks.onAutoRetry(e, t, r._autoRetries[e]), r._onBeforeAutoRetry(e, t), r._retryTimeouts[e] = setTimeout(function() {
                        r.log("Retrying " + t + "..."), r._uploadData.setStatus(e, qq.status.UPLOAD_RETRYING), o ? o(e) : r._handler.retry(e)
                    }, 1e3 * r._options.retry.autoAttemptDelay), !0
                },
                _onBeforeAutoRetry: function(e, t) {
                    this.log("Waiting " + this._options.retry.autoAttemptDelay + " seconds before retrying " + t + "...")
                },
                _onBeforeManualRetry: function(e) {
                    var t, n = this._currentItemLimit;
                    return this._preventRetries[e] ? (this.log("Retries are forbidden for id " + e, "warn"), !1) : this._handler.isValid(e) ? (t = this.getName(e), this._options.callbacks.onManualRetry(e, t) !== !1 && (n > 0 && this._netUploadedOrQueued + 1 > n ? (this._itemError("retryFailTooManyItems"), !1) : (this.log("Retrying upload for '" + t + "' (id: " + e + ")..."), !0))) : (this.log("'" + e + "' is not a valid file ID", "error"), !1)
                },
                _onCancel: function(e, t) {
                    this._netUploadedOrQueued--, clearTimeout(this._retryTimeouts[e]);
                    var n = qq.indexOf(this._storedIds, e);
                    !this._options.autoUpload && n >= 0 && this._storedIds.splice(n, 1), this._uploadData.setStatus(e, qq.status.CANCELED)
                },
                _onComplete: function(e, t, n, i) {
                    return n.success ? (n.thumbnailUrl && (this._thumbnailUrls[e] = n.thumbnailUrl), this._netUploaded++, this._uploadData.setStatus(e, qq.status.UPLOAD_SUCCESSFUL)) : (this._netUploadedOrQueued--, this._uploadData.setStatus(e, qq.status.UPLOAD_FAILED), n[this._options.retry.preventRetryResponseProperty] === !0 && (this._preventRetries[e] = !0)), this._maybeParseAndSendUploadError(e, t, n, i), !!n.success
                },
                _onDelete: function(e) {
                    this._uploadData.setStatus(e, qq.status.DELETING)
                },
                _onDeleteComplete: function(e, t, n) {
                    var i = this.getName(e);
                    n ? (this._uploadData.setStatus(e, qq.status.DELETE_FAILED), this.log("Delete request for '" + i + "' has failed.", "error"), void 0 === t.withCredentials ? this._options.callbacks.onError(e, i, "Delete request failed", t) : this._options.callbacks.onError(e, i, "Delete request failed with response code " + t.status, t)) : (this._netUploadedOrQueued--, this._netUploaded--, this._handler.expunge(e), this._uploadData.setStatus(e, qq.status.DELETED), this.log("Delete request for '" + i + "' has succeeded."))
                },
                _onInputChange: function(e) {
                    var t;
                    if (qq.supportedFeatures.ajaxUploading) {
                        for (t = 0; t < e.files.length; t++) this._annotateWithButtonId(e.files[t], e);
                        this.addFiles(e.files)
                    } else e.value.length > 0 && this.addFiles(e);
                    qq.each(this._buttons, function(e, t) {
                        t.reset()
                    })
                },
                _onProgress: function(e, t, n, i) {
                    this._totalProgress && this._totalProgress.onIndividualProgress(e, n, i)
                },
                _onSubmit: function(e, t) {},
                _onSubmitCallbackSuccess: function(e, t) {
                    this._onSubmit.apply(this, arguments), this._uploadData.setStatus(e, qq.status.SUBMITTED), this._onSubmitted.apply(this, arguments), this._options.autoUpload ? (this._options.callbacks.onSubmitted.apply(this, arguments), this._uploadFile(e)) : (this._storeForLater(e), this._options.callbacks.onSubmitted.apply(this, arguments))
                },
                _onSubmitDelete: function(e, t, n) {
                    var i, o = this.getUuid(e);
                    return t && (i = qq.bind(t, this, e, o, n)), this._isDeletePossible() ? (this._handleCheckedCallback({
                        name: "onSubmitDelete",
                        callback: qq.bind(this._options.callbacks.onSubmitDelete, this, e),
                        onSuccess: i || qq.bind(this._deleteHandler.sendDelete, this, e, o, n),
                        identifier: e
                    }), !0) : (this.log("Delete request ignored for ID " + e + ", delete feature is disabled or request not possible due to CORS on a user agent that does not support pre-flighting.", "warn"), !1)
                },
                _onSubmitted: function(e) {},
                _onTotalProgress: function(e, t) {
                    this._options.callbacks.onTotalProgress(e, t)
                },
                _onUploadPrep: function(e) {},
                _onUpload: function(e, t) {
                    this._uploadData.setStatus(e, qq.status.UPLOADING)
                },
                _onUploadChunk: function(e, t) {},
                _onUploadStatusChange: function(e, t, n) {
                    n === qq.status.PAUSED && clearTimeout(this._retryTimeouts[e])
                },
                _onValidateBatchCallbackFailure: function(e) {
                    var t = this;
                    qq.each(e, function(e, n) {
                        t._fileOrBlobRejected(n.id)
                    })
                },
                _onValidateBatchCallbackSuccess: function(e, t, n, i, o) {
                    var r, a = this._currentItemLimit,
                        s = this._netUploadedOrQueued;
                    0 === a || s <= a ? t.length > 0 ? this._handleCheckedCallback({
                        name: "onValidate",
                        callback: qq.bind(this._options.callbacks.onValidate, this, e[0], o),
                        onSuccess: qq.bind(this._onValidateCallbackSuccess, this, t, 0, n, i),
                        onFailure: qq.bind(this._onValidateCallbackFailure, this, t, 0, n, i),
                        identifier: "Item '" + t[0].file.name + "', size: " + t[0].file.size
                    }) : this._itemError("noFilesError") : (this._onValidateBatchCallbackFailure(t), r = this._options.messages.tooManyItemsError.replace(/\{netItems\}/g, s).replace(/\{itemLimit\}/g, a), this._batchError(r))
                },
                _onValidateCallbackFailure: function(e, t, n, i) {
                    var o = t + 1;
                    this._fileOrBlobRejected(e[t].id, e[t].file.name), this._maybeProcessNextItemAfterOnValidateCallback(!1, e, o, n, i)
                },
                _onValidateCallbackSuccess: function(e, t, n, i) {
                    var o = this,
                        r = t + 1,
                        a = this._getValidationDescriptor(e[t]);
                    this._validateFileOrBlobData(e[t], a).then(function() {
                        o._upload(e[t].id, n, i), o._maybeProcessNextItemAfterOnValidateCallback(!0, e, r, n, i)
                    }, function() {
                        o._maybeProcessNextItemAfterOnValidateCallback(!1, e, r, n, i)
                    })
                },
                _prepareItemsForUpload: function(e, t, n) {
                    if (0 === e.length) return void this._itemError("noFilesError");
                    var i = this._getValidationDescriptors(e),
                        o = this._getButtonId(e[0].file),
                        r = this._getButton(o);
                    this._handleCheckedCallback({
                        name: "onValidateBatch",
                        callback: qq.bind(this._options.callbacks.onValidateBatch, this, i, r),
                        onSuccess: qq.bind(this._onValidateBatchCallbackSuccess, this, i, e, t, n, r),
                        onFailure: qq.bind(this._onValidateBatchCallbackFailure, this, e),
                        identifier: "batch validation"
                    })
                },
                _preventLeaveInProgress: function() {
                    var e = this;
                    this._disposeSupport.attach(window, "beforeunload", function(t) {
                        if (e.getInProgress()) return t = t || window.event, t.returnValue = e._options.messages.onLeave, e._options.messages.onLeave
                    })
                },
                _refreshSessionData: function() {
                    var e = this,
                        t = this._options.session;
                    qq.Session && null != this._options.session.endpoint && (this._session || (qq.extend(t, {
                        cors: this._options.cors
                    }), t.log = qq.bind(this.log, this), t.addFileRecord = qq.bind(this._addCannedFile, this), this._session = new qq.Session(t)), setTimeout(function() {
                        e._session.refresh().then(function(t, n) {
                            e._sessionRequestComplete(), e._options.callbacks.onSessionRequestComplete(t, !0, n)
                        }, function(t, n) {
                            e._options.callbacks.onSessionRequestComplete(t, !1, n)
                        })
                    }, 0))
                },
                _sessionRequestComplete: function() {},
                _setSize: function(e, t) {
                    this._uploadData.updateSize(e, t), this._totalProgress && this._totalProgress.onNewSize(e)
                },
                _shouldAutoRetry: function(e, t, n) {
                    var i = this._uploadData.retrieve({
                        id: e
                    });
                    return !!(!this._preventRetries[e] && this._options.retry.enableAuto && i.status !== qq.status.PAUSED && (void 0 === this._autoRetries[e] && (this._autoRetries[e] = 0), this._autoRetries[e] < this._options.retry.maxAutoAttempts)) && (this._autoRetries[e] += 1, !0)
                },
                _storeForLater: function(e) {
                    this._storedIds.push(e)
                },
                _trackButton: function(e) {
                    var t;
                    t = qq.supportedFeatures.ajaxUploading ? this._handler.getFile(e).qqButtonId : this._getButtonId(this._handler.getInput(e)), t && (this._buttonIdsForFileIds[e] = t)
                },
                _updateFormSupportAndParams: function(e) {
                    this._options.form.element = e, this._formSupport = qq.FormSupport && new qq.FormSupport(this._options.form, qq.bind(this.uploadStoredFiles, this), qq.bind(this.log, this)), this._formSupport && this._formSupport.attachedToForm && (this._paramsStore.addReadOnly(null, this._formSupport.getFormInputsAsObject), this._options.autoUpload = this._formSupport.newAutoUpload, this._formSupport.newEndpoint && this.setEndpoint(this._formSupport.newEndpoint))
                },
                _upload: function(e, t, n) {
                    var i = this.getName(e);
                    t && this.setParams(t, e), n && this.setEndpoint(n, e), this._handleCheckedCallback({
                        name: "onSubmit",
                        callback: qq.bind(this._options.callbacks.onSubmit, this, e, i),
                        onSuccess: qq.bind(this._onSubmitCallbackSuccess, this, e, i),
                        onFailure: qq.bind(this._fileOrBlobRejected, this, e, i),
                        identifier: e
                    })
                },
                _uploadFile: function(e) {
                    this._handler.upload(e) || this._uploadData.setStatus(e, qq.status.QUEUED)
                },
                _uploadStoredFiles: function() {
                    for (var e, t, n = this; this._storedIds.length;) e = this._storedIds.shift(), this._uploadFile(e);
                    t = this.getUploads({
                        status: qq.status.SUBMITTING
                    }).length, t && (qq.log("Still waiting for " + t + " files to clear submit queue. Will re-parse stored IDs array shortly."), setTimeout(function() {
                        n._uploadStoredFiles()
                    }, 1e3))
                },
                _validateFileOrBlobData: function(e, t) {
                    var n = this,
                        i = function() {
                            return e.file instanceof qq.BlobProxy ? e.file.referenceBlob : e.file
                        }(),
                        o = t.name,
                        r = t.size,
                        a = this._getButtonId(e.file),
                        s = this._getValidationBase(a),
                        l = new qq.Promise;
                    return l.then(function() {}, function() {
                        n._fileOrBlobRejected(e.id, o)
                    }), qq.isFileOrInput(i) && !this._isAllowedExtension(s.allowedExtensions, o) ? (this._itemError("typeError", o, i), l.failure()) : 0 === r ? (this._itemError("emptyError", o, i), l.failure()) : r > 0 && s.sizeLimit && r > s.sizeLimit ? (this._itemError("sizeError", o, i), l.failure()) : r > 0 && r < s.minSizeLimit ? (this._itemError("minSizeError", o, i), l.failure()) : (qq.ImageValidation && qq.supportedFeatures.imagePreviews && qq.isFile(i) ? new qq.ImageValidation(i, qq.bind(n.log, n)).validate(s.image).then(l.success, function(e) {
                        n._itemError(e + "ImageError", o, i), l.failure()
                    }) : l.success(), l)
                },
                _wrapCallbacks: function() {
                    var e, t, n;
                    e = this, t = function(t, n, i) {
                        var o;
                        try {
                            return n.apply(e, i)
                        } catch (n) {
                            o = n.message || n.toString(), e.log("Caught exception in '" + t + "' callback - " + o, "error")
                        }
                    };
                    for (n in this._options.callbacks) ! function() {
                        var i, o;
                        i = n, o = e._options.callbacks[i], e._options.callbacks[i] = function() {
                            return t(i, o, arguments)
                        }
                    }()
                }
            }
        }(),
        function() {
            "use strict";
            qq.FineUploaderBasic = function(e) {
                var t = this;
                this._options = {
                    debug: !1,
                    button: null,
                    multiple: !0,
                    maxConnections: 3,
                    disableCancelForFormUploads: !1,
                    autoUpload: !0,
                    request: {
                        customHeaders: {},
                        endpoint: "/server/upload",
                        filenameParam: "qqfilename",
                        forceMultipart: !0,
                        inputName: "qqfile",
                        method: "POST",
                        params: {},
                        paramsInBody: !0,
                        totalFileSizeName: "qqtotalfilesize",
                        uuidName: "qquuid"
                    },
                    validation: {
                        allowedExtensions: [],
                        sizeLimit: 0,
                        minSizeLimit: 0,
                        itemLimit: 0,
                        stopOnFirstInvalidFile: !0,
                        acceptFiles: null,
                        image: {
                            maxHeight: 0,
                            maxWidth: 0,
                            minHeight: 0,
                            minWidth: 0
                        }
                    },
                    callbacks: {
                        onSubmit: function(e, t) {},
                        onSubmitted: function(e, t) {},
                        onComplete: function(e, t, n, i) {},
                        onAllComplete: function(e, t) {},
                        onCancel: function(e, t) {},
                        onUpload: function(e, t) {},
                        onUploadChunk: function(e, t, n) {},
                        onUploadChunkSuccess: function(e, t, n, i) {},
                        onResume: function(e, t, n) {},
                        onProgress: function(e, t, n, i) {},
                        onTotalProgress: function(e, t) {},
                        onError: function(e, t, n, i) {},
                        onAutoRetry: function(e, t, n) {},
                        onManualRetry: function(e, t) {},
                        onValidateBatch: function(e) {},
                        onValidate: function(e) {},
                        onSubmitDelete: function(e) {},
                        onDelete: function(e) {},
                        onDeleteComplete: function(e, t, n) {},
                        onPasteReceived: function(e) {},
                        onStatusChange: function(e, t, n) {},
                        onSessionRequestComplete: function(e, t, n) {}
                    },
                    messages: {
                        typeError: "{file} has an invalid extension. Valid extension(s): {extensions}.",
                        sizeError: "{file} is too large, maximum file size is {sizeLimit}.",
                        minSizeError: "{file} is too small, minimum file size is {minSizeLimit}.",
                        emptyError: "{file} is empty, please select files again without it.",
                        noFilesError: "No files to upload.",
                        tooManyItemsError: "Too many items ({netItems}) would be uploaded.  Item limit is {itemLimit}.",
                        maxHeightImageError: "Image is too tall.",
                        maxWidthImageError: "Image is too wide.",
                        minHeightImageError: "Image is not tall enough.",
                        minWidthImageError: "Image is not wide enough.",
                        retryFailTooManyItems: "Retry failed - you have reached your file limit.",
                        onLeave: "The files are being uploaded, if you leave now the upload will be canceled.",
                        unsupportedBrowserIos8Safari: "Unrecoverable error - this browser does not permit file uploading of any kind due to serious bugs in iOS8 Safari.  Please use iOS8 Chrome until Apple fixes these issues."
                    },
                    retry: {
                        enableAuto: !1,
                        maxAutoAttempts: 3,
                        autoAttemptDelay: 5,
                        preventRetryResponseProperty: "preventRetry"
                    },
                    classes: {
                        buttonHover: "qq-upload-button-hover",
                        buttonFocus: "qq-upload-button-focus"
                    },
                    chunking: {
                        enabled: !1,
                        concurrent: {
                            enabled: !1
                        },
                        mandatory: !1,
                        paramNames: {
                            partIndex: "qqpartindex",
                            partByteOffset: "qqpartbyteoffset",
                            chunkSize: "qqchunksize",
                            totalFileSize: "qqtotalfilesize",
                            totalParts: "qqtotalparts"
                        },
                        partSize: 2e6,
                        success: {
                            endpoint: null
                        }
                    },
                    resume: {
                        enabled: !1,
                        recordsExpireIn: 7,
                        paramNames: {
                            resuming: "qqresume"
                        }
                    },
                    formatFileName: function(e) {
                        return e
                    },
                    text: {
                        defaultResponseError: "Upload failure reason unknown",
                        fileInputTitle: "file input",
                        sizeSymbols: ["kB", "MB", "GB", "TB", "PB", "EB"]
                    },
                    deleteFile: {
                        enabled: !1,
                        method: "DELETE",
                        endpoint: "/server/upload",
                        customHeaders: {},
                        params: {}
                    },
                    cors: {
                        expected: !1,
                        sendCredentials: !1,
                        allowXdr: !1
                    },
                    blobs: {
                        defaultName: "misc_data"
                    },
                    paste: {
                        targetElement: null,
                        defaultName: "pasted_image"
                    },
                    camera: {
                        ios: !1,
                        button: null
                    },
                    extraButtons: [],
                    session: {
                        endpoint: null,
                        params: {},
                        customHeaders: {},
                        refreshOnReset: !0
                    },
                    form: {
                        element: "qq-form",
                        autoUpload: !1,
                        interceptSubmit: !0
                    },
                    scaling: {
                        customResizer: null,
                        sendOriginal: !0,
                        orient: !0,
                        defaultType: null,
                        defaultQuality: 80,
                        failureText: "Failed to scale",
                        includeExif: !1,
                        sizes: []
                    },
                    workarounds: {
                        iosEmptyVideos: !0,
                        ios8SafariUploads: !0,
                        ios8BrowserCrash: !1
                    }
                }, qq.extend(this._options, e, !0), this._buttons = [], this._extraButtonSpecs = {}, this._buttonIdsForFileIds = [], this._wrapCallbacks(), this._disposeSupport = new qq.DisposeSupport, this._storedIds = [], this._autoRetries = [], this._retryTimeouts = [], this._preventRetries = [], this._thumbnailUrls = [], this._netUploadedOrQueued = 0, this._netUploaded = 0, this._uploadData = this._createUploadDataTracker(), this._initFormSupportAndParams(), this._customHeadersStore = this._createStore(this._options.request.customHeaders), this._deleteFileCustomHeadersStore = this._createStore(this._options.deleteFile.customHeaders), this._deleteFileParamsStore = this._createStore(this._options.deleteFile.params), this._endpointStore = this._createStore(this._options.request.endpoint), this._deleteFileEndpointStore = this._createStore(this._options.deleteFile.endpoint), this._handler = this._createUploadHandler(), this._deleteHandler = qq.DeleteFileAjaxRequester && this._createDeleteHandler(), this._options.button && (this._defaultButtonId = this._createUploadButton({
                    element: this._options.button,
                    title: this._options.text.fileInputTitle
                }).getButtonId()), this._generateExtraButtonSpecs(), this._handleCameraAccess(), this._options.paste.targetElement && (qq.PasteSupport ? this._pasteHandler = this._createPasteHandler() : this.log("Paste support module not found", "error")), this._preventLeaveInProgress(), this._imageGenerator = qq.ImageGenerator && new qq.ImageGenerator(qq.bind(this.log, this)), this._refreshSessionData(), this._succeededSinceLastAllComplete = [], this._failedSinceLastAllComplete = [], this._scaler = qq.Scaler && new qq.Scaler(this._options.scaling, qq.bind(this.log, this)) || {}, this._scaler.enabled && (this._customNewFileHandler = qq.bind(this._scaler.handleNewFile, this._scaler)), qq.TotalProgress && qq.supportedFeatures.progressBar && (this._totalProgress = new qq.TotalProgress(qq.bind(this._onTotalProgress, this), function(e) {
                    var n = t._uploadData.retrieve({
                        id: e
                    });
                    return n && n.size || 0
                })), this._currentItemLimit = this._options.validation.itemLimit
            }, qq.FineUploaderBasic.prototype = qq.basePublicApi, qq.extend(qq.FineUploaderBasic.prototype, qq.basePrivateApi)
        }(), qq.AjaxRequester = function(e) {
            "use strict";

            function t() {
                return qq.indexOf(["GET", "POST", "HEAD"], S.method) >= 0
            }

            function n(e) {
                var t = !1;
                return qq.each(t, function(e, n) {
                    if (qq.indexOf(["Accept", "Accept-Language", "Content-Language", "Content-Type"], n) < 0) return t = !0, !1
                }), t
            }

            function i(e) {
                return S.cors.expected && void 0 === e.withCredentials
            }

            function o() {
                var e;
                return (window.XMLHttpRequest || window.ActiveXObject) && (e = qq.createXhrInstance(), void 0 === e.withCredentials && (e = new XDomainRequest, e.onload = function() {}, e.onerror = function() {}, e.ontimeout = function() {}, e.onprogress = function() {})), e
            }

            function r(e, t) {
                var n = y[e].xhr;
                return n || (n = t ? t : S.cors.expected ? o() : qq.createXhrInstance(), y[e].xhr = n), n
            }

            function a(e) {
                var t, n = qq.indexOf(b, e),
                    i = S.maxConnections;
                delete y[e], b.splice(n, 1), b.length >= i && n < i && (t = b[i - 1], u(t))
            }

            function s(e, t) {
                var n = r(e),
                    o = S.method,
                    s = t === !0;
                a(e), s ? _(o + " request for " + e + " has failed", "error") : i(n) || m(n.status) || (s = !0, _(o + " request for " + e + " has failed - response code " + n.status, "error")), S.onComplete(e, n, s)
            }

            function l(e) {
                var t, n = y[e].additionalParams,
                    i = S.mandatedParams;
                return S.paramsStore.get && (t = S.paramsStore.get(e)), n && qq.each(n, function(e, n) {
                    t = t || {}, t[e] = n
                }), i && qq.each(i, function(e, n) {
                    t = t || {}, t[e] = n
                }), t
            }

            function u(e, t) {
                var n, o = r(e, t),
                    a = S.method,
                    s = l(e),
                    u = y[e].payload;
                return S.onSend(e), n = c(e, s, y[e].additionalQueryParams), i(o) ? (o.onload = h(e), o.onerror = f(e)) : o.onreadystatechange = d(e), p(e), o.open(a, n, !0), S.cors.expected && S.cors.sendCredentials && !i(o) && (o.withCredentials = !0), q(e), _("Sending " + a + " request for " + e), u ? o.send(u) : v || !s ? o.send() : s && S.contentType && S.contentType.toLowerCase().indexOf("application/x-www-form-urlencoded") >= 0 ? o.send(qq.obj2url(s, "")) : s && S.contentType && S.contentType.toLowerCase().indexOf("application/json") >= 0 ? o.send(JSON.stringify(s)) : o.send(s), o
            }

            function c(e, t, n) {
                var i = S.endpointStore.get(e),
                    o = y[e].addToPath;
                return void 0 != o && (i += "/" + o), v && t && (i = qq.obj2url(t, i)), n && (i = qq.obj2url(n, i)), i
            }

            function d(e) {
                return function() {
                    4 === r(e).readyState && s(e)
                }
            }

            function p(e) {
                var t = S.onProgress;
                t && (r(e).upload.onprogress = function(n) {
                    n.lengthComputable && t(e, n.loaded, n.total)
                })
            }

            function h(e) {
                return function() {
                    s(e)
                }
            }

            function f(e) {
                return function() {
                    s(e, !0)
                }
            }

            function q(e) {
                var o = r(e),
                    a = S.customHeaders,
                    s = y[e].additionalHeaders || {},
                    l = S.method,
                    u = {};
                i(o) || (S.acceptHeader && o.setRequestHeader("Accept", S.acceptHeader), S.allowXRequestedWithAndCacheControl && (S.cors.expected && t() && !n(a) || (o.setRequestHeader("X-Requested-With", "XMLHttpRequest"), o.setRequestHeader("Cache-Control", "no-cache"))), !S.contentType || "POST" !== l && "PUT" !== l || o.setRequestHeader("Content-Type", S.contentType), qq.extend(u, qq.isFunction(a) ? a(e) : a), qq.extend(u, s), qq.each(u, function(e, t) {
                    o.setRequestHeader(e, t)
                }))
            }

            function m(e) {
                return qq.indexOf(S.successfulResponseCodes[S.method], e) >= 0
            }

            function g(e, t, n, i, o, r, a) {
                y[e] = {
                    addToPath: n,
                    additionalParams: i,
                    additionalQueryParams: o,
                    additionalHeaders: r,
                    payload: a
                };
                var s = b.push(e);
                if (s <= S.maxConnections) return u(e, t)
            }
            var _, v, b = [],
                y = {},
                S = {
                    acceptHeader: null,
                    validMethods: ["PATCH", "POST", "PUT"],
                    method: "POST",
                    contentType: "application/x-www-form-urlencoded",
                    maxConnections: 3,
                    customHeaders: {},
                    endpointStore: {},
                    paramsStore: {},
                    mandatedParams: {},
                    allowXRequestedWithAndCacheControl: !0,
                    successfulResponseCodes: {
                        DELETE: [200, 202, 204],
                        PATCH: [200, 201, 202, 203, 204],
                        POST: [200, 201, 202, 203, 204],
                        PUT: [200, 201, 202, 203, 204],
                        GET: [200]
                    },
                    cors: {
                        expected: !1,
                        sendCredentials: !1
                    },
                    log: function(e, t) {},
                    onSend: function(e) {},
                    onComplete: function(e, t, n) {},
                    onProgress: null
                };
            if (qq.extend(S, e), _ = S.log, qq.indexOf(S.validMethods, S.method) < 0) throw new Error("'" + S.method + "' is not a supported method for this type of request!");
            v = "GET" === S.method || "DELETE" === S.method, qq.extend(this, {
                initTransport: function(e) {
                    var t, n, i, o, r, a;
                    return {
                        withPath: function(e) {
                            return t = e, this
                        },
                        withParams: function(e) {
                            return n = e, this
                        },
                        withQueryParams: function(e) {
                            return a = e, this
                        },
                        withHeaders: function(e) {
                            return i = e, this
                        },
                        withPayload: function(e) {
                            return o = e, this
                        },
                        withCacheBuster: function() {
                            return r = !0, this
                        },
                        send: function(s) {
                            return r && qq.indexOf(["GET", "DELETE"], S.method) >= 0 && (n.qqtimestamp = (new Date).getTime()), g(e, s, t, n, a, i, o)
                        }
                    }
                },
                canceled: function(e) {
                    a(e)
                }
            })
        }, qq.UploadHandler = function(e) {
            "use strict";
            var t = e.proxy,
                n = {},
                i = t.onCancel,
                o = t.getName;
            qq.extend(this, {
                add: function(e, t) {
                    n[e] = t, n[e].temp = {}
                },
                cancel: function(e) {
                    var t = this,
                        r = new qq.Promise,
                        a = i(e, o(e), r);
                    a.then(function() {
                        t.isValid(e) && (n[e].canceled = !0, t.expunge(e)), r.success()
                    })
                },
                expunge: function(e) {
                    delete n[e]
                },
                getThirdPartyFileId: function(e) {
                    return n[e].key
                },
                isValid: function(e) {
                    return void 0 !== n[e]
                },
                reset: function() {
                    n = {}
                },
                _getFileState: function(e) {
                    return n[e]
                },
                _setThirdPartyFileId: function(e, t) {
                    n[e].key = t
                },
                _wasCanceled: function(e) {
                    return !!n[e].canceled
                }
            })
        }, qq.UploadHandlerController = function(e, t) {
            "use strict";
            var n, i, o, r = this,
                a = !1,
                s = !1,
                l = {
                    paramsStore: {},
                    maxConnections: 3,
                    chunking: {
                        enabled: !1,
                        multiple: {
                            enabled: !1
                        }
                    },
                    log: function(e, t) {},
                    onProgress: function(e, t, n, i) {},
                    onComplete: function(e, t, n, i) {},
                    onCancel: function(e, t) {},
                    onUploadPrep: function(e) {},
                    onUpload: function(e, t) {},
                    onUploadChunk: function(e, t, n) {},
                    onUploadChunkSuccess: function(e, t, n, i) {},
                    onAutoRetry: function(e, t, n, i) {},
                    onResume: function(e, t, n) {},
                    onUuidChanged: function(e, t) {},
                    getName: function(e) {},
                    setSize: function(e, t) {},
                    isQueued: function(e) {},
                    getIdsInProxyGroup: function(e) {},
                    getIdsInBatch: function(e) {}
                },
                u = {
                    done: function(e, t, n, i) {
                        var r = o._getChunkData(e, t);
                        o._getFileState(e).attemptingResume = !1, delete o._getFileState(e).temp.chunkProgress[t], o._getFileState(e).loaded += r.size, l.onUploadChunkSuccess(e, o._getChunkDataForCallback(r), n, i)
                    },
                    finalize: function(e) {
                        var t = l.getSize(e),
                            n = l.getName(e);
                        i("All chunks have been uploaded for " + e + " - finalizing...."), o.finalizeChunks(e).then(function(r, a) {
                            i("Finalize successful for " + e);
                            var s = p.normalizeResponse(r, !0);
                            l.onProgress(e, n, t, t), o._maybeDeletePersistedChunkData(e), p.cleanup(e, s, a)
                        }, function(t, o) {
                            var r = p.normalizeResponse(t, !1);
                            i("Problem finalizing chunks for file ID " + e + " - " + r.error, "error"), r.reset && u.reset(e), l.onAutoRetry(e, n, r, o) || p.cleanup(e, r, o)
                        })
                    },
                    hasMoreParts: function(e) {
                        return !!o._getFileState(e).chunking.remaining.length
                    },
                    nextPart: function(e) {
                        var t = o._getFileState(e).chunking.remaining.shift();
                        return t >= o._getTotalChunks(e) && (t = null), t
                    },
                    reset: function(e) {
                        i("Server or callback has ordered chunking effort to be restarted on next attempt for item ID " + e, "error"), o._maybeDeletePersistedChunkData(e), o.reevaluateChunking(e), o._getFileState(e).loaded = 0
                    },
                    sendNext: function(e) {
                        var t = l.getSize(e),
                            n = l.getName(e),
                            r = u.nextPart(e),
                            a = o._getChunkData(e, r),
                            d = o._getFileState(e).attemptingResume,
                            h = o._getFileState(e).chunking.inProgress || [];
                        null == o._getFileState(e).loaded && (o._getFileState(e).loaded = 0), d && l.onResume(e, n, a) === !1 && (u.reset(e), r = u.nextPart(e), a = o._getChunkData(e, r), d = !1), null == r && 0 === h.length ? u.finalize(e) : (i(qq.format("Sending chunked upload request for item {}.{}, bytes {}-{} of {}.", e, r, a.start + 1, a.end, t)), l.onUploadChunk(e, n, o._getChunkDataForCallback(a)), h.push(r), o._getFileState(e).chunking.inProgress = h, s && c.open(e, r), s && c.available() && o._getFileState(e).chunking.remaining.length && u.sendNext(e), o.uploadChunk(e, r, d).then(function(t, n) {
                            i("Chunked upload request succeeded for " + e + ", chunk " + r), o.clearCachedChunk(e, r);
                            var a = o._getFileState(e).chunking.inProgress || [],
                                s = p.normalizeResponse(t, !0),
                                l = qq.indexOf(a, r);
                            i(qq.format("Chunk {} for file {} uploaded successfully.", r, e)), u.done(e, r, s, n), l >= 0 && a.splice(l, 1), o._maybePersistChunkedState(e), u.hasMoreParts(e) || 0 !== a.length ? u.hasMoreParts(e) ? u.sendNext(e) : i(qq.format("File ID {} has no more chunks to send and these chunk indexes are still marked as in-progress: {}", e, JSON.stringify(a))) : u.finalize(e)
                        }, function(t, a) {
                            i("Chunked upload request failed for " + e + ", chunk " + r), o.clearCachedChunk(e, r);
                            var d, h = p.normalizeResponse(t, !1);
                            h.reset ? u.reset(e) : (d = qq.indexOf(o._getFileState(e).chunking.inProgress, r), d >= 0 && (o._getFileState(e).chunking.inProgress.splice(d, 1), o._getFileState(e).chunking.remaining.unshift(r))), o._getFileState(e).temp.ignoreFailure || (s && (o._getFileState(e).temp.ignoreFailure = !0, i(qq.format("Going to attempt to abort these chunks: {}. These are currently in-progress: {}.", JSON.stringify(Object.keys(o._getXhrs(e))), JSON.stringify(o._getFileState(e).chunking.inProgress))), qq.each(o._getXhrs(e), function(t, n) {
                                i(qq.format("Attempting to abort file {}.{}. XHR readyState {}. ", e, t, n.readyState)), n.abort(), n._cancelled = !0
                            }), o.moveInProgressToRemaining(e), c.free(e, !0)), l.onAutoRetry(e, n, h, a) || p.cleanup(e, h, a))
                        }).done(function() {
                            o.clearXhr(e, r)
                        }))
                    }
                },
                c = {
                    _open: [],
                    _openChunks: {},
                    _waiting: [],
                    available: function() {
                        var e = l.maxConnections,
                            t = 0,
                            n = 0;
                        return qq.each(c._openChunks, function(e, i) {
                            t++, n += i.length
                        }), e - (c._open.length - t + n)
                    },
                    free: function(e, t) {
                        var n, r = !t,
                            a = qq.indexOf(c._waiting, e),
                            s = qq.indexOf(c._open, e);
                        delete c._openChunks[e], p.getProxyOrBlob(e) instanceof qq.BlobProxy && (i("Generated blob upload has ended for " + e + ", disposing generated blob."), delete o._getFileState(e).file), a >= 0 ? c._waiting.splice(a, 1) : r && s >= 0 && (c._open.splice(s, 1), n = c._waiting.shift(), n >= 0 && (c._open.push(n), p.start(n)))
                    },
                    getWaitingOrConnected: function() {
                        var e = [];
                        return qq.each(c._openChunks, function(t, n) {
                            n && n.length && e.push(parseInt(t))
                        }), qq.each(c._open, function(t, n) {
                            c._openChunks[n] || e.push(parseInt(n))
                        }), e = e.concat(c._waiting)
                    },
                    isUsingConnection: function(e) {
                        return qq.indexOf(c._open, e) >= 0
                    },
                    open: function(e, t) {
                        return null == t && c._waiting.push(e), !!c.available() && (null == t ? (c._waiting.pop(), c._open.push(e)) : ! function() {
                            var n = c._openChunks[e] || [];
                            n.push(t), c._openChunks[e] = n
                        }(), !0)
                    },
                    reset: function() {
                        c._waiting = [], c._open = []
                    }
                },
                d = {
                    send: function(e, t) {
                        o._getFileState(e).loaded = 0, i("Sending simple upload request for " + e), o.uploadFile(e).then(function(n, o) {
                            i("Simple upload request succeeded for " + e);
                            var r = p.normalizeResponse(n, !0),
                                a = l.getSize(e);
                            l.onProgress(e, t, a, a), p.maybeNewUuid(e, r), p.cleanup(e, r, o)
                        }, function(n, o) {
                            i("Simple upload request failed for " + e);
                            var r = p.normalizeResponse(n, !1);
                            l.onAutoRetry(e, t, r, o) || p.cleanup(e, r, o)
                        })
                    }
                },
                p = {
                    cancel: function(e) {
                        i("Cancelling " + e), l.paramsStore.remove(e), c.free(e)
                    },
                    cleanup: function(e, t, n) {
                        var i = l.getName(e);
                        l.onComplete(e, i, t, n), o._getFileState(e) && o._clearXhrs && o._clearXhrs(e), c.free(e)
                    },
                    getProxyOrBlob: function(e) {
                        return o.getProxy && o.getProxy(e) || o.getFile && o.getFile(e)
                    },
                    initHandler: function() {
                        var e = t ? qq[t] : qq.traditional,
                            n = qq.supportedFeatures.ajaxUploading ? "Xhr" : "Form";
                        o = new e[n + "UploadHandler"](l, {
                            getDataByUuid: l.getDataByUuid,
                            getName: l.getName,
                            getSize: l.getSize,
                            getUuid: l.getUuid,
                            log: i,
                            onCancel: l.onCancel,
                            onProgress: l.onProgress,
                            onUuidChanged: l.onUuidChanged
                        }), o._removeExpiredChunkingRecords && o._removeExpiredChunkingRecords()
                    },
                    isDeferredEligibleForUpload: function(e) {
                        return l.isQueued(e)
                    },
                    maybeDefer: function(e, t) {
                        return t && !o.getFile(e) && t instanceof qq.BlobProxy ? (l.onUploadPrep(e), i("Attempting to generate a blob on-demand for " + e), t.create().then(function(t) {
                            i("Generated an on-demand blob for " + e), o.updateBlob(e, t),
                                l.setSize(e, t.size), o.reevaluateChunking(e), p.maybeSendDeferredFiles(e)
                        }, function(t) {
                            var o = {};
                            t && (o.error = t), i(qq.format("Failed to generate blob for ID {}.  Error message: {}.", e, t), "error"), l.onComplete(e, l.getName(e), qq.extend(o, n), null), p.maybeSendDeferredFiles(e), c.free(e)
                        }), !1) : p.maybeSendDeferredFiles(e)
                    },
                    maybeSendDeferredFiles: function(e) {
                        var t = l.getIdsInProxyGroup(e),
                            n = !1;
                        return t && t.length ? (i("Maybe ready to upload proxy group file " + e), qq.each(t, function(t, i) {
                            if (p.isDeferredEligibleForUpload(i) && o.getFile(i)) n = i === e, p.now(i);
                            else if (p.isDeferredEligibleForUpload(i)) return !1
                        })) : (n = !0, p.now(e)), n
                    },
                    maybeNewUuid: function(e, t) {
                        void 0 !== t.newUuid && l.onUuidChanged(e, t.newUuid)
                    },
                    normalizeResponse: function(e, t) {
                        var n = e;
                        return qq.isObject(e) || (n = {}, qq.isString(e) && !t && (n.error = e)), n.success = t, n
                    },
                    now: function(e) {
                        var t = l.getName(e);
                        if (!r.isValid(e)) throw new qq.Error(e + " is not a valid file ID to upload!");
                        l.onUpload(e, t), a && o._shouldChunkThisFile(e) ? u.sendNext(e) : d.send(e, t)
                    },
                    start: function(e) {
                        var t = p.getProxyOrBlob(e);
                        return t ? p.maybeDefer(e, t) : (p.now(e), !0)
                    }
                };
            qq.extend(this, {
                add: function(e, t) {
                    o.add.apply(this, arguments)
                },
                upload: function(e) {
                    return !!c.open(e) && p.start(e)
                },
                retry: function(e) {
                    return s && (o._getFileState(e).temp.ignoreFailure = !1), c.isUsingConnection(e) ? p.start(e) : r.upload(e)
                },
                cancel: function(e) {
                    var t = o.cancel(e);
                    qq.isGenericPromise(t) ? t.then(function() {
                        p.cancel(e)
                    }) : t !== !1 && p.cancel(e)
                },
                cancelAll: function() {
                    var e, t = c.getWaitingOrConnected();
                    if (t.length)
                        for (e = t.length - 1; e >= 0; e--) r.cancel(t[e]);
                    c.reset()
                },
                getFile: function(e) {
                    return o.getProxy && o.getProxy(e) ? o.getProxy(e).referenceBlob : o.getFile && o.getFile(e)
                },
                isProxied: function(e) {
                    return !(!o.getProxy || !o.getProxy(e))
                },
                getInput: function(e) {
                    if (o.getInput) return o.getInput(e)
                },
                reset: function() {
                    i("Resetting upload handler"), r.cancelAll(), c.reset(), o.reset()
                },
                expunge: function(e) {
                    if (r.isValid(e)) return o.expunge(e)
                },
                isValid: function(e) {
                    return o.isValid(e)
                },
                getResumableFilesData: function() {
                    return o.getResumableFilesData ? o.getResumableFilesData() : []
                },
                getThirdPartyFileId: function(e) {
                    if (r.isValid(e)) return o.getThirdPartyFileId(e)
                },
                pause: function(e) {
                    return !!(r.isResumable(e) && o.pause && r.isValid(e) && o.pause(e)) && (c.free(e), o.moveInProgressToRemaining(e), !0)
                },
                isResumable: function(e) {
                    return !!o.isResumable && o.isResumable(e)
                }
            }), qq.extend(l, e), i = l.log, a = l.chunking.enabled && qq.supportedFeatures.chunking, s = a && l.chunking.concurrent.enabled, n = function() {
                var e = {};
                return e[l.preventRetryParam] = !0, e
            }(), p.initHandler()
        }, qq.WindowReceiveMessage = function(e) {
            "use strict";
            var t = {
                    log: function(e, t) {}
                },
                n = {};
            qq.extend(t, e), qq.extend(this, {
                receiveMessage: function(e, t) {
                    var i = function(e) {
                        t(e.data)
                    };
                    window.postMessage ? n[e] = qq(window).attach("message", i) : log("iframe message passing not supported in this browser!", "error")
                },
                stopReceivingMessages: function(e) {
                    if (window.postMessage) {
                        var t = n[e];
                        t && t()
                    }
                }
            })
        }, qq.FormUploadHandler = function(e) {
            "use strict";

            function t(e) {
                delete c[e], p && (clearTimeout(d[e]), delete d[e], m.stopReceivingMessages(e));
                var t = document.getElementById(a._getIframeName(e));
                t && (t.setAttribute("src", "javascript:false;"), qq(t).remove())
            }

            function n(e) {
                return e.split("_")[0]
            }

            function i(e) {
                var t = qq.toElement("<iframe src='javascript:false;' name='" + e + "' />");
                return t.setAttribute("id", e), t.style.display = "none", document.body.appendChild(t), t
            }

            function o(e, t) {
                var i = e.id,
                    o = n(i),
                    r = f(o);
                u[r] = t, c[o] = qq(e).attach("load", function() {
                    a.getInput(o) && (q("Received iframe load event for CORS upload request (iframe name " + i + ")"), d[i] = setTimeout(function() {
                        var e = "No valid message received from loaded iframe for iframe name " + i;
                        q(e, "error"), t({
                            error: e
                        })
                    }, 1e3))
                }), m.receiveMessage(i, function(e) {
                    q("Received the following window message: '" + e + "'");
                    var t, o = (n(i), a._parseJsonResponse(e)),
                        r = o.uuid;
                    r && u[r] ? (q("Handling response for iframe name " + i), clearTimeout(d[i]), delete d[i], a._detachLoadEvent(i), t = u[r], delete u[r], m.stopReceivingMessages(i), t(o)) : r || q("'" + e + "' does not contain a UUID - ignoring.")
                })
            }
            var r = e.options,
                a = this,
                s = e.proxy,
                l = qq.getUniqueId(),
                u = {},
                c = {},
                d = {},
                p = r.isCors,
                h = r.inputName,
                f = s.getUuid,
                q = s.log,
                m = new qq.WindowReceiveMessage({
                    log: q
                });
            qq.extend(this, new qq.UploadHandler(e)), qq.override(this, function(e) {
                return {
                    add: function(t, n) {
                        e.add(t, {
                            input: n
                        }), n.setAttribute("name", h), n.parentNode && qq(n).remove()
                    },
                    expunge: function(n) {
                        t(n), e.expunge(n)
                    },
                    isValid: function(t) {
                        return e.isValid(t) && void 0 !== a._getFileState(t).input
                    }
                }
            }), qq.extend(this, {
                getInput: function(e) {
                    return a._getFileState(e).input
                },
                _attachLoadEvent: function(e, t) {
                    var n;
                    p ? o(e, t) : c[e.id] = qq(e).attach("load", function() {
                        if (q("Received response for " + e.id), e.parentNode) {
                            try {
                                if (e.contentDocument && e.contentDocument.body && "false" == e.contentDocument.body.innerHTML) return
                            } catch (e) {
                                q("Error when attempting to access iframe during handling of upload response (" + e.message + ")", "error"), n = {
                                    success: !1
                                }
                            }
                            t(n)
                        }
                    })
                },
                _createIframe: function(e) {
                    var t = a._getIframeName(e);
                    return i(t)
                },
                _detachLoadEvent: function(e) {
                    void 0 !== c[e] && (c[e](), delete c[e])
                },
                _getIframeName: function(e) {
                    return e + "_" + l
                },
                _initFormForUpload: function(e) {
                    var t = e.method,
                        n = e.endpoint,
                        i = e.params,
                        o = e.paramsInBody,
                        r = e.targetName,
                        a = qq.toElement("<form method='" + t + "' enctype='multipart/form-data'></form>"),
                        s = n;
                    return o ? qq.obj2Inputs(i, a) : s = qq.obj2url(i, n), a.setAttribute("action", s), a.setAttribute("target", r), a.style.display = "none", document.body.appendChild(a), a
                },
                _parseJsonResponse: function(e) {
                    var t = {};
                    try {
                        t = qq.parseJson(e)
                    } catch (e) {
                        q("Error when attempting to parse iframe upload response (" + e.message + ")", "error")
                    }
                    return t
                }
            })
        }, qq.XhrUploadHandler = function(e) {
            "use strict";

            function t(e) {
                qq.each(n._getXhrs(e), function(t, i) {
                    var o = n._getAjaxRequester(e, t);
                    i.onreadystatechange = null, i.upload.onprogress = null, i.abort(), o && o.canceled && o.canceled(e)
                })
            }
            var n = this,
                i = e.options.namespace,
                o = e.proxy,
                r = e.options.chunking,
                a = e.options.resume,
                s = r && e.options.chunking.enabled && qq.supportedFeatures.chunking,
                l = a && e.options.resume.enabled && s && qq.supportedFeatures.resume,
                u = o.getName,
                c = o.getSize,
                d = o.getUuid,
                p = o.getEndpoint,
                h = o.getDataByUuid,
                f = o.onUuidChanged,
                q = o.onProgress,
                m = o.log;
            qq.extend(this, new qq.UploadHandler(e)), qq.override(this, function(e) {
                return {
                    add: function(t, i) {
                        if (qq.isFile(i) || qq.isBlob(i)) e.add(t, {
                            file: i
                        });
                        else {
                            if (!(i instanceof qq.BlobProxy)) throw new Error("Passed obj is not a File, Blob, or proxy");
                            e.add(t, {
                                proxy: i
                            })
                        }
                        n._initTempState(t), l && n._maybePrepareForResume(t)
                    },
                    expunge: function(i) {
                        t(i), n._maybeDeletePersistedChunkData(i), n._clearXhrs(i), e.expunge(i)
                    }
                }
            }), qq.extend(this, {
                clearCachedChunk: function(e, t) {
                    delete n._getFileState(e).temp.cachedChunks[t]
                },
                clearXhr: function(e, t) {
                    var i = n._getFileState(e).temp;
                    i.xhrs && delete i.xhrs[t], i.ajaxRequesters && delete i.ajaxRequesters[t]
                },
                finalizeChunks: function(e, t) {
                    var i = n._getTotalChunks(e) - 1,
                        o = n._getXhr(e, i);
                    return t ? (new qq.Promise).success(t(o), o) : (new qq.Promise).success({}, o)
                },
                getFile: function(e) {
                    return n.isValid(e) && n._getFileState(e).file
                },
                getProxy: function(e) {
                    return n.isValid(e) && n._getFileState(e).proxy
                },
                getResumableFilesData: function() {
                    var e = [];
                    return n._iterateResumeRecords(function(t, i) {
                        n.moveInProgressToRemaining(null, i.chunking.inProgress, i.chunking.remaining);
                        var o = {
                            name: i.name,
                            remaining: i.chunking.remaining,
                            size: i.size,
                            uuid: i.uuid
                        };
                        i.key && (o.key = i.key), e.push(o)
                    }), e
                },
                isResumable: function(e) {
                    return !!r && n.isValid(e) && !n._getFileState(e).notResumable
                },
                moveInProgressToRemaining: function(e, t, i) {
                    var o = t || n._getFileState(e).chunking.inProgress,
                        r = i || n._getFileState(e).chunking.remaining;
                    o && (m(qq.format("Moving these chunks from in-progress {}, to remaining.", JSON.stringify(o))), o.reverse(), qq.each(o, function(e, t) {
                        r.unshift(t)
                    }), o.length = 0)
                },
                pause: function(e) {
                    if (n.isValid(e)) return m(qq.format("Aborting XHR upload for {} '{}' due to pause instruction.", e, u(e))), n._getFileState(e).paused = !0, t(e), !0
                },
                reevaluateChunking: function(e) {
                    if (r && n.isValid(e)) {
                        var t, i, o = n._getFileState(e);
                        if (delete o.chunking, o.chunking = {}, t = n._getTotalChunks(e), t > 1 || r.mandatory) {
                            for (o.chunking.enabled = !0, o.chunking.parts = t, o.chunking.remaining = [], i = 0; i < t; i++) o.chunking.remaining.push(i);
                            n._initTempState(e)
                        } else o.chunking.enabled = !1
                    }
                },
                updateBlob: function(e, t) {
                    n.isValid(e) && (n._getFileState(e).file = t)
                },
                _clearXhrs: function(e) {
                    var t = n._getFileState(e).temp;
                    qq.each(t.ajaxRequesters, function(e) {
                        delete t.ajaxRequesters[e]
                    }), qq.each(t.xhrs, function(e) {
                        delete t.xhrs[e]
                    })
                },
                _createXhr: function(e, t) {
                    return n._registerXhr(e, t, qq.createXhrInstance())
                },
                _getAjaxRequester: function(e, t) {
                    var i = null == t ? -1 : t;
                    return n._getFileState(e).temp.ajaxRequesters[i]
                },
                _getChunkData: function(e, t) {
                    var i = r.partSize,
                        o = c(e),
                        a = n.getFile(e),
                        s = i * t,
                        l = s + i >= o ? o : s + i,
                        u = n._getTotalChunks(e),
                        d = this._getFileState(e).temp.cachedChunks,
                        p = d[t] || qq.sliceBlob(a, s, l);
                    return d[t] = p, {
                        part: t,
                        start: s,
                        end: l,
                        count: u,
                        blob: p,
                        size: l - s
                    }
                },
                _getChunkDataForCallback: function(e) {
                    return {
                        partIndex: e.part,
                        startByte: e.start + 1,
                        endByte: e.end,
                        totalParts: e.count
                    }
                },
                _getLocalStorageId: function(e) {
                    var t = "5.0",
                        n = u(e),
                        o = c(e),
                        a = r.partSize,
                        s = p(e);
                    return qq.format("qq{}resume{}-{}-{}-{}-{}", i, t, n, o, a, s)
                },
                _getMimeType: function(e) {
                    return n.getFile(e).type
                },
                _getPersistableData: function(e) {
                    return n._getFileState(e).chunking
                },
                _getTotalChunks: function(e) {
                    if (r) {
                        var t = c(e),
                            n = r.partSize;
                        return Math.ceil(t / n)
                    }
                },
                _getXhr: function(e, t) {
                    var i = null == t ? -1 : t;
                    return n._getFileState(e).temp.xhrs[i]
                },
                _getXhrs: function(e) {
                    return n._getFileState(e).temp.xhrs
                },
                _iterateResumeRecords: function(e) {
                    l && qq.each(localStorage, function(t, n) {
                        if (0 === t.indexOf(qq.format("qq{}resume", i))) {
                            var o = JSON.parse(n);
                            e(t, o)
                        }
                    })
                },
                _initTempState: function(e) {
                    n._getFileState(e).temp = {
                        ajaxRequesters: {},
                        chunkProgress: {},
                        xhrs: {},
                        cachedChunks: {}
                    }
                },
                _markNotResumable: function(e) {
                    n._getFileState(e).notResumable = !0
                },
                _maybeDeletePersistedChunkData: function(e) {
                    var t;
                    return !!(l && n.isResumable(e) && (t = n._getLocalStorageId(e), t && localStorage.getItem(t))) && (localStorage.removeItem(t), !0)
                },
                _maybePrepareForResume: function(e) {
                    var t, i, o = n._getFileState(e);
                    l && void 0 === o.key && (t = n._getLocalStorageId(e), i = localStorage.getItem(t), i && (i = JSON.parse(i), h(i.uuid) ? n._markNotResumable(e) : (m(qq.format("Identified file with ID {} and name of {} as resumable.", e, u(e))), f(e, i.uuid), o.key = i.key, o.chunking = i.chunking, o.loaded = i.loaded, o.attemptingResume = !0, n.moveInProgressToRemaining(e))))
                },
                _maybePersistChunkedState: function(e) {
                    var t, i, o = n._getFileState(e);
                    if (l && n.isResumable(e)) {
                        t = n._getLocalStorageId(e), i = {
                            name: u(e),
                            size: c(e),
                            uuid: d(e),
                            key: o.key,
                            chunking: o.chunking,
                            loaded: o.loaded,
                            lastUpdated: Date.now()
                        };
                        try {
                            localStorage.setItem(t, JSON.stringify(i))
                        } catch (t) {
                            m(qq.format("Unable to save resume data for '{}' due to error: '{}'.", e, t.toString()), "warn")
                        }
                    }
                },
                _registerProgressHandler: function(e, t, i) {
                    var o = n._getXhr(e, t),
                        r = u(e),
                        a = {
                            simple: function(t, n) {
                                var i = c(e);
                                t === n ? q(e, r, i, i) : q(e, r, t >= i ? i - 1 : t, i)
                            },
                            chunked: function(o, a) {
                                var s = n._getFileState(e).temp.chunkProgress,
                                    l = n._getFileState(e).loaded,
                                    u = o,
                                    d = a,
                                    p = c(e),
                                    h = u - (d - i),
                                    f = l;
                                s[t] = h, qq.each(s, function(e, t) {
                                    f += t
                                }), q(e, r, f, p)
                            }
                        };
                    o.upload.onprogress = function(e) {
                        if (e.lengthComputable) {
                            var t = null == i ? "simple" : "chunked";
                            a[t](e.loaded, e.total)
                        }
                    }
                },
                _registerXhr: function(e, t, i, o) {
                    var r = null == t ? -1 : t,
                        a = n._getFileState(e).temp;
                    return a.xhrs = a.xhrs || {}, a.ajaxRequesters = a.ajaxRequesters || {}, a.xhrs[r] = i, o && (a.ajaxRequesters[r] = o), i
                },
                _removeExpiredChunkingRecords: function() {
                    var e = a.recordsExpireIn;
                    n._iterateResumeRecords(function(t, n) {
                        var i = new Date(n.lastUpdated);
                        i.setDate(i.getDate() + e), i.getTime() <= Date.now() && (m("Removing expired resume record with key " + t), localStorage.removeItem(t))
                    })
                },
                _shouldChunkThisFile: function(e) {
                    var t = n._getFileState(e);
                    return t.chunking || n.reevaluateChunking(e), t.chunking.enabled
                }
            })
        }, qq.DeleteFileAjaxRequester = function(e) {
            "use strict";

            function t() {
                return "POST" === i.method.toUpperCase() ? {
                    _method: "DELETE"
                } : {}
            }
            var n, i = {
                method: "DELETE",
                uuidParamName: "qquuid",
                endpointStore: {},
                maxConnections: 3,
                customHeaders: function(e) {
                    return {}
                },
                paramsStore: {},
                cors: {
                    expected: !1,
                    sendCredentials: !1
                },
                log: function(e, t) {},
                onDelete: function(e) {},
                onDeleteComplete: function(e, t, n) {}
            };
            qq.extend(i, e), n = qq.extend(this, new qq.AjaxRequester({
                acceptHeader: "application/json",
                validMethods: ["POST", "DELETE"],
                method: i.method,
                endpointStore: i.endpointStore,
                paramsStore: i.paramsStore,
                mandatedParams: t(),
                maxConnections: i.maxConnections,
                customHeaders: function(e) {
                    return i.customHeaders.get(e)
                },
                log: i.log,
                onSend: i.onDelete,
                onComplete: i.onDeleteComplete,
                cors: i.cors
            })), qq.extend(this, {
                sendDelete: function(e, t, o) {
                    var r = o || {};
                    i.log("Submitting delete file request for " + e), "DELETE" === i.method ? n.initTransport(e).withPath(t).withParams(r).send() : (r[i.uuidParamName] = t, n.initTransport(e).withParams(r).send())
                }
            })
        },
        function() {
            function e(e) {
                var t, n = e.naturalWidth,
                    i = e.naturalHeight,
                    o = document.createElement("canvas");
                return n * i > 1048576 && (o.width = o.height = 1, t = o.getContext("2d"), t.drawImage(e, -n + 1, 0), 0 === t.getImageData(0, 0, 1, 1).data[3])
            }

            function t(e, t, n) {
                var i, o, r, a, s = document.createElement("canvas"),
                    l = 0,
                    u = n,
                    c = n;
                for (s.width = 1, s.height = n, i = s.getContext("2d"), i.drawImage(e, 0, 0), o = i.getImageData(0, 0, 1, n).data; c > l;) r = o[4 * (c - 1) + 3], 0 === r ? u = c : l = c, c = u + l >> 1;
                return a = c / n, 0 === a ? 1 : a
            }

            function n(e, t, n, i) {
                var r = document.createElement("canvas"),
                    a = n.mime || "image/jpeg",
                    s = new qq.Promise;
                return o(e, t, r, n, i).then(function() {
                    s.success(r.toDataURL(a, n.quality || .8))
                }), s
            }

            function i(e) {
                var t = 5241e3;
                if (!qq.ios()) throw new qq.Error("Downsampled dimensions can only be reliably calculated for iOS!");
                if (e.origHeight * e.origWidth > t) return {
                    newHeight: Math.round(Math.sqrt(t * (e.origHeight / e.origWidth))),
                    newWidth: Math.round(Math.sqrt(t * (e.origWidth / e.origHeight)))
                }
            }

            function o(n, o, s, l, u) {
                var c, d = n.naturalWidth,
                    p = n.naturalHeight,
                    h = l.width,
                    f = l.height,
                    q = s.getContext("2d"),
                    m = new qq.Promise;
                return q.save(), l.resize ? r({
                    blob: o,
                    canvas: s,
                    image: n,
                    imageHeight: p,
                    imageWidth: d,
                    orientation: l.orientation,
                    resize: l.resize,
                    targetHeight: f,
                    targetWidth: h
                }) : (qq.supportedFeatures.unlimitedScaledImageSize || (c = i({
                    origWidth: h,
                    origHeight: f
                }), c && (qq.log(qq.format("Had to reduce dimensions due to device limitations from {}w / {}h to {}w / {}h", h, f, c.newWidth, c.newHeight), "warn"), h = c.newWidth, f = c.newHeight)), a(s, h, f, l.orientation), qq.ios() ? ! function() {
                    e(n) && (d /= 2, p /= 2);
                    var i, o, r, a = 1024,
                        s = document.createElement("canvas"),
                        l = u ? t(n, d, p) : 1,
                        c = Math.ceil(a * h / d),
                        m = Math.ceil(a * f / p / l),
                        g = 0,
                        _ = 0;
                    for (s.width = s.height = a, i = s.getContext("2d"); g < p;) {
                        for (o = 0, r = 0; o < d;) i.clearRect(0, 0, a, a), i.drawImage(n, -o, -g), q.drawImage(s, 0, 0, a, a, r, _, c, m), o += a, r += c;
                        g += a, _ += m
                    }
                    q.restore(), s = i = null
                }() : q.drawImage(n, 0, 0, h, f), s.qqImageRendered && s.qqImageRendered(), m.success(), m)
            }

            function r(e) {
                var t = e.blob,
                    n = e.image,
                    i = e.imageHeight,
                    o = e.imageWidth,
                    r = e.orientation,
                    s = new qq.Promise,
                    l = e.resize,
                    u = document.createElement("canvas"),
                    c = u.getContext("2d"),
                    d = e.canvas,
                    p = e.targetHeight,
                    h = e.targetWidth;
                return a(u, o, i, r), d.height = p, d.width = h, c.drawImage(n, 0, 0), l({
                    blob: t,
                    height: p,
                    image: n,
                    sourceCanvas: u,
                    targetCanvas: d,
                    width: h
                }).then(function() {
                    d.qqImageRendered && d.qqImageRendered(), s.success()
                }, s.failure), s
            }

            function a(e, t, n, i) {
                switch (i) {
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                        e.width = n, e.height = t;
                        break;
                    default:
                        e.width = t, e.height = n
                }
                var o = e.getContext("2d");
                switch (i) {
                    case 2:
                        o.translate(t, 0), o.scale(-1, 1);
                        break;
                    case 3:
                        o.translate(t, n), o.rotate(Math.PI);
                        break;
                    case 4:
                        o.translate(0, n), o.scale(1, -1);
                        break;
                    case 5:
                        o.rotate(.5 * Math.PI), o.scale(1, -1);
                        break;
                    case 6:
                        o.rotate(.5 * Math.PI), o.translate(0, -n);
                        break;
                    case 7:
                        o.rotate(.5 * Math.PI), o.translate(t, -n), o.scale(-1, 1);
                        break;
                    case 8:
                        o.rotate(-.5 * Math.PI), o.translate(-t, 0)
                }
            }

            function s(e, t) {
                var n = this;
                window.Blob && e instanceof Blob && ! function() {
                    var t = new Image,
                        i = window.URL && window.URL.createObjectURL ? window.URL : window.webkitURL && window.webkitURL.createObjectURL ? window.webkitURL : null;
                    if (!i) throw Error("No createObjectURL function found to create blob url");
                    t.src = i.createObjectURL(e), n.blob = e, e = t
                }(), e.naturalWidth || e.naturalHeight || (e.onload = function() {
                    var e = n.imageLoadListeners;
                    e && (n.imageLoadListeners = null, setTimeout(function() {
                        for (var t = 0, n = e.length; t < n; t++) e[t]()
                    }, 0))
                }, e.onerror = t, this.imageLoadListeners = []), this.srcImage = e
            }
            s.prototype.render = function(e, t) {
                t = t || {};
                var i, r = this,
                    a = this.srcImage.naturalWidth,
                    s = this.srcImage.naturalHeight,
                    l = t.width,
                    u = t.height,
                    c = t.maxWidth,
                    d = t.maxHeight,
                    p = !this.blob || "image/jpeg" === this.blob.type,
                    h = e.tagName.toLowerCase();
                return this.imageLoadListeners ? void this.imageLoadListeners.push(function() {
                    r.render(e, t)
                }) : (l && !u ? u = s * l / a << 0 : u && !l ? l = a * u / s << 0 : (l = a, u = s), c && l > c && (l = c, u = s * l / a << 0), d && u > d && (u = d, l = a * u / s << 0), i = {
                    width: l,
                    height: u
                }, qq.each(t, function(e, t) {
                    i[e] = t
                }), "img" === h ? ! function() {
                    var t = e.src;
                    n(r.srcImage, r.blob, i, p).then(function(n) {
                        e.src = n, t === e.src && e.onload()
                    })
                }() : "canvas" === h && o(this.srcImage, this.blob, e, i, p), void("function" == typeof this.onrender && this.onrender(e)))
            }, qq.MegaPixImage = s
        }(), qq.ImageGenerator = function(e) {
            "use strict";

            function t(e) {
                return "img" === e.tagName.toLowerCase()
            }

            function n(e) {
                return "canvas" === e.tagName.toLowerCase()
            }

            function i() {
                return void 0 !== (new Image).crossOrigin
            }

            function o() {
                var e = document.createElement("canvas");
                return e.getContext && e.getContext("2d")
            }

            function r(e) {
                var t = e.split("/"),
                    n = t[t.length - 1].split("?")[0],
                    i = qq.getExtension(n);
                switch (i = i && i.toLowerCase()) {
                    case "jpeg":
                    case "jpg":
                        return "image/jpeg";
                    case "png":
                        return "image/png";
                    case "bmp":
                        return "image/bmp";
                    case "gif":
                        return "image/gif";
                    case "tiff":
                    case "tif":
                        return "image/tiff"
                }
            }

            function a(e) {
                var t, n, i, o = document.createElement("a");
                return o.href = e, t = o.protocol, i = o.port, n = o.hostname, t.toLowerCase() !== window.location.protocol.toLowerCase() || (n.toLowerCase() !== window.location.hostname.toLowerCase() || i !== window.location.port && !qq.ie())
            }

            function s(t, n) {
                t.onload = function() {
                    t.onload = null, t.onerror = null, n.success(t)
                }, t.onerror = function() {
                    t.onload = null, t.onerror = null, e("Problem drawing thumbnail!", "error"), n.failure(t, "Problem drawing thumbnail!")
                }
            }

            function l(e, t) {
                e.qqImageRendered = function() {
                    t.success(e)
                }
            }

            function u(i, o) {
                var r = t(i) || n(i);
                return t(i) ? s(i, o) : n(i) ? l(i, o) : (o.failure(i), e(qq.format("Element container of type {} is not supported!", i.tagName), "error")), r
            }

            function c(t, n, i) {
                var o = new qq.Promise,
                    r = new qq.Identify(t, e),
                    a = i.maxSize,
                    s = null == i.orient || i.orient,
                    l = function() {
                        n.onerror = null, n.onload = null, e("Could not render preview, file may be too large!", "error"), o.failure(n, "Browser cannot render image!")
                    };
                return r.isPreviewable().then(function(r) {
                    var c = {
                            parse: function() {
                                return (new qq.Promise).success()
                            }
                        },
                        d = s ? new qq.Exif(t, e) : c,
                        p = new qq.MegaPixImage(t, l);
                    u(n, o) && d.parse().then(function(e) {
                        var t = e && e.Orientation;
                        p.render(n, {
                            maxWidth: a,
                            maxHeight: a,
                            orientation: t,
                            mime: r,
                            resize: i.customResizeFunction
                        })
                    }, function(t) {
                        e(qq.format("EXIF data could not be parsed ({}).  Assuming orientation = 1.", t)), p.render(n, {
                            maxWidth: a,
                            maxHeight: a,
                            mime: r,
                            resize: i.customResizeFunction
                        })
                    })
                }, function() {
                    e("Not previewable"), o.failure(n, "Not previewable")
                }), o
            }

            function d(e, t, n, i, o) {
                var s = new Image,
                    l = new qq.Promise;
                u(s, l), a(e) && (s.crossOrigin = "anonymous"), s.src = e, l.then(function() {
                    u(t, n);
                    var a = new qq.MegaPixImage(s);
                    a.render(t, {
                        maxWidth: i,
                        maxHeight: i,
                        mime: r(e),
                        resize: o
                    })
                }, n.failure)
            }

            function p(e, t, n, i) {
                u(t, n), qq(t).css({
                    maxWidth: i + "px",
                    maxHeight: i + "px"
                }), t.src = e
            }

            function h(e, r, s) {
                var l = new qq.Promise,
                    c = s.scale,
                    h = c ? s.maxSize : null;
                return c && t(r) ? o() ? a(e) && !i() ? p(e, r, l, h) : d(e, r, l, h) : p(e, r, l, h) : n(r) ? d(e, r, l, h) : u(r, l) && (r.src = e), l
            }
            qq.extend(this, {
                generate: function(t, n, i) {
                    return qq.isString(t) ? (e("Attempting to update thumbnail based on server response."), h(t, n, i || {})) : (e("Attempting to draw client-side image preview."), c(t, n, i || {}))
                }
            }), this._testing = {}, this._testing.isImg = t, this._testing.isCanvas = n, this._testing.isCrossOrigin = a, this._testing.determineMimeOfFileName = r
        }, qq.Exif = function(e, t) {
            "use strict";

            function n(e) {
                for (var t = 0, n = 0; e.length > 0;) t += parseInt(e.substring(0, 2), 16) * Math.pow(2, n), e = e.substring(2, e.length), n += 8;
                return t
            }

            function i(t, n) {
                var o = t,
                    r = n;
                return void 0 === o && (o = 2, r = new qq.Promise), qq.readBlobToHex(e, o, 4).then(function(e) {
                    var t, n = /^ffe([0-9])/.exec(e);
                    n ? "1" !== n[1] ? (t = parseInt(e.slice(4, 8), 16), i(o + t + 2, r)) : r.success(o) : r.failure("No EXIF header to be found!")
                }), r
            }

            function o() {
                var t = new qq.Promise;
                return qq.readBlobToHex(e, 0, 6).then(function(e) {
                    0 !== e.indexOf("ffd8") ? t.failure("Not a valid JPEG!") : i().then(function(e) {
                        t.success(e)
                    }, function(e) {
                        t.failure(e)
                    })
                }), t
            }

            function r(t) {
                var n = new qq.Promise;
                return qq.readBlobToHex(e, t + 10, 2).then(function(e) {
                    n.success("4949" === e)
                }), n
            }

            function a(t, i) {
                var o = new qq.Promise;
                return qq.readBlobToHex(e, t + 18, 2).then(function(e) {
                    return i ? o.success(n(e)) : void o.success(parseInt(e, 16))
                }), o
            }

            function s(t, n) {
                var i = t + 20,
                    o = 12 * n;
                return qq.readBlobToHex(e, i, o)
            }

            function l(e) {
                for (var t = [], n = 0; n + 24 <= e.length;) t.push(e.slice(n, n + 24)), n += 24;
                return t
            }

            function u(e, t) {
                var i = 16,
                    o = qq.extend([], c),
                    r = {};
                return qq.each(t, function(t, a) {
                    var s, l, u, c = a.slice(0, 4),
                        p = e ? n(c) : parseInt(c, 16),
                        h = o.indexOf(p);
                    if (h >= 0 && (l = d[p].name, u = d[p].bytes, s = a.slice(i, i + 2 * u), r[l] = e ? n(s) : parseInt(s, 16), o.splice(h, 1)), 0 === o.length) return !1
                }), r
            }
            var c = [274],
                d = {
                    274: {
                        name: "Orientation",
                        bytes: 2
                    }
                };
            qq.extend(this, {
                parse: function() {
                    var n = new qq.Promise,
                        i = function(e) {
                            t(qq.format("EXIF header parse failed: '{}' ", e)), n.failure(e)
                        };
                    return o().then(function(o) {
                        t(qq.format("Moving forward with EXIF header parsing for '{}'", void 0 === e.name ? "blob" : e.name)), r(o).then(function(e) {
                            t(qq.format("EXIF Byte order is {} endian", e ? "little" : "big")), a(o, e).then(function(r) {
                                t(qq.format("Found {} APP1 directory entries", r)), s(o, r).then(function(i) {
                                    var o = l(i),
                                        r = u(e, o);
                                    t("Successfully parsed some EXIF tags"), n.success(r)
                                }, i)
                            }, i)
                        }, i)
                    }, i), n
                }
            }), this._testing = {}, this._testing.parseLittleEndian = n
        }, qq.Identify = function(e, t) {
            "use strict";

            function n(e, t) {
                var n = !1,
                    i = [].concat(e);
                return qq.each(i, function(e, i) {
                    if (0 === t.indexOf(i)) return n = !0, !1
                }), n
            }
            qq.extend(this, {
                isPreviewable: function() {
                    var i = this,
                        o = new qq.Promise,
                        r = !1,
                        a = void 0 === e.name ? "blob" : e.name;
                    return t(qq.format("Attempting to determine if {} can be rendered in this browser", a)), t("First pass: check type attribute of blob object."), this.isPreviewableSync() ? (t("Second pass: check for magic bytes in file header."), qq.readBlobToHex(e, 0, 4).then(function(e) {
                        qq.each(i.PREVIEWABLE_MIME_TYPES, function(t, i) {
                            if (n(i, e)) return ("image/tiff" !== t || qq.supportedFeatures.tiffPreviews) && (r = !0, o.success(t)), !1
                        }), t(qq.format("'{}' is {} able to be rendered in this browser", a, r ? "" : "NOT")), r || o.failure()
                    }, function() {
                        t("Error reading file w/ name '" + a + "'.  Not able to be rendered in this browser."), o.failure()
                    })) : o.failure(), o
                },
                isPreviewableSync: function() {
                    var n = e.type,
                        i = qq.indexOf(Object.keys(this.PREVIEWABLE_MIME_TYPES), n) >= 0,
                        o = !1,
                        r = void 0 === e.name ? "blob" : e.name;
                    return i && (o = "image/tiff" !== n || qq.supportedFeatures.tiffPreviews), !o && t(r + " is not previewable in this browser per the blob's type attr"), o
                }
            })
        }, qq.Identify.prototype.PREVIEWABLE_MIME_TYPES = {
            "image/jpeg": "ffd8ff",
            "image/gif": "474946",
            "image/png": "89504e",
            "image/bmp": "424d",
            "image/tiff": ["49492a00", "4d4d002a"]
        }, qq.Identify = function(e, t) {
            "use strict";

            function n(e, t) {
                var n = !1,
                    i = [].concat(e);
                return qq.each(i, function(e, i) {
                    if (0 === t.indexOf(i)) return n = !0, !1
                }), n
            }
            qq.extend(this, {
                isPreviewable: function() {
                    var i = this,
                        o = new qq.Promise,
                        r = !1,
                        a = void 0 === e.name ? "blob" : e.name;
                    return t(qq.format("Attempting to determine if {} can be rendered in this browser", a)), t("First pass: check type attribute of blob object."), this.isPreviewableSync() ? (t("Second pass: check for magic bytes in file header."), qq.readBlobToHex(e, 0, 4).then(function(e) {
                        qq.each(i.PREVIEWABLE_MIME_TYPES, function(t, i) {
                            if (n(i, e)) return ("image/tiff" !== t || qq.supportedFeatures.tiffPreviews) && (r = !0, o.success(t)), !1
                        }), t(qq.format("'{}' is {} able to be rendered in this browser", a, r ? "" : "NOT")), r || o.failure()
                    }, function() {
                        t("Error reading file w/ name '" + a + "'.  Not able to be rendered in this browser."), o.failure()
                    })) : o.failure(), o
                },
                isPreviewableSync: function() {
                    var n = e.type,
                        i = qq.indexOf(Object.keys(this.PREVIEWABLE_MIME_TYPES), n) >= 0,
                        o = !1,
                        r = void 0 === e.name ? "blob" : e.name;
                    return i && (o = "image/tiff" !== n || qq.supportedFeatures.tiffPreviews), !o && t(r + " is not previewable in this browser per the blob's type attr"), o
                }
            })
        }, qq.Identify.prototype.PREVIEWABLE_MIME_TYPES = {
            "image/jpeg": "ffd8ff",
            "image/gif": "474946",
            "image/png": "89504e",
            "image/bmp": "424d",
            "image/tiff": ["49492a00", "4d4d002a"]
        }, qq.ImageValidation = function(e, t) {
            "use strict";

            function n(e) {
                var t = !1;
                return qq.each(e, function(e, n) {
                    if (n > 0) return t = !0, !1
                }), t
            }

            function i() {
                var n = new qq.Promise;
                return new qq.Identify(e, t).isPreviewable().then(function() {
                    var i = new Image,
                        o = window.URL && window.URL.createObjectURL ? window.URL : window.webkitURL && window.webkitURL.createObjectURL ? window.webkitURL : null;
                    o ? (i.onerror = function() {
                        t("Cannot determine dimensions for image.  May be too large.", "error"), n.failure()
                    }, i.onload = function() {
                        n.success({
                            width: this.width,
                            height: this.height
                        })
                    }, i.src = o.createObjectURL(e)) : (t("No createObjectURL function available to generate image URL!", "error"), n.failure())
                }, n.failure), n
            }

            function o(e, t) {
                var n;
                return qq.each(e, function(e, i) {
                    if (i > 0) {
                        var o = /(max|min)(Width|Height)/.exec(e),
                            r = o[2].charAt(0).toLowerCase() + o[2].slice(1),
                            a = t[r];
                        switch (o[1]) {
                            case "min":
                                if (a < i) return n = e, !1;
                                break;
                            case "max":
                                if (a > i) return n = e, !1
                        }
                    }
                }), n
            }
            this.validate = function(e) {
                var r = new qq.Promise;
                return t("Attempting to validate image."), n(e) ? i().then(function(t) {
                    var n = o(e, t);
                    n ? r.failure(n) : r.success()
                }, r.success) : r.success(), r
            }
        }, qq.Session = function(e) {
            "use strict";

            function t(e) {
                return !!qq.isArray(e) || void i.log("Session response is not an array.", "error")
            }

            function n(e, n, o, r) {
                var a = !1;
                n = n && t(e), n && qq.each(e, function(e, t) {
                    if (null == t.uuid) a = !0, i.log(qq.format("Session response item {} did not include a valid UUID - ignoring.", e), "error");
                    else if (null == t.name) a = !0, i.log(qq.format("Session response item {} did not include a valid name - ignoring.", e), "error");
                    else try {
                        return i.addFileRecord(t), !0
                    } catch (e) {
                        a = !0, i.log(e.message, "error")
                    }
                    return !1
                }), r[n && !a ? "success" : "failure"](e, o)
            }
            var i = {
                endpoint: null,
                params: {},
                customHeaders: {},
                cors: {},
                addFileRecord: function(e) {},
                log: function(e, t) {}
            };
            qq.extend(i, e, !0), this.refresh = function() {
                var e = new qq.Promise,
                    t = function(t, i, o) {
                        n(t, i, o, e)
                    },
                    o = qq.extend({}, i),
                    r = new qq.SessionAjaxRequester(qq.extend(o, {
                        onComplete: t
                    }));
                return r.queryServer(), e
            }
        }, qq.SessionAjaxRequester = function(e) {
            "use strict";

            function t(e, t, n) {
                var o = null;
                if (null != t.responseText) try {
                    o = qq.parseJson(t.responseText)
                } catch (e) {
                    i.log("Problem parsing session response: " + e.message, "error"), n = !0
                }
                i.onComplete(o, !n, t)
            }
            var n, i = {
                endpoint: null,
                customHeaders: {},
                params: {},
                cors: {
                    expected: !1,
                    sendCredentials: !1
                },
                onComplete: function(e, t, n) {},
                log: function(e, t) {}
            };
            qq.extend(i, e), n = qq.extend(this, new qq.AjaxRequester({
                acceptHeader: "application/json",
                validMethods: ["GET"],
                method: "GET",
                endpointStore: {
                    get: function() {
                        return i.endpoint
                    }
                },
                customHeaders: i.customHeaders,
                log: i.log,
                onComplete: t,
                cors: i.cors
            })), qq.extend(this, {
                queryServer: function() {
                    var e = qq.extend({}, i.params);
                    i.log("Session query request."), n.initTransport("sessionRefresh").withParams(e).withCacheBuster().send()
                }
            })
        }, qq.Scaler = function(e, t) {
            "use strict";
            var n = e.customResizer,
                i = e.sendOriginal,
                o = e.orient,
                r = e.defaultType,
                a = e.defaultQuality / 100,
                s = e.failureText,
                l = e.includeExif,
                u = this._getSortedSizes(e.sizes);
            qq.extend(this, {
                enabled: qq.supportedFeatures.scaling && u.length > 0,
                getFileRecords: function(e, c, d) {
                    var p = this,
                        h = [],
                        f = d.blob ? d.blob : d,
                        q = new qq.Identify(f, t);
                    return q.isPreviewableSync() ? (qq.each(u, function(e, i) {
                        var u = p._determineOutputType({
                            defaultType: r,
                            requestedType: i.type,
                            refType: f.type
                        });
                        h.push({
                            uuid: qq.getUniqueId(),
                            name: p._getName(c, {
                                name: i.name,
                                type: u,
                                refType: f.type
                            }),
                            blob: new qq.BlobProxy(f, qq.bind(p._generateScaledImage, p, {
                                customResizeFunction: n,
                                maxSize: i.maxSize,
                                orient: o,
                                type: u,
                                quality: a,
                                failedText: s,
                                includeExif: l,
                                log: t
                            }))
                        })
                    }), h.push({
                        uuid: e,
                        name: c,
                        size: f.size,
                        blob: i ? f : null
                    })) : h.push({
                        uuid: e,
                        name: c,
                        size: f.size,
                        blob: f
                    }), h
                },
                handleNewFile: function(e, t, n, i, o, r, a, s) {
                    var l = this,
                        u = (e.qqButtonId || e.blob && e.blob.qqButtonId, []),
                        c = null,
                        d = s.addFileToHandler,
                        p = s.uploadData,
                        h = s.paramsStore,
                        f = qq.getUniqueId();
                    qq.each(l.getFileRecords(n, t, e), function(e, t) {
                        var n, i = t.size;
                        t.blob instanceof qq.BlobProxy && (i = -1), n = p.addFile({
                            uuid: t.uuid,
                            name: t.name,
                            size: i,
                            batchId: r,
                            proxyGroupId: f
                        }), t.blob instanceof qq.BlobProxy ? u.push(n) : c = n, t.blob ? (d(n, t.blob), o.push({
                            id: n,
                            file: t.blob
                        })) : p.setStatus(n, qq.status.REJECTED)
                    }), null !== c && (qq.each(u, function(e, t) {
                        var n = {
                            qqparentuuid: p.retrieve({
                                id: c
                            }).uuid,
                            qqparentsize: p.retrieve({
                                id: c
                            }).size
                        };
                        n[a] = p.retrieve({
                            id: t
                        }).uuid, p.setParentId(t, c), h.addReadOnly(t, n)
                    }), u.length && ! function() {
                        var e = {};
                        e[a] = p.retrieve({
                            id: c
                        }).uuid, h.addReadOnly(c, e)
                    }())
                }
            })
        }, qq.extend(qq.Scaler.prototype, {
            scaleImage: function(e, t, n) {
                "use strict";
                if (!qq.supportedFeatures.scaling) throw new qq.Error("Scaling is not supported in this browser!");
                var i = new qq.Promise,
                    o = n.log,
                    r = n.getFile(e),
                    a = n.uploadData.retrieve({
                        id: e
                    }),
                    s = a && a.name,
                    l = a && a.uuid,
                    u = {
                        customResizer: t.customResizer,
                        sendOriginal: !1,
                        orient: t.orient,
                        defaultType: t.type || null,
                        defaultQuality: t.quality,
                        failedToScaleText: "Unable to scale",
                        sizes: [{
                            name: "",
                            maxSize: t.maxSize
                        }]
                    },
                    c = new qq.Scaler(u, o);
                return qq.Scaler && qq.supportedFeatures.imagePreviews && r ? qq.bind(function() {
                    var t = c.getFileRecords(l, s, r)[0];
                    t && t.blob instanceof qq.BlobProxy ? t.blob.create().then(i.success, i.failure) : (o(e + " is not a scalable image!", "error"), i.failure())
                }, this)() : (i.failure(), o("Could not generate requested scaled image for " + e + ".  Scaling is either not possible in this browser, or the file could not be located.", "error")), i
            },
            _determineOutputType: function(e) {
                "use strict";
                var t = e.requestedType,
                    n = e.defaultType,
                    i = e.refType;
                return n || t ? t && qq.indexOf(Object.keys(qq.Identify.prototype.PREVIEWABLE_MIME_TYPES), t) >= 0 ? "image/tiff" === t ? qq.supportedFeatures.tiffPreviews ? t : n : t : n : "image/jpeg" !== i ? "image/png" : i
            },
            _getName: function(e, t) {
                "use strict";
                var n = e.lastIndexOf("."),
                    i = t.type || "image/png",
                    o = t.refType,
                    r = "",
                    a = qq.getExtension(e),
                    s = "";
                return t.name && t.name.trim().length && (s = " (" + t.name + ")"), n >= 0 ? (r = e.substr(0, n), o !== i && (a = i.split("/")[1]), r += s + "." + a) : r = e + s, r
            },
            _getSortedSizes: function(e) {
                "use strict";
                return e = qq.extend([], e), e.sort(function(e, t) {
                    return e.maxSize > t.maxSize ? 1 : e.maxSize < t.maxSize ? -1 : 0
                })
            },
            _generateScaledImage: function(e, t) {
                "use strict";
                var n = this,
                    i = e.customResizeFunction,
                    o = e.log,
                    r = e.maxSize,
                    a = e.orient,
                    s = e.type,
                    l = e.quality,
                    u = e.failedText,
                    c = e.includeExif && "image/jpeg" === t.type && "image/jpeg" === s,
                    d = new qq.Promise,
                    p = new qq.ImageGenerator(o),
                    h = document.createElement("canvas");
                return o("Attempting to generate scaled version for " + t.name), p.generate(t, h, {
                    maxSize: r,
                    orient: a,
                    customResizeFunction: i
                }).then(function() {
                    var e = h.toDataURL(s, l),
                        i = function() {
                            o("Success generating scaled version for " + t.name);
                            var n = qq.dataUriToBlob(e);
                            d.success(n)
                        };
                    c ? n._insertExifHeader(t, e, o).then(function(t) {
                        e = t, i()
                    }, function() {
                        o("Problem inserting EXIF header into scaled image.  Using scaled image w/out EXIF data.", "error"), i()
                    }) : i()
                }, function() {
                    o("Failed attempt to generate scaled version for " + t.name, "error"), d.failure(u)
                }), d
            },
            _insertExifHeader: function(e, t, n) {
                "use strict";
                var i = new FileReader,
                    o = new qq.Promise,
                    r = "";
                return i.onload = function() {
                    r = i.result, o.success(qq.ExifRestorer.restore(r, t))
                }, i.onerror = function() {
                    n("Problem reading " + e.name + " during attempt to transfer EXIF data to scaled version.", "error"), o.failure()
                }, i.readAsDataURL(e), o
            },
            _dataUriToBlob: function(e) {
                "use strict";
                var t, n, i, o;
                return t = e.split(",")[0].indexOf("base64") >= 0 ? atob(e.split(",")[1]) : decodeURI(e.split(",")[1]), n = e.split(",")[0].split(":")[1].split(";")[0], i = new ArrayBuffer(t.length), o = new Uint8Array(i), qq.each(t, function(e, t) {
                    o[e] = t.charCodeAt(0)
                }), this._createBlob(i, n)
            },
            _createBlob: function(e, t) {
                "use strict";
                var n = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder,
                    i = n && new n;
                return i ? (i.append(e), i.getBlob(t)) : new Blob([e], {
                    type: t
                })
            }
        }), qq.ExifRestorer = function() {
            var e = {};
            return e.KEY_STR = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", e.encode64 = function(e) {
                var t, n, i, o, r, a = "",
                    s = "",
                    l = "",
                    u = 0;
                do t = e[u++], n = e[u++], s = e[u++], i = t >> 2, o = (3 & t) << 4 | n >> 4, r = (15 & n) << 2 | s >> 6, l = 63 & s, isNaN(n) ? r = l = 64 : isNaN(s) && (l = 64), a = a + this.KEY_STR.charAt(i) + this.KEY_STR.charAt(o) + this.KEY_STR.charAt(r) + this.KEY_STR.charAt(l),
                    t = n = s = "", i = o = r = l = ""; while (u < e.length);
                return a
            }, e.restore = function(e, t) {
                var n = "data:image/jpeg;base64,";
                if (!e.match(n)) return t;
                var i = this.decode64(e.replace(n, "")),
                    o = this.slice2Segments(i),
                    r = this.exifManipulation(t, o);
                return n + this.encode64(r)
            }, e.exifManipulation = function(e, t) {
                var n = this.getExifArray(t),
                    i = this.insertExif(e, n),
                    o = new Uint8Array(i);
                return o
            }, e.getExifArray = function(e) {
                for (var t, n = 0; n < e.length; n++)
                    if (t = e[n], 255 == t[0] & 225 == t[1]) return t;
                return []
            }, e.insertExif = function(e, t) {
                var n = e.replace("data:image/jpeg;base64,", ""),
                    i = this.decode64(n),
                    o = i.indexOf(255, 3),
                    r = i.slice(0, o),
                    a = i.slice(o),
                    s = r;
                return s = s.concat(t), s = s.concat(a)
            }, e.slice2Segments = function(e) {
                for (var t = 0, n = [];;) {
                    if (255 == e[t] & 218 == e[t + 1]) break;
                    if (255 == e[t] & 216 == e[t + 1]) t += 2;
                    else {
                        var i = 256 * e[t + 2] + e[t + 3],
                            o = t + i + 2,
                            r = e.slice(t, o);
                        n.push(r), t = o
                    }
                    if (t > e.length) break
                }
                return n
            }, e.decode64 = function(e) {
                var t, n, i, o, r, a = "",
                    s = "",
                    l = 0,
                    u = [],
                    c = /[^A-Za-z0-9\+\/\=]/g;
                if (c.exec(e)) throw new Error("There were invalid base64 characters in the input text.  Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='");
                e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
                do i = this.KEY_STR.indexOf(e.charAt(l++)), o = this.KEY_STR.indexOf(e.charAt(l++)), r = this.KEY_STR.indexOf(e.charAt(l++)), s = this.KEY_STR.indexOf(e.charAt(l++)), t = i << 2 | o >> 4, n = (15 & o) << 4 | r >> 2, a = (3 & r) << 6 | s, u.push(t), 64 != r && u.push(n), 64 != s && u.push(a), t = n = a = "", i = o = r = s = ""; while (l < e.length);
                return u
            }, e
        }(), qq.TotalProgress = function(e, t) {
            "use strict";
            var n = {},
                i = 0,
                o = 0,
                r = -1,
                a = -1,
                s = function(t, n) {
                    t === r && n === a || e(t, n), r = t, a = n
                },
                l = function(e, t) {
                    var n = !0;
                    return qq.each(e, function(e, i) {
                        if (qq.indexOf(t, i) >= 0) return n = !1, !1
                    }), n
                },
                u = function(e) {
                    p(e, -1, -1), delete n[e]
                },
                c = function(e, t, n) {
                    (0 === t.length || l(t, n)) && (s(o, o), this.reset())
                },
                d = function(e) {
                    var i = t(e);
                    i > 0 && (p(e, 0, i), n[e] = {
                        loaded: 0,
                        total: i
                    })
                },
                p = function(e, t, r) {
                    var a = n[e] ? n[e].loaded : 0,
                        l = n[e] ? n[e].total : 0;
                    t === -1 && r === -1 ? (i -= a, o -= l) : (t && (i += t - a), r && (o += r - l)), s(i, o)
                };
            qq.extend(this, {
                onAllComplete: c,
                onStatusChange: function(e, t, n) {
                    n === qq.status.CANCELED || n === qq.status.REJECTED ? u(e) : n === qq.status.SUBMITTING && d(e)
                },
                onIndividualProgress: function(e, t, i) {
                    p(e, t, i), n[e] = {
                        loaded: t,
                        total: i
                    }
                },
                onNewSize: function(e) {
                    d(e)
                },
                reset: function() {
                    n = {}, i = 0, o = 0
                }
            })
        }, qq.PasteSupport = function(e) {
            "use strict";

            function t(e) {
                return e.type && 0 === e.type.indexOf("image/")
            }

            function n() {
                r = qq(o.targetElement).attach("paste", function(e) {
                    var n = e.clipboardData;
                    n && qq.each(n.items, function(e, n) {
                        if (t(n)) {
                            var i = n.getAsFile();
                            o.callbacks.pasteReceived(i)
                        }
                    })
                })
            }

            function i() {
                r && r()
            }
            var o, r;
            o = {
                targetElement: null,
                callbacks: {
                    log: function(e, t) {},
                    pasteReceived: function(e) {}
                }
            }, qq.extend(o, e), n(), qq.extend(this, {
                reset: function() {
                    i()
                }
            })
        }, qq.FormSupport = function(e, t, n) {
            "use strict";

            function i(e) {
                e.getAttribute("action") && (s.newEndpoint = e.getAttribute("action"))
            }

            function o(e, t) {
                return !(e.checkValidity && !e.checkValidity()) || (n("Form did not pass validation checks - will not upload.", "error"), void t())
            }

            function r(e) {
                var n = e.submit;
                qq(e).attach("submit", function(i) {
                    i = i || window.event, i.preventDefault ? i.preventDefault() : i.returnValue = !1, o(e, n) && t()
                }), e.submit = function() {
                    o(e, n) && t()
                }
            }

            function a(e) {
                return e && (qq.isString(e) && (e = document.getElementById(e)), e && (n("Attaching to form element."), i(e), l && r(e))), e
            }
            var s = this,
                l = e.interceptSubmit,
                u = e.element,
                c = e.autoUpload;
            qq.extend(this, {
                newEndpoint: null,
                newAutoUpload: c,
                attachedToForm: !1,
                getFormInputsAsObject: function() {
                    return null == u ? null : s._form2Obj(u)
                }
            }), u = a(u), this.attachedToForm = !!u
        }, qq.extend(qq.FormSupport.prototype, {
            _form2Obj: function(e) {
                "use strict";
                var t = {},
                    n = function(e) {
                        var t = ["button", "image", "reset", "submit"];
                        return qq.indexOf(t, e.toLowerCase()) < 0
                    },
                    i = function(e) {
                        return qq.indexOf(["checkbox", "radio"], e.toLowerCase()) >= 0
                    },
                    o = function(e) {
                        return !(!i(e.type) || e.checked) || e.disabled && "hidden" !== e.type.toLowerCase()
                    },
                    r = function(e) {
                        var t = null;
                        return qq.each(qq(e).children(), function(e, n) {
                            if ("option" === n.tagName.toLowerCase() && n.selected) return t = n.value, !1
                        }), t
                    };
                return qq.each(e.elements, function(e, i) {
                    if (!qq.isInput(i, !0) && "textarea" !== i.tagName.toLowerCase() || !n(i.type) || o(i)) {
                        if ("select" === i.tagName.toLowerCase() && !o(i)) {
                            var a = r(i);
                            null !== a && (t[i.name] = a)
                        }
                    } else t[i.name] = i.value
                }), t
            }
        }), qq.traditional = qq.traditional || {}, qq.traditional.FormUploadHandler = function(e, t) {
            "use strict";

            function n(e, t) {
                var n, i, r;
                try {
                    i = t.contentDocument || t.contentWindow.document, r = i.body.innerHTML, s("converting iframe's innerHTML to JSON"), s("innerHTML = " + r), r && r.match(/^<pre/i) && (r = i.body.firstChild.firstChild.nodeValue), n = o._parseJsonResponse(r)
                } catch (e) {
                    s("Error when attempting to parse form upload response (" + e.message + ")", "error"), n = {
                        success: !1
                    }
                }
                return n
            }

            function i(t, n) {
                var i = e.paramsStore.get(t),
                    s = "get" === e.method.toLowerCase() ? "GET" : "POST",
                    l = e.endpointStore.get(t),
                    u = r(t);
                return i[e.uuidName] = a(t), i[e.filenameParam] = u, o._initFormForUpload({
                    method: s,
                    endpoint: l,
                    params: i,
                    paramsInBody: e.paramsInBody,
                    targetName: n.name
                })
            }
            var o = this,
                r = t.getName,
                a = t.getUuid,
                s = t.log;
            this.uploadFile = function(t) {
                var r, a = o.getInput(t),
                    l = o._createIframe(t),
                    u = new qq.Promise;
                return r = i(t, l), r.appendChild(a), o._attachLoadEvent(l, function(i) {
                    s("iframe loaded");
                    var r = i ? i : n(t, l);
                    o._detachLoadEvent(t), e.cors.expected || qq(l).remove(), r.success ? u.success(r) : u.failure(r)
                }), s("Sending upload request for " + t), r.submit(), qq(r).remove(), u
            }, qq.extend(this, new qq.FormUploadHandler({
                options: {
                    isCors: e.cors.expected,
                    inputName: e.inputName
                },
                proxy: {
                    onCancel: e.onCancel,
                    getName: r,
                    getUuid: a,
                    log: s
                }
            }))
        }, qq.traditional = qq.traditional || {}, qq.traditional.XhrUploadHandler = function(e, t) {
            "use strict";
            var n = this,
                i = t.getName,
                o = t.getSize,
                r = t.getUuid,
                a = t.log,
                s = e.forceMultipart || e.paramsInBody,
                l = function(t, n, r) {
                    var a = o(t),
                        l = i(t);
                    n[e.chunking.paramNames.partIndex] = r.part, n[e.chunking.paramNames.partByteOffset] = r.start, n[e.chunking.paramNames.chunkSize] = r.size, n[e.chunking.paramNames.totalParts] = r.count, n[e.totalFileSizeName] = a, s && (n[e.filenameParam] = l)
                },
                u = new qq.traditional.AllChunksDoneAjaxRequester({
                    cors: e.cors,
                    endpoint: e.chunking.success.endpoint,
                    log: a
                }),
                c = function(e, t) {
                    var n = new qq.Promise;
                    return t.onreadystatechange = function() {
                        if (4 === t.readyState) {
                            var i = h(e, t);
                            i.success ? n.success(i.response, t) : n.failure(i.response, t)
                        }
                    }, n
                },
                d = function(t) {
                    var a = e.paramsStore.get(t),
                        s = i(t),
                        l = o(t);
                    return a[e.uuidName] = r(t), a[e.filenameParam] = s, a[e.totalFileSizeName] = l, a[e.chunking.paramNames.totalParts] = n._getTotalChunks(t), a
                },
                p = function(e, t) {
                    return qq.indexOf([200, 201, 202, 203, 204], e.status) < 0 || !t.success || t.reset
                },
                h = function(e, t) {
                    var n;
                    return a("xhr - server response received for " + e), a("responseText = " + t.responseText), n = f(!0, t), {
                        success: !p(t, n),
                        response: n
                    }
                },
                f = function(e, t) {
                    var n = {};
                    try {
                        a(qq.format("Received response status {} with body: {}", t.status, t.responseText)), n = qq.parseJson(t.responseText)
                    } catch (t) {
                        e && a("Error when attempting to parse xhr response text (" + t.message + ")", "error")
                    }
                    return n
                },
                q = function(t) {
                    var i = new qq.Promise;
                    return u.complete(t, n._createXhr(t), d(t), e.customHeaders.get(t)).then(function(e) {
                        i.success(f(!1, e), e)
                    }, function(e) {
                        i.failure(f(!1, e), e)
                    }), i
                },
                m = function(t, n, a, l) {
                    var u = new FormData,
                        c = e.method,
                        d = e.endpointStore.get(l),
                        p = i(l),
                        h = o(l);
                    return t[e.uuidName] = r(l), t[e.filenameParam] = p, s && (t[e.totalFileSizeName] = h), e.paramsInBody || (s || (t[e.inputName] = p), d = qq.obj2url(t, d)), n.open(c, d, !0), e.cors.expected && e.cors.sendCredentials && (n.withCredentials = !0), s ? (e.paramsInBody && qq.obj2FormData(t, u), u.append(e.inputName, a), u) : a
                },
                g = function(t, i) {
                    var o = e.customHeaders.get(t),
                        r = n.getFile(t);
                    i.setRequestHeader("Accept", "application/json"), i.setRequestHeader("X-Requested-With", "XMLHttpRequest"), i.setRequestHeader("Cache-Control", "no-cache"), s || (i.setRequestHeader("Content-Type", "application/octet-stream"), i.setRequestHeader("X-Mime-Type", r.type)), qq.each(o, function(e, t) {
                        i.setRequestHeader(e, t)
                    })
                };
            qq.extend(this, {
                uploadChunk: function(t, i, r) {
                    var a, s, u, d = n._getChunkData(t, i),
                        p = n._createXhr(t, i);
                    o(t);
                    return a = c(t, p), n._registerProgressHandler(t, i, d.size), u = e.paramsStore.get(t), l(t, u, d), r && (u[e.resume.paramNames.resuming] = !0), s = m(u, p, d.blob, t), g(t, p), p.send(s), a
                },
                uploadFile: function(t) {
                    var i, o, r, a, s = n.getFile(t);
                    return o = n._createXhr(t), n._registerProgressHandler(t), i = c(t, o), r = e.paramsStore.get(t), a = m(r, o, s, t), g(t, o), o.send(a), i
                }
            }), qq.extend(this, new qq.XhrUploadHandler({
                options: qq.extend({
                    namespace: "traditional"
                }, e),
                proxy: qq.extend({
                    getEndpoint: e.endpointStore.get
                }, t)
            })), qq.override(this, function(t) {
                return {
                    finalizeChunks: function(n) {
                        return e.chunking.success.endpoint ? q(n) : t.finalizeChunks(n, qq.bind(f, this, !0))
                    }
                }
            })
        }, qq.traditional.AllChunksDoneAjaxRequester = function(e) {
            "use strict";
            var t, n = "POST",
                i = {
                    cors: {
                        allowXdr: !1,
                        expected: !1,
                        sendCredentials: !1
                    },
                    endpoint: null,
                    log: function(e, t) {}
                },
                o = {},
                r = {
                    get: function(e) {
                        return i.endpoint
                    }
                };
            qq.extend(i, e), t = qq.extend(this, new qq.AjaxRequester({
                acceptHeader: "application/json",
                validMethods: [n],
                method: n,
                endpointStore: r,
                allowXRequestedWithAndCacheControl: !1,
                cors: i.cors,
                log: i.log,
                onComplete: function(e, t, n) {
                    var i = o[e];
                    delete o[e], n ? i.failure(t) : i.success(t)
                }
            })), qq.extend(this, {
                complete: function(e, n, r, a) {
                    var s = new qq.Promise;
                    return i.log("Submitting All Chunks Done request for " + e), o[e] = s, t.initTransport(e).withParams(r).withHeaders(a).send(n), s
                }
            })
        }, qq.DragAndDrop = function(e) {
            "use strict";

            function t(e, t) {
                var n = Array.prototype.slice.call(e);
                u.callbacks.dropLog("Grabbed " + e.length + " dropped files."), t.dropDisabled(!1), u.callbacks.processingDroppedFilesComplete(n, t.getElement())
            }

            function n(e) {
                var t = new qq.Promise;
                return e.isFile ? e.file(function(n) {
                    var i = e.name,
                        o = e.fullPath,
                        r = o.indexOf(i);
                    o = o.substr(0, r), "/" === o.charAt(0) && (o = o.substr(1)), n.qqPath = o, h.push(n), t.success()
                }, function(n) {
                    u.callbacks.dropLog("Problem parsing '" + e.fullPath + "'.  FileError code " + n.code + ".", "error"), t.failure()
                }) : e.isDirectory && i(e).then(function(e) {
                    var i = e.length;
                    qq.each(e, function(e, o) {
                        n(o).done(function() {
                            i -= 1, 0 === i && t.success()
                        })
                    }), e.length || t.success()
                }, function(n) {
                    u.callbacks.dropLog("Problem parsing '" + e.fullPath + "'.  FileError code " + n.code + ".", "error"), t.failure()
                }), t
            }

            function i(e, t, n, o) {
                var r = o || new qq.Promise,
                    a = t || e.createReader();
                return a.readEntries(function(t) {
                    var o = n ? n.concat(t) : t;
                    t.length ? setTimeout(function() {
                        i(e, a, o, r)
                    }, 0) : r.success(o)
                }, r.failure), r
            }

            function o(e, t) {
                var i = [],
                    o = new qq.Promise;
                return u.callbacks.processingDroppedFiles(), t.dropDisabled(!0), e.files.length > 1 && !u.allowMultipleItems ? (u.callbacks.processingDroppedFilesComplete([]), u.callbacks.dropError("tooManyFilesError", ""), t.dropDisabled(!1), o.failure()) : (h = [], qq.isFolderDropSupported(e) ? qq.each(e.items, function(e, t) {
                    var r = t.webkitGetAsEntry();
                    r && (r.isFile ? h.push(t.getAsFile()) : i.push(n(r).done(function() {
                        i.pop(), 0 === i.length && o.success()
                    })))
                }) : h = e.files, 0 === i.length && o.success()), o
            }

            function r(e) {
                var n = new qq.UploadDropZone({
                    HIDE_ZONES_EVENT_NAME: c,
                    element: e,
                    onEnter: function(t) {
                        qq(e).addClass(u.classes.dropActive), t.stopPropagation()
                    },
                    onLeaveNotDescendants: function(t) {
                        qq(e).removeClass(u.classes.dropActive)
                    },
                    onDrop: function(e) {
                        o(e.dataTransfer, n).then(function() {
                            t(h, n)
                        }, function() {
                            u.callbacks.dropLog("Drop event DataTransfer parsing failed.  No files will be uploaded.", "error")
                        })
                    }
                });
                return f.addDisposer(function() {
                    n.dispose()
                }), qq(e).hasAttribute(d) && qq(e).hide(), p.push(n), n
            }

            function a(e) {
                var t;
                return qq.each(e.dataTransfer.types, function(e, n) {
                    if ("Files" === n) return t = !0, !1
                }), t
            }

            function s(e) {
                return qq.firefox() ? !e.relatedTarget : qq.safari() ? e.x < 0 || e.y < 0 : 0 === e.x && 0 === e.y
            }

            function l() {
                var e = u.dropZoneElements,
                    t = function() {
                        setTimeout(function() {
                            qq.each(e, function(e, t) {
                                qq(t).hasAttribute(d) && qq(t).hide(), qq(t).removeClass(u.classes.dropActive)
                            })
                        }, 10)
                    };
                qq.each(e, function(t, n) {
                    var i = r(n);
                    e.length && qq.supportedFeatures.fileDrop && f.attach(document, "dragenter", function(t) {
                        !i.dropDisabled() && a(t) && qq.each(e, function(e, t) {
                            t instanceof HTMLElement && qq(t).hasAttribute(d) && qq(t).css({
                                display: "block"
                            })
                        })
                    })
                }), f.attach(document, "dragleave", function(e) {
                    s(e) && t()
                }), f.attach(qq(document).children()[0], "mouseenter", function(e) {
                    t()
                }), f.attach(document, "drop", function(e) {
                    e.preventDefault(), t()
                }), f.attach(document, c, t)
            }
            var u, c = "qq-hidezones",
                d = "qq-hide-dropzone",
                p = [],
                h = [],
                f = new qq.DisposeSupport;
            u = {
                dropZoneElements: [],
                allowMultipleItems: !0,
                classes: {
                    dropActive: null
                },
                callbacks: new qq.DragAndDrop.callbacks
            }, qq.extend(u, e, !0), l(), qq.extend(this, {
                setupExtraDropzone: function(e) {
                    u.dropZoneElements.push(e), r(e)
                },
                removeDropzone: function(e) {
                    var t, n = u.dropZoneElements;
                    for (t in n)
                        if (n[t] === e) return n.splice(t, 1)
                },
                dispose: function() {
                    f.dispose(), qq.each(p, function(e, t) {
                        t.dispose()
                    })
                }
            })
        }, qq.DragAndDrop.callbacks = function() {
            "use strict";
            return {
                processingDroppedFiles: function() {},
                processingDroppedFilesComplete: function(e, t) {},
                dropError: function(e, t) {
                    qq.log("Drag & drop error code '" + e + " with these specifics: '" + t + "'", "error")
                },
                dropLog: function(e, t) {
                    qq.log(e, t)
                }
            }
        }, qq.UploadDropZone = function(e) {
            "use strict";

            function t() {
                return qq.safari() || qq.firefox() && qq.windows()
            }

            function n(e) {
                c || (t ? d.attach(document, "dragover", function(e) {
                    e.preventDefault()
                }) : d.attach(document, "dragover", function(e) {
                    e.dataTransfer && (e.dataTransfer.dropEffect = "none", e.preventDefault())
                }), c = !0)
            }

            function i(e) {
                if (!qq.supportedFeatures.fileDrop) return !1;
                var t, n = e.dataTransfer,
                    i = qq.safari();
                return t = !(!qq.ie() || !qq.supportedFeatures.fileDrop) || "none" !== n.effectAllowed, n && t && (n.files || !i && n.types.contains && n.types.contains("Files"))
            }

            function o(e) {
                return void 0 !== e && (u = e), u
            }

            function r() {
                function e() {
                    t = document.createEvent("Event"), t.initEvent(s.HIDE_ZONES_EVENT_NAME, !0, !0)
                }
                var t;
                if (window.CustomEvent) try {
                    t = new CustomEvent(s.HIDE_ZONES_EVENT_NAME)
                } catch (t) {
                    e()
                } else e();
                document.dispatchEvent(t)
            }

            function a() {
                d.attach(l, "dragover", function(e) {
                    if (i(e)) {
                        var t = qq.ie() && qq.supportedFeatures.fileDrop ? null : e.dataTransfer.effectAllowed;
                        "move" === t || "linkMove" === t ? e.dataTransfer.dropEffect = "move" : e.dataTransfer.dropEffect = "copy", e.stopPropagation(), e.preventDefault()
                    }
                }), d.attach(l, "dragenter", function(e) {
                    if (!o()) {
                        if (!i(e)) return;
                        s.onEnter(e)
                    }
                }), d.attach(l, "dragleave", function(e) {
                    if (i(e)) {
                        s.onLeave(e);
                        var t = document.elementFromPoint(e.clientX, e.clientY);
                        qq(this).contains(t) || s.onLeaveNotDescendants(e)
                    }
                }), d.attach(l, "drop", function(e) {
                    if (!o()) {
                        if (!i(e)) return;
                        e.preventDefault(), e.stopPropagation(), s.onDrop(e), r()
                    }
                })
            }
            var s, l, u, c, d = new qq.DisposeSupport;
            s = {
                element: null,
                onEnter: function(e) {},
                onLeave: function(e) {},
                onLeaveNotDescendants: function(e) {},
                onDrop: function(e) {}
            }, qq.extend(s, e), l = s.element, n(), a(), qq.extend(this, {
                dropDisabled: function(e) {
                    return o(e)
                },
                dispose: function() {
                    d.dispose()
                },
                getElement: function() {
                    return l
                }
            })
        },
        function() {
            "use strict";
            qq.uiPublicApi = {
                addInitialFiles: function(e) {
                    this._parent.prototype.addInitialFiles.apply(this, arguments), this._templating.addCacheToDom()
                },
                clearStoredFiles: function() {
                    this._parent.prototype.clearStoredFiles.apply(this, arguments), this._templating.clearFiles()
                },
                addExtraDropzone: function(e) {
                    this._dnd && this._dnd.setupExtraDropzone(e)
                },
                removeExtraDropzone: function(e) {
                    if (this._dnd) return this._dnd.removeDropzone(e)
                },
                getItemByFileId: function(e) {
                    if (!this._templating.isHiddenForever(e)) return this._templating.getFileContainer(e)
                },
                reset: function() {
                    this._parent.prototype.reset.apply(this, arguments), this._templating.reset(), !this._options.button && this._templating.getButton() && (this._defaultButtonId = this._createUploadButton({
                        element: this._templating.getButton(),
                        title: this._options.text.fileInputTitle
                    }).getButtonId()), this._dnd && (this._dnd.dispose(), this._dnd = this._setupDragAndDrop()), this._totalFilesInBatch = 0, this._filesInBatchAddedToUi = 0, this._setupClickAndEditEventHandlers()
                },
                setName: function(e, t) {
                    var n = this._options.formatFileName(t);
                    this._parent.prototype.setName.apply(this, arguments), this._templating.updateFilename(e, n)
                },
                pauseUpload: function(e) {
                    var t = this._parent.prototype.pauseUpload.apply(this, arguments);
                    return t && this._templating.uploadPaused(e), t
                },
                continueUpload: function(e) {
                    var t = this._parent.prototype.continueUpload.apply(this, arguments);
                    return t && this._templating.uploadContinued(e), t
                },
                getId: function(e) {
                    return this._templating.getFileId(e)
                },
                getDropTarget: function(e) {
                    var t = this.getFile(e);
                    return t.qqDropTarget
                }
            }, qq.uiPrivateApi = {
                _getButton: function(e) {
                    var t = this._parent.prototype._getButton.apply(this, arguments);
                    return t || e === this._defaultButtonId && (t = this._templating.getButton()), t
                },
                _removeFileItem: function(e) {
                    this._templating.removeFile(e)
                },
                _setupClickAndEditEventHandlers: function() {
                    this._fileButtonsClickHandler = qq.FileButtonsClickHandler && this._bindFileButtonsClickEvent(), this._focusinEventSupported = !qq.firefox(), this._isEditFilenameEnabled() && (this._filenameClickHandler = this._bindFilenameClickEvent(), this._filenameInputFocusInHandler = this._bindFilenameInputFocusInEvent(), this._filenameInputFocusHandler = this._bindFilenameInputFocusEvent())
                },
                _setupDragAndDrop: function() {
                    var e = this,
                        t = this._options.dragAndDrop.extraDropzones,
                        n = this._templating,
                        i = n.getDropZone();
                    return i && t.push(i), new qq.DragAndDrop({
                        dropZoneElements: t,
                        allowMultipleItems: this._options.multiple,
                        classes: {
                            dropActive: this._options.classes.dropActive
                        },
                        callbacks: {
                            processingDroppedFiles: function() {
                                n.showDropProcessing()
                            },
                            processingDroppedFilesComplete: function(t, i) {
                                n.hideDropProcessing(), qq.each(t, function(e, t) {
                                    t.qqDropTarget = i
                                }), t.length && e.addFiles(t, null, null)
                            },
                            dropError: function(t, n) {
                                e._itemError(t, n)
                            },
                            dropLog: function(t, n) {
                                e.log(t, n)
                            }
                        }
                    })
                },
                _bindFileButtonsClickEvent: function() {
                    var e = this;
                    return new qq.FileButtonsClickHandler({
                        templating: this._templating,
                        log: function(t, n) {
                            e.log(t, n)
                        },
                        onDeleteFile: function(t) {
                            e.deleteFile(t)
                        },
                        onCancel: function(t) {
                            e.cancel(t)
                        },
                        onRetry: function(t) {
                            e.retry(t)
                        },
                        onPause: function(t) {
                            e.pauseUpload(t)
                        },
                        onContinue: function(t) {
                            e.continueUpload(t)
                        },
                        onGetName: function(t) {
                            return e.getName(t)
                        }
                    })
                },
                _isEditFilenameEnabled: function() {
                    return this._templating.isEditFilenamePossible() && !this._options.autoUpload && qq.FilenameClickHandler && qq.FilenameInputFocusHandler && qq.FilenameInputFocusHandler
                },
                _filenameEditHandler: function() {
                    var e = this,
                        t = this._templating;
                    return {
                        templating: t,
                        log: function(t, n) {
                            e.log(t, n)
                        },
                        onGetUploadStatus: function(t) {
                            return e.getUploads({
                                id: t
                            }).status
                        },
                        onGetName: function(t) {
                            return e.getName(t)
                        },
                        onSetName: function(t, n) {
                            e.setName(t, n)
                        },
                        onEditingStatusChange: function(e, n) {
                            var i = qq(t.getEditInput(e)),
                                o = qq(t.getFileContainer(e));
                            n ? (i.addClass("qq-editing"), t.hideFilename(e), t.hideEditIcon(e)) : (i.removeClass("qq-editing"), t.showFilename(e), t.showEditIcon(e)), o.addClass("qq-temp").removeClass("qq-temp")
                        }
                    }
                },
                _onUploadStatusChange: function(e, t, n) {
                    this._parent.prototype._onUploadStatusChange.apply(this, arguments), this._isEditFilenameEnabled() && this._templating.getFileContainer(e) && n !== qq.status.SUBMITTED && (this._templating.markFilenameEditable(e), this._templating.hideEditIcon(e)), n === qq.status.UPLOAD_RETRYING ? (this._templating.hideRetry(e), this._templating.setStatusText(e), qq(this._templating.getFileContainer(e)).removeClass(this._classes.retrying)) : n === qq.status.UPLOAD_FAILED && this._templating.hidePause(e)
                },
                _bindFilenameInputFocusInEvent: function() {
                    var e = qq.extend({}, this._filenameEditHandler());
                    return new qq.FilenameInputFocusInHandler(e)
                },
                _bindFilenameInputFocusEvent: function() {
                    var e = qq.extend({}, this._filenameEditHandler());
                    return new qq.FilenameInputFocusHandler(e)
                },
                _bindFilenameClickEvent: function() {
                    var e = qq.extend({}, this._filenameEditHandler());
                    return new qq.FilenameClickHandler(e)
                },
                _storeForLater: function(e) {
                    this._parent.prototype._storeForLater.apply(this, arguments), this._templating.hideSpinner(e)
                },
                _onAllComplete: function(e, t) {
                    this._parent.prototype._onAllComplete.apply(this, arguments), this._templating.resetTotalProgress()
                },
                _onSubmit: function(e, t) {
                    var n = this.getFile(e);
                    n && n.qqPath && this._options.dragAndDrop.reportDirectoryPaths && this._paramsStore.addReadOnly(e, {
                        qqpath: n.qqPath
                    }), this._parent.prototype._onSubmit.apply(this, arguments), this._addToList(e, t)
                },
                _onSubmitted: function(e) {
                    this._isEditFilenameEnabled() && (this._templating.markFilenameEditable(e), this._templating.showEditIcon(e), this._focusinEventSupported || this._filenameInputFocusHandler.addHandler(this._templating.getEditInput(e)))
                },
                _onProgress: function(e, t, n, i) {
                    this._parent.prototype._onProgress.apply(this, arguments), this._templating.updateProgress(e, n, i), 100 === Math.round(n / i * 100) ? (this._templating.hideCancel(e), this._templating.hidePause(e), this._templating.hideProgress(e), this._templating.setStatusText(e, this._options.text.waitingForResponse), this._displayFileSize(e)) : this._displayFileSize(e, n, i)
                },
                _onTotalProgress: function(e, t) {
                    this._parent.prototype._onTotalProgress.apply(this, arguments), this._templating.updateTotalProgress(e, t)
                },
                _onComplete: function(e, t, n, i) {
                    function o(t) {
                        s && (a.setStatusText(e), qq(s).removeClass(l._classes.retrying), a.hideProgress(e), l.getUploads({
                            id: e
                        }).status !== qq.status.UPLOAD_FAILED && a.hideCancel(e), a.hideSpinner(e), t.success ? l._markFileAsSuccessful(e) : (qq(s).addClass(l._classes.fail), a.showCancel(e), a.isRetryPossible() && !l._preventRetries[e] && (qq(s).addClass(l._classes.retryable), a.showRetry(e)), l._controlFailureTextDisplay(e, t)))
                    }
                    var r = this._parent.prototype._onComplete.apply(this, arguments),
                        a = this._templating,
                        s = a.getFileContainer(e),
                        l = this;
                    return r instanceof qq.Promise ? r.done(function(e) {
                        o(e)
                    }) : o(n), r
                },
                _markFileAsSuccessful: function(e) {
                    var t = this._templating;
                    this._isDeletePossible() && t.showDeleteButton(e), qq(t.getFileContainer(e)).addClass(this._classes.success), this._maybeUpdateThumbnail(e)
                },
                _onUploadPrep: function(e) {
                    this._parent.prototype._onUploadPrep.apply(this, arguments), this._templating.showSpinner(e)
                },
                _onUpload: function(e, t) {
                    var n = this._parent.prototype._onUpload.apply(this, arguments);
                    return this._templating.showSpinner(e), n
                },
                _onUploadChunk: function(e, t) {
                    this._parent.prototype._onUploadChunk.apply(this, arguments), t.partIndex > 0 && this._handler.isResumable(e) && this._templating.allowPause(e)
                },
                _onCancel: function(e, t) {
                    this._parent.prototype._onCancel.apply(this, arguments), this._removeFileItem(e), 0 === this._getNotFinished() && this._templating.resetTotalProgress()
                },
                _onBeforeAutoRetry: function(e) {
                    var t, n, i;
                    this._parent.prototype._onBeforeAutoRetry.apply(this, arguments), this._showCancelLink(e), this._options.retry.showAutoRetryNote && (t = this._autoRetries[e], n = this._options.retry.maxAutoAttempts, i = this._options.retry.autoRetryNote.replace(/\{retryNum\}/g, t), i = i.replace(/\{maxAuto\}/g, n), this._templating.setStatusText(e, i), qq(this._templating.getFileContainer(e)).addClass(this._classes.retrying))
                },
                _onBeforeManualRetry: function(e) {
                    return this._parent.prototype._onBeforeManualRetry.apply(this, arguments) ? (this._templating.resetProgress(e), qq(this._templating.getFileContainer(e)).removeClass(this._classes.fail), this._templating.setStatusText(e), this._templating.showSpinner(e), this._showCancelLink(e), !0) : (qq(this._templating.getFileContainer(e)).addClass(this._classes.retryable), this._templating.showRetry(e), !1)
                },
                _onSubmitDelete: function(e) {
                    var t = qq.bind(this._onSubmitDeleteSuccess, this);
                    this._parent.prototype._onSubmitDelete.call(this, e, t)
                },
                _onSubmitDeleteSuccess: function(e, t, n) {
                    this._options.deleteFile.forceConfirm ? this._showDeleteConfirm.apply(this, arguments) : this._sendDeleteRequest.apply(this, arguments)
                },
                _onDeleteComplete: function(e, t, n) {
                    this._parent.prototype._onDeleteComplete.apply(this, arguments), this._templating.hideSpinner(e), n ? (this._templating.setStatusText(e, this._options.deleteFile.deletingFailedText), this._templating.showDeleteButton(e)) : this._removeFileItem(e)
                },
                _sendDeleteRequest: function(e, t, n) {
                    this._templating.hideDeleteButton(e), this._templating.showSpinner(e), this._templating.setStatusText(e, this._options.deleteFile.deletingStatusText), this._deleteHandler.sendDelete.apply(this, arguments)
                },
                _showDeleteConfirm: function(e, t, n) {
                    var i, o = this.getName(e),
                        r = this._options.deleteFile.confirmMessage.replace(/\{filename\}/g, o),
                        a = (this.getUuid(e), arguments),
                        s = this;
                    i = this._options.showConfirm(r), qq.isGenericPromise(i) ? i.then(function() {
                        s._sendDeleteRequest.apply(s, a)
                    }) : i !== !1 && s._sendDeleteRequest.apply(s, a)
                },
                _addToList: function(e, t, n) {
                    var i, o, r = 0,
                        a = this._handler.isProxied(e) && this._options.scaling.hideScaled;
                    this._options.display.prependFiles && (this._totalFilesInBatch > 1 && this._filesInBatchAddedToUi > 0 && (r = this._filesInBatchAddedToUi - 1), i = {
                        index: r
                    }), n || (this._options.disableCancelForFormUploads && !qq.supportedFeatures.ajaxUploading && this._templating.disableCancel(), this._options.multiple || (o = this.getUploads({
                        id: e
                    }), this._handledProxyGroup = this._handledProxyGroup || o.proxyGroupId, o.proxyGroupId === this._handledProxyGroup && o.proxyGroupId || (this._handler.cancelAll(), this._clearList(), this._handledProxyGroup = null))), n ? (this._templating.addFileToCache(e, this._options.formatFileName(t), i, a), this._templating.updateThumbnail(e, this._thumbnailUrls[e], !0, this._options.thumbnails.customResizer)) : (this._templating.addFile(e, this._options.formatFileName(t), i, a), this._templating.generatePreview(e, this.getFile(e), this._options.thumbnails.customResizer)), this._filesInBatchAddedToUi += 1, (n || this._options.display.fileSizeOnSubmit && qq.supportedFeatures.ajaxUploading) && this._displayFileSize(e)
                },
                _clearList: function() {
                    this._templating.clearFiles(), this.clearStoredFiles()
                },
                _displayFileSize: function(e, t, n) {
                    var i = this.getSize(e),
                        o = this._formatSize(i);
                    i >= 0 && (void 0 !== t && void 0 !== n && (o = this._formatProgress(t, n)), this._templating.updateSize(e, o))
                },
                _formatProgress: function(e, t) {
                    function n(e, t) {
                        i = i.replace(e, t)
                    }
                    var i = this._options.text.formatProgress;
                    return n("{percent}", Math.round(e / t * 100)), n("{total_size}", this._formatSize(t)), i
                },
                _controlFailureTextDisplay: function(e, t) {
                    var n, i, o;
                    n = this._options.failedUploadTextDisplay.mode, i = this._options.failedUploadTextDisplay.responseProperty, "custom" === n ? (o = t[i], o || (o = this._options.text.failUpload), this._templating.setStatusText(e, o), this._options.failedUploadTextDisplay.enableTooltip && this._showTooltip(e, o)) : "default" === n ? this._templating.setStatusText(e, this._options.text.failUpload) : "none" !== n && this.log("failedUploadTextDisplay.mode value of '" + n + "' is not valid", "warn")
                },
                _showTooltip: function(e, t) {
                    this._templating.getFileContainer(e).title = t
                },
                _showCancelLink: function(e) {
                    this._options.disableCancelForFormUploads && !qq.supportedFeatures.ajaxUploading || this._templating.showCancel(e)
                },
                _itemError: function(e, t, n) {
                    var i = this._parent.prototype._itemError.apply(this, arguments);
                    this._options.showMessage(i)
                },
                _batchError: function(e) {
                    this._parent.prototype._batchError.apply(this, arguments), this._options.showMessage(e)
                },
                _setupPastePrompt: function() {
                    var e = this;
                    this._options.callbacks.onPasteReceived = function() {
                        var t = e._options.paste.namePromptMessage,
                            n = e._options.paste.defaultName;
                        return e._options.showPrompt(t, n)
                    }
                },
                _fileOrBlobRejected: function(e, t) {
                    this._totalFilesInBatch -= 1, this._parent.prototype._fileOrBlobRejected.apply(this, arguments)
                },
                _prepareItemsForUpload: function(e, t, n) {
                    this._totalFilesInBatch = e.length, this._filesInBatchAddedToUi = 0, this._parent.prototype._prepareItemsForUpload.apply(this, arguments)
                },
                _maybeUpdateThumbnail: function(e) {
                    var t = this._thumbnailUrls[e],
                        n = this.getUploads({
                            id: e
                        }).status;
                    n === qq.status.DELETED || !t && !this._options.thumbnails.placeholders.waitUntilResponse && qq.supportedFeatures.imagePreviews || this._templating.updateThumbnail(e, t, this._options.thumbnails.customResizer)
                },
                _addCannedFile: function(e) {
                    var t = this._parent.prototype._addCannedFile.apply(this, arguments);
                    return this._addToList(t, this.getName(t), !0), this._templating.hideSpinner(t), this._templating.hideCancel(t), this._markFileAsSuccessful(t), t
                },
                _setSize: function(e, t) {
                    this._parent.prototype._setSize.apply(this, arguments), this._templating.updateSize(e, this._formatSize(t))
                },
                _sessionRequestComplete: function() {
                    this._templating.addCacheToDom(), this._parent.prototype._sessionRequestComplete.apply(this, arguments)
                }
            }
        }(), qq.FineUploader = function(e, t) {
            "use strict";
            var n = this;
            this._parent = t ? qq[t].FineUploaderBasic : qq.FineUploaderBasic, this._parent.apply(this, arguments), qq.extend(this._options, {
                element: null,
                button: null,
                listElement: null,
                dragAndDrop: {
                    extraDropzones: [],
                    reportDirectoryPaths: !1
                },
                text: {
                    formatProgress: "{percent}% of {total_size}",
                    failUpload: "Upload failed",
                    waitingForResponse: "Processing...",
                    paused: "Paused"
                },
                template: "qq-template",
                classes: {
                    retrying: "qq-upload-retrying",
                    retryable: "qq-upload-retryable",
                    success: "qq-upload-success",
                    fail: "qq-upload-fail",
                    editable: "qq-editable",
                    hide: "qq-hide",
                    dropActive: "qq-upload-drop-area-active"
                },
                failedUploadTextDisplay: {
                    mode: "default",
                    responseProperty: "error",
                    enableTooltip: !0
                },
                messages: {
                    tooManyFilesError: "You may only drop one file",
                    unsupportedBrowser: "Unrecoverable error - this browser does not permit file uploading of any kind."
                },
                retry: {
                    showAutoRetryNote: !0,
                    autoRetryNote: "Retrying {retryNum}/{maxAuto}..."
                },
                deleteFile: {
                    forceConfirm: !1,
                    confirmMessage: "Are you sure you want to delete {filename}?",
                    deletingStatusText: "Deleting...",
                    deletingFailedText: "Delete failed"
                },
                display: {
                    fileSizeOnSubmit: !1,
                    prependFiles: !1
                },
                paste: {
                    promptForName: !1,
                    namePromptMessage: "Please name this image"
                },
                thumbnails: {
                    customResizer: null,
                    maxCount: 0,
                    placeholders: {
                        waitUntilResponse: !1,
                        notAvailablePath: null,
                        waitingPath: null
                    },
                    timeBetweenThumbs: 750
                },
                scaling: {
                    hideScaled: !1
                },
                showMessage: function(e) {
                    return n._templating.hasDialog("alert") ? n._templating.showDialog("alert", e) : void setTimeout(function() {
                        window.alert(e)
                    }, 0)
                },
                showConfirm: function(e) {
                    return n._templating.hasDialog("confirm") ? n._templating.showDialog("confirm", e) : window.confirm(e)
                },
                showPrompt: function(e, t) {
                    return n._templating.hasDialog("prompt") ? n._templating.showDialog("prompt", e, t) : window.prompt(e, t)
                }
            }, !0), qq.extend(this._options, e, !0), this._templating = new qq.Templating({
                log: qq.bind(this.log, this),
                templateIdOrEl: this._options.template,
                containerEl: this._options.element,
                fileContainerEl: this._options.listElement,
                button: this._options.button,
                imageGenerator: this._imageGenerator,
                classes: {
                    hide: this._options.classes.hide,
                    editable: this._options.classes.editable
                },
                limits: {
                    maxThumbs: this._options.thumbnails.maxCount,
                    timeBetweenThumbs: this._options.thumbnails.timeBetweenThumbs
                },
                placeholders: {
                    waitUntilUpdate: this._options.thumbnails.placeholders.waitUntilResponse,
                    thumbnailNotAvailable: this._options.thumbnails.placeholders.notAvailablePath,
                    waitingForThumbnail: this._options.thumbnails.placeholders.waitingPath
                },
                text: this._options.text
            }), this._options.workarounds.ios8SafariUploads && qq.ios800() && qq.iosSafari() ? this._templating.renderFailure(this._options.messages.unsupportedBrowserIos8Safari) : !qq.supportedFeatures.uploading || this._options.cors.expected && !qq.supportedFeatures.uploadCors ? this._templating.renderFailure(this._options.messages.unsupportedBrowser) : (this._wrapCallbacks(), this._templating.render(), this._classes = this._options.classes, !this._options.button && this._templating.getButton() && (this._defaultButtonId = this._createUploadButton({
                element: this._templating.getButton(),
                title: this._options.text.fileInputTitle
            }).getButtonId()), this._setupClickAndEditEventHandlers(), qq.DragAndDrop && qq.supportedFeatures.fileDrop && (this._dnd = this._setupDragAndDrop()), this._options.paste.targetElement && this._options.paste.promptForName && (qq.PasteSupport ? this._setupPastePrompt() : this.log("Paste support module not found.", "error")), this._totalFilesInBatch = 0, this._filesInBatchAddedToUi = 0)
        }, qq.extend(qq.FineUploader.prototype, qq.basePublicApi), qq.extend(qq.FineUploader.prototype, qq.basePrivateApi), qq.extend(qq.FineUploader.prototype, qq.uiPublicApi), qq.extend(qq.FineUploader.prototype, qq.uiPrivateApi), qq.Templating = function(e) {
            "use strict";
            var t, n, i, o, r, a, s, l, u = "qq-file-id",
                c = "qq-file-id-",
                d = "qq-max-size",
                p = "qq-server-scale",
                h = "qq-hide-dropzone",
                f = "qq-drop-area-text",
                q = "qq-in-progress",
                m = "qq-hidden-forever",
                g = {
                    content: document.createDocumentFragment(),
                    map: {}
                },
                _ = !1,
                v = 0,
                b = !1,
                y = [],
                S = -1,
                w = {
                    log: null,
                    limits: {
                        maxThumbs: 0,
                        timeBetweenThumbs: 750
                    },
                    templateIdOrEl: "qq-template",
                    containerEl: null,
                    fileContainerEl: null,
                    button: null,
                    imageGenerator: null,
                    classes: {
                        hide: "qq-hide",
                        editable: "qq-editable"
                    },
                    placeholders: {
                        waitUntilUpdate: !1,
                        thumbnailNotAvailable: null,
                        waitingForThumbnail: null
                    },
                    text: {
                        paused: "Paused"
                    }
                },
                F = {
                    button: "qq-upload-button-selector",
                    alertDialog: "qq-alert-dialog-selector",
                    dialogCancelButton: "qq-cancel-button-selector",
                    confirmDialog: "qq-confirm-dialog-selector",
                    dialogMessage: "qq-dialog-message-selector",
                    dialogOkButton: "qq-ok-button-selector",
                    promptDialog: "qq-prompt-dialog-selector",
                    uploader: "qq-uploader-selector",
                    drop: "qq-upload-drop-area-selector",
                    list: "qq-upload-list-selector",
                    progressBarContainer: "qq-progress-bar-container-selector",
                    progressBar: "qq-progress-bar-selector",
                    totalProgressBarContainer: "qq-total-progress-bar-container-selector",
                    totalProgressBar: "qq-total-progress-bar-selector",
                    file: "qq-upload-file-selector",
                    spinner: "qq-upload-spinner-selector",
                    size: "qq-upload-size-selector",
                    cancel: "qq-upload-cancel-selector",
                    pause: "qq-upload-pause-selector",
                    continueButton: "qq-upload-continue-selector",
                    deleteButton: "qq-upload-delete-selector",
                    retry: "qq-upload-retry-selector",
                    statusText: "qq-upload-status-text-selector",
                    editFilenameInput: "qq-edit-filename-selector",
                    editNameIcon: "qq-edit-filename-icon-selector",
                    dropText: "qq-upload-drop-area-text-selector",
                    dropProcessing: "qq-drop-processing-selector",
                    dropProcessingSpinner: "qq-drop-processing-spinner-selector",
                    thumbnail: "qq-thumbnail-selector"
                },
                x = {},
                C = new qq.Promise,
                E = new qq.Promise,
                I = function() {
                    var e = w.placeholders.thumbnailNotAvailable,
                        n = w.placeholders.waitingForThumbnail,
                        i = {
                            maxSize: S,
                            scale: l
                        };
                    s && (e ? w.imageGenerator.generate(e, new Image, i).then(function(e) {
                        C.success(e)
                    }, function() {
                        C.failure(), t("Problem loading 'not available' placeholder image at " + e, "error")
                    }) : C.failure(), n ? w.imageGenerator.generate(n, new Image, i).then(function(e) {
                        E.success(e)
                    }, function() {
                        E.failure(), t("Problem loading 'waiting for thumbnail' placeholder image at " + n, "error")
                    }) : E.failure())
                },
                P = function(e) {
                    var t = new qq.Promise;
                    return E.then(function(n) {
                        Q(n, e), e.src ? t.success() : (e.src = n.src, e.onload = function() {
                            e.onload = null, te(e), t.success()
                        })
                    }, function() {
                        W(e), t.success()
                    }), t
                },
                D = function(e, n, i) {
                    var o = X(e);
                    return t("Generating new thumbnail for " + e), n.qqThumbnailId = e, w.imageGenerator.generate(n, o, i).then(function() {
                        v++, te(o), x[e].success()
                    }, function() {
                        x[e].failure(), w.placeholders.waitUntilUpdate || Y(e, o)
                    })
                },
                T = function() {
                    if (y.length) {
                        b = !0;
                        var e = y.shift();
                        e.update ? $(e) : K(e)
                    } else b = !1
                },
                U = function(e) {
                    return V(L(e), F.cancel)
                },
                k = function(e) {
                    return V(L(e), F.continueButton)
                },
                A = function(e) {
                    return V(r, F[e + "Dialog"])
                },
                R = function(e) {
                    return V(L(e), F.deleteButton)
                },
                B = function() {
                    return V(r, F.dropProcessing)
                },
                N = function(e) {
                    return V(L(e), F.editNameIcon)
                },
                L = function(e) {
                    return g.map[e] || qq(a).getFirstByClass(c + e)
                },
                O = function(e) {
                    return V(L(e), F.file)
                },
                H = function(e) {
                    return V(L(e), F.pause)
                },
                z = function(e) {
                    return null == e ? V(r, F.totalProgressBarContainer) || V(r, F.totalProgressBar) : V(L(e), F.progressBarContainer) || V(L(e), F.progressBar)
                },
                M = function(e) {
                    return V(L(e), F.retry)
                },
                j = function(e) {
                    return V(L(e), F.size)
                },
                G = function(e) {
                    return V(L(e), F.spinner)
                },
                V = function(e, t) {
                    return e && qq(e).getFirstByClass(t)
                },
                X = function(e) {
                    return s && V(L(e), F.thumbnail)
                },
                W = function(e) {
                    e && qq(e).addClass(w.classes.hide)
                },
                Q = function(e, t) {
                    var n = e.style.maxWidth,
                        i = e.style.maxHeight;
                    i && n && !t.style.maxWidth && !t.style.maxHeight && qq(t).css({
                        maxWidth: n,
                        maxHeight: i
                    })
                },
                Y = function(e, t) {
                    var n = x[e] || (new qq.Promise).failure(),
                        i = new qq.Promise;
                    return C.then(function(e) {
                        n.then(function() {
                            i.success()
                        }, function() {
                            Q(e, t), t.onload = function() {
                                t.onload = null, i.success()
                            }, t.src = e.src, te(t)
                        })
                    }), i
                },
                J = function() {
                    var e, o, r, a, u, c, q, m, g, _, v;
                    if (t("Parsing template"), null == w.templateIdOrEl) throw new Error("You MUST specify either a template element or ID!");
                    if (qq.isString(w.templateIdOrEl)) {
                        if (e = document.getElementById(w.templateIdOrEl), null === e) throw new Error(qq.format("Cannot find template script at ID '{}'!", w.templateIdOrEl));
                        o = e.innerHTML
                    } else {
                        if (void 0 === w.templateIdOrEl.innerHTML) throw new Error("You have specified an invalid value for the template option!  It must be an ID or an Element.");
                        o = w.templateIdOrEl.innerHTML
                    }
                    if (o = qq.trimStr(o), a = document.createElement("div"), a.appendChild(qq.toElement(o)), v = qq(a).getFirstByClass(F.uploader), w.button && (c = qq(a).getFirstByClass(F.button), c && qq(c).remove()), qq.DragAndDrop && qq.supportedFeatures.fileDrop || (g = qq(a).getFirstByClass(F.dropProcessing), g && qq(g).remove()), q = qq(a).getFirstByClass(F.drop), q && !qq.DragAndDrop && (t("DnD module unavailable.", "info"), qq(q).remove()), qq.supportedFeatures.fileDrop ? qq(v).hasAttribute(f) && q && (_ = qq(q).getFirstByClass(F.dropText), _ && qq(_).remove()) : (v.removeAttribute(f), q && qq(q).hasAttribute(h) && qq(q).css({
                            display: "none"
                        })), m = qq(a).getFirstByClass(F.thumbnail), s ? m && (S = parseInt(m.getAttribute(d)), S = S > 0 ? S : null, l = qq(m).hasAttribute(p)) : m && qq(m).remove(), s = s && m, n = qq(a).getByClass(F.editFilenameInput).length > 0, i = qq(a).getByClass(F.retry).length > 0, r = qq(a).getFirstByClass(F.list), null == r) throw new Error("Could not find the file list container in the template!");
                    return u = r.innerHTML, r.innerHTML = "", a.getElementsByTagName("DIALOG").length && document.createElement("dialog"), t("Template parsing complete"), {
                        template: qq.trimStr(a.innerHTML),
                        fileTemplate: qq.trimStr(u)
                    }
                },
                Z = function(e, t, n) {
                    var i = n,
                        o = i.firstChild;
                    t > 0 && (o = qq(i).children()[t].nextSibling), i.insertBefore(e, o)
                },
                K = function(e) {
                    var t = e.id,
                        n = e.optFileOrBlob,
                        i = n && n.qqThumbnailId,
                        o = X(t),
                        r = {
                            customResizeFunction: e.customResizeFunction,
                            maxSize: S,
                            orient: !0,
                            scale: !0
                        };
                    qq.supportedFeatures.imagePreviews ? o ? w.limits.maxThumbs && w.limits.maxThumbs <= v ? (Y(t, o), T()) : P(o).done(function() {
                        x[t] = new qq.Promise, x[t].done(function() {
                            setTimeout(T, w.limits.timeBetweenThumbs)
                        }), null != i ? ne(t, i) : D(t, n, r)
                    }) : T() : o && (P(o), T())
                },
                $ = function(e) {
                    var t = e.id,
                        n = e.thumbnailUrl,
                        i = e.showWaitingImg,
                        o = X(t),
                        r = {
                            customResizeFunction: e.customResizeFunction,
                            scale: l,
                            maxSize: S
                        };
                    if (o)
                        if (n) {
                            if (!(w.limits.maxThumbs && w.limits.maxThumbs <= v)) return i && P(o), w.imageGenerator.generate(n, o, r).then(function() {
                                te(o), v++, setTimeout(T, w.limits.timeBetweenThumbs)
                            }, function() {
                                Y(t, o), setTimeout(T, w.limits.timeBetweenThumbs)
                            });
                            Y(t, o), T()
                        } else Y(t, o), T()
                },
                ee = function(e, t) {
                    var n = z(e),
                        i = null == e ? F.totalProgressBar : F.progressBar;
                    n && !qq(n).hasClass(i) && (n = qq(n).getFirstByClass(i)), n && (qq(n).css({
                        width: t + "%"
                    }), n.setAttribute("aria-valuenow", t))
                },
                te = function(e) {
                    e && qq(e).removeClass(w.classes.hide)
                },
                ne = function(e, n) {
                    var i = X(e),
                        o = X(n);
                    t(qq.format("ID {} is the same file as ID {}.  Will use generated thumbnail from ID {} instead.", e, n, n)), x[n].then(function() {
                        v++, x[e].success(), t(qq.format("Now using previously generated thumbnail created for ID {} on ID {}.", n, e)), i.src = o.src, te(i)
                    }, function() {
                        x[e].failure(), w.placeholders.waitUntilUpdate || Y(e, i)
                    })
                };
            qq.extend(w, e), t = w.log, qq.supportedFeatures.imagePreviews || (w.limits.timeBetweenThumbs = 0, w.limits.maxThumbs = 0), r = w.containerEl, s = void 0 !== w.imageGenerator, o = J(), I(), qq.extend(this, {
                render: function() {
                    t("Rendering template in DOM."), v = 0, r.innerHTML = o.template, W(B()), this.hideTotalProgress(), a = w.fileContainerEl || V(r, F.list), t("Template rendering complete")
                },
                renderFailure: function(e) {
                    var t = qq.toElement(e);
                    r.innerHTML = "", r.appendChild(t)
                },
                reset: function() {
                    this.render()
                },
                clearFiles: function() {
                    a.innerHTML = ""
                },
                disableCancel: function() {
                    _ = !0
                },
                addFile: function(e, t, n, i, s) {
                    var l, d = qq.toElement(o.fileTemplate),
                        p = V(d, F.file),
                        h = V(r, F.uploader),
                        q = s ? g.content : a;
                    s && (g.map[e] = d), qq(d).addClass(c + e), h.removeAttribute(f), p && (qq(p).setText(t), p.setAttribute("title", t)), d.setAttribute(u, e), n ? Z(d, n.index, q) : q.appendChild(d), i ? (d.style.display = "none", qq(d).addClass(m)) : (W(z(e)), W(j(e)), W(R(e)), W(M(e)), W(H(e)), W(k(e)), _ && this.hideCancel(e), l = X(e), l && !l.src && E.then(function(e) {
                        l.src = e.src, e.style.maxHeight && e.style.maxWidth && qq(l).css({
                            maxHeight: e.style.maxHeight,
                            maxWidth: e.style.maxWidth
                        }), te(l)
                    }))
                },
                addFileToCache: function(e, t, n, i) {
                    this.addFile(e, t, n, i, !0)
                },
                addCacheToDom: function() {
                    a.appendChild(g.content), g.content = document.createDocumentFragment(), g.map = {}
                },
                removeFile: function(e) {
                    qq(L(e)).remove()
                },
                getFileId: function(e) {
                    var t = e;
                    if (t) {
                        for (; null == t.getAttribute(u);) t = t.parentNode;
                        return parseInt(t.getAttribute(u))
                    }
                },
                getFileList: function() {
                    return a
                },
                markFilenameEditable: function(e) {
                    var t = O(e);
                    t && qq(t).addClass(w.classes.editable)
                },
                updateFilename: function(e, t) {
                    var n = O(e);
                    n && (qq(n).setText(t), n.setAttribute("title", t))
                },
                hideFilename: function(e) {
                    W(O(e))
                },
                showFilename: function(e) {
                    te(O(e))
                },
                isFileName: function(e) {
                    return qq(e).hasClass(F.file)
                },
                getButton: function() {
                    return w.button || V(r, F.button)
                },
                hideDropProcessing: function() {
                    W(B())
                },
                showDropProcessing: function() {
                    te(B())
                },
                getDropZone: function() {
                    return V(r, F.drop)
                },
                isEditFilenamePossible: function() {
                    return n
                },
                hideRetry: function(e) {
                    W(M(e))
                },
                isRetryPossible: function() {
                    return i
                },
                showRetry: function(e) {
                    te(M(e))
                },
                getFileContainer: function(e) {
                    return L(e)
                },
                showEditIcon: function(e) {
                    var t = N(e);
                    t && qq(t).addClass(w.classes.editable)
                },
                isHiddenForever: function(e) {
                    return qq(L(e)).hasClass(m)
                },
                hideEditIcon: function(e) {
                    var t = N(e);
                    t && qq(t).removeClass(w.classes.editable)
                },
                isEditIcon: function(e) {
                    return qq(e).hasClass(F.editNameIcon, !0)
                },
                getEditInput: function(e) {
                    return V(L(e), F.editFilenameInput)
                },
                isEditInput: function(e) {
                    return qq(e).hasClass(F.editFilenameInput, !0)
                },
                updateProgress: function(e, t, n) {
                    var i, o = z(e);
                    o && n > 0 && (i = Math.round(t / n * 100), 100 === i ? W(o) : te(o), ee(e, i))
                },
                updateTotalProgress: function(e, t) {
                    this.updateProgress(null, e, t)
                },
                hideProgress: function(e) {
                    var t = z(e);
                    t && W(t)
                },
                hideTotalProgress: function() {
                    this.hideProgress()
                },
                resetProgress: function(e) {
                    ee(e, 0), this.hideTotalProgress(e)
                },
                resetTotalProgress: function() {
                    this.resetProgress()
                },
                showCancel: function(e) {
                    if (!_) {
                        var t = U(e);
                        t && qq(t).removeClass(w.classes.hide)
                    }
                },
                hideCancel: function(e) {
                    W(U(e))
                },
                isCancel: function(e) {
                    return qq(e).hasClass(F.cancel, !0)
                },
                allowPause: function(e) {
                    te(H(e)), W(k(e))
                },
                uploadPaused: function(e) {
                    this.setStatusText(e, w.text.paused), this.allowContinueButton(e), W(G(e))
                },
                hidePause: function(e) {
                    W(H(e))
                },
                isPause: function(e) {
                    return qq(e).hasClass(F.pause, !0)
                },
                isContinueButton: function(e) {
                    return qq(e).hasClass(F.continueButton, !0)
                },
                allowContinueButton: function(e) {
                    te(k(e)), W(H(e))
                },
                uploadContinued: function(e) {
                    this.setStatusText(e, ""), this.allowPause(e), te(G(e))
                },
                showDeleteButton: function(e) {
                    te(R(e))
                },
                hideDeleteButton: function(e) {
                    W(R(e))
                },
                isDeleteButton: function(e) {
                    return qq(e).hasClass(F.deleteButton, !0)
                },
                isRetry: function(e) {
                    return qq(e).hasClass(F.retry, !0)
                },
                updateSize: function(e, t) {
                    var n = j(e);
                    n && (te(n), qq(n).setText(t))
                },
                setStatusText: function(e, t) {
                    var n = V(L(e), F.statusText);
                    n && (null == t ? qq(n).clearText() : qq(n).setText(t))
                },
                hideSpinner: function(e) {
                    qq(L(e)).removeClass(q), W(G(e))
                },
                showSpinner: function(e) {
                    qq(L(e)).addClass(q), te(G(e))
                },
                generatePreview: function(e, t, n) {
                    this.isHiddenForever(e) || (y.push({
                        id: e,
                        customResizeFunction: n,
                        optFileOrBlob: t
                    }), !b && T())
                },
                updateThumbnail: function(e, t, n, i) {
                    this.isHiddenForever(e) || (y.push({
                        customResizeFunction: i,
                        update: !0,
                        id: e,
                        thumbnailUrl: t,
                        showWaitingImg: n
                    }), !b && T())
                },
                hasDialog: function(e) {
                    return qq.supportedFeatures.dialogElement && !!A(e)
                },
                showDialog: function(e, t, n) {
                    var i = A(e),
                        o = V(i, F.dialogMessage),
                        r = i.getElementsByTagName("INPUT")[0],
                        a = V(i, F.dialogCancelButton),
                        s = V(i, F.dialogOkButton),
                        l = new qq.Promise,
                        u = function() {
                            a.removeEventListener("click", c), s && s.removeEventListener("click", d), l.failure()
                        },
                        c = function() {
                            a.removeEventListener("click", c), i.close()
                        },
                        d = function() {
                            i.removeEventListener("close", u), s.removeEventListener("click", d), i.close(), l.success(r && r.value)
                        };
                    return i.addEventListener("close", u), a.addEventListener("click", c), s && s.addEventListener("click", d), r && (r.value = n), o.textContent = t, i.showModal(), l
                }
            })
        }, qq.UiEventHandler = function(e, t) {
            "use strict";

            function n(e) {
                i.attach(e, o.eventType, function(e) {
                    e = e || window.event;
                    var t = e.target || e.srcElement;
                    o.onHandled(t, e)
                })
            }
            var i = new qq.DisposeSupport,
                o = {
                    eventType: "click",
                    attachTo: null,
                    onHandled: function(e, t) {}
                };
            qq.extend(this, {
                addHandler: function(e) {
                    n(e)
                },
                dispose: function() {
                    i.dispose()
                }
            }), qq.extend(t, {
                getFileIdFromItem: function(e) {
                    return e.qqFileId
                },
                getDisposeSupport: function() {
                    return i
                }
            }), qq.extend(o, e), o.attachTo && n(o.attachTo)
        }, qq.FileButtonsClickHandler = function(e) {
            "use strict";

            function t(e, t) {
                qq.each(o, function(n, o) {
                    var r, a = n.charAt(0).toUpperCase() + n.slice(1);
                    if (i.templating["is" + a](e)) return r = i.templating.getFileId(e), qq.preventDefault(t), i.log(qq.format("Detected valid file button click event on file '{}', ID: {}.", i.onGetName(r), r)), o(r), !1
                })
            }
            var n = {},
                i = {
                    templating: null,
                    log: function(e, t) {},
                    onDeleteFile: function(e) {},
                    onCancel: function(e) {},
                    onRetry: function(e) {},
                    onPause: function(e) {},
                    onContinue: function(e) {},
                    onGetName: function(e) {}
                },
                o = {
                    cancel: function(e) {
                        i.onCancel(e)
                    },
                    retry: function(e) {
                        i.onRetry(e)
                    },
                    deleteButton: function(e) {
                        i.onDeleteFile(e)
                    },
                    pause: function(e) {
                        i.onPause(e)
                    },
                    continueButton: function(e) {
                        i.onContinue(e)
                    }
                };
            qq.extend(i, e), i.eventType = "click", i.onHandled = t, i.attachTo = i.templating.getFileList(), qq.extend(this, new qq.UiEventHandler(i, n))
        }, qq.FilenameClickHandler = function(e) {
            "use strict";

            function t(e, t) {
                if (i.templating.isFileName(e) || i.templating.isEditIcon(e)) {
                    var o = i.templating.getFileId(e),
                        r = i.onGetUploadStatus(o);
                    r === qq.status.SUBMITTED && (i.log(qq.format("Detected valid filename click event on file '{}', ID: {}.", i.onGetName(o), o)), qq.preventDefault(t), n.handleFilenameEdit(o, e, !0))
                }
            }
            var n = {},
                i = {
                    templating: null,
                    log: function(e, t) {},
                    classes: {
                        file: "qq-upload-file",
                        editNameIcon: "qq-edit-filename-icon"
                    },
                    onGetUploadStatus: function(e) {},
                    onGetName: function(e) {}
                };
            qq.extend(i, e), i.eventType = "click", i.onHandled = t, qq.extend(this, new qq.FilenameEditHandler(i, n))
        }, qq.FilenameInputFocusInHandler = function(e, t) {
            "use strict";

            function n(e, n) {
                if (i.templating.isEditInput(e)) {
                    var o = i.templating.getFileId(e),
                        r = i.onGetUploadStatus(o);
                    r === qq.status.SUBMITTED && (i.log(qq.format("Detected valid filename input focus event on file '{}', ID: {}.", i.onGetName(o), o)), t.handleFilenameEdit(o, e))
                }
            }
            var i = {
                templating: null,
                onGetUploadStatus: function(e) {},
                log: function(e, t) {}
            };
            t || (t = {}), i.eventType = "focusin", i.onHandled = n, qq.extend(i, e), qq.extend(this, new qq.FilenameEditHandler(i, t))
        }, qq.FilenameInputFocusHandler = function(e) {
            "use strict";
            e.eventType = "focus", e.attachTo = null, qq.extend(this, new qq.FilenameInputFocusInHandler(e, {}))
        }, qq.FilenameEditHandler = function(e, t) {
            "use strict";

            function n(e) {
                var t = s.onGetName(e),
                    n = t.lastIndexOf(".");
                return n > 0 && (t = t.substr(0, n)), t
            }

            function i(e) {
                var t = s.onGetName(e);
                return qq.getExtension(t)
            }

            function o(e, t) {
                var n, o = e.value;
                void 0 !== o && qq.trimStr(o).length > 0 && (n = i(t), void 0 !== n && (o = o + "." + n), s.onSetName(t, o)), s.onEditingStatusChange(t, !1)
            }

            function r(e, n) {
                t.getDisposeSupport().attach(e, "blur", function() {
                    o(e, n)
                })
            }

            function a(e, n) {
                t.getDisposeSupport().attach(e, "keyup", function(t) {
                    var i = t.keyCode || t.which;
                    13 === i && o(e, n)
                })
            }
            var s = {
                templating: null,
                log: function(e, t) {},
                onGetUploadStatus: function(e) {},
                onGetName: function(e) {},
                onSetName: function(e, t) {},
                onEditingStatusChange: function(e, t) {}
            };
            qq.extend(s, e), s.attachTo = s.templating.getFileList(), qq.extend(this, new qq.UiEventHandler(s, t)), qq.extend(t, {
                handleFilenameEdit: function(e, t, i) {
                    var o = s.templating.getEditInput(e);
                    s.onEditingStatusChange(e, !0), o.value = n(e), i && o.focus(), r(o, e), a(o, e)
                }
            })
        }
}(window);
/* End */
;; /* Start:"a:4:{s:4:"full";s:103:"/local/templates/landing/github/digitalBush/jquery.maskedinput/jquery.maskedinput.min.js?14798133724313";s:6:"source";s:88:"/local/templates/landing/github/digitalBush/jquery.maskedinput/jquery.maskedinput.min.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
/*
 jQuery Masked Input Plugin
 Copyright (c) 2007 - 2015 Josh Bush (digitalbush.com)
 Licensed under the MIT license (http://digitalbush.com/projects/masked-input-plugin/#license)
 Version: 1.4.1
 */
! function(a) {
    "function" == typeof define && define.amd ? define(["jquery"], a) : a("object" == typeof exports ? require("jquery") : jQuery)
}(function(a) {
    var b, c = navigator.userAgent,
        d = /iphone/i.test(c),
        e = /chrome/i.test(c),
        f = /android/i.test(c);
    a.mask = {
        definitions: {
            9: "[0-9]",
            a: "[A-Za-z]",
            "*": "[A-Za-z0-9]"
        },
        autoclear: !0,
        dataName: "rawMaskFn",
        placeholder: "_"
    }, a.fn.extend({
        caret: function(a, b) {
            var c;
            if (0 !== this.length && !this.is(":hidden")) return "number" == typeof a ? (b = "number" == typeof b ? b : a, this.each(function() {
                this.setSelectionRange ? this.setSelectionRange(a, b) : this.createTextRange && (c = this.createTextRange(), c.collapse(!0), c.moveEnd("character", b), c.moveStart("character", a), c.select())
            })) : (this[0].setSelectionRange ? (a = this[0].selectionStart, b = this[0].selectionEnd) : document.selection && document.selection.createRange && (c = document.selection.createRange(), a = 0 - c.duplicate().moveStart("character", -1e5), b = a + c.text.length), {
                begin: a,
                end: b
            })
        },
        unmask: function() {
            return this.trigger("unmask")
        },
        mask: function(c, g) {
            var h, i, j, k, l, m, n, o;
            if (!c && this.length > 0) {
                h = a(this[0]);
                var p = h.data(a.mask.dataName);
                return p ? p() : void 0
            }
            return g = a.extend({
                autoclear: a.mask.autoclear,
                placeholder: a.mask.placeholder,
                completed: null
            }, g), i = a.mask.definitions, j = [], k = n = c.length, l = null, a.each(c.split(""), function(a, b) {
                "?" == b ? (n--, k = a) : i[b] ? (j.push(new RegExp(i[b])), null === l && (l = j.length - 1), k > a && (m = j.length - 1)) : j.push(null)
            }), this.trigger("unmask").each(function() {
                function h() {
                    if (g.completed) {
                        for (var a = l; m >= a; a++)
                            if (j[a] && C[a] === p(a)) return;
                        g.completed.call(B)
                    }
                }

                function p(a) {
                    return g.placeholder.charAt(a < g.placeholder.length ? a : 0)
                }

                function q(a) {
                    for (; ++a < n && !j[a];);
                    return a
                }

                function r(a) {
                    for (; --a >= 0 && !j[a];);
                    return a
                }

                function s(a, b) {
                    var c, d;
                    if (!(0 > a)) {
                        for (c = a, d = q(b); n > c; c++)
                            if (j[c]) {
                                if (!(n > d && j[c].test(C[d]))) break;
                                C[c] = C[d], C[d] = p(d), d = q(d)
                            }
                        z(), B.caret(Math.max(l, a))
                    }
                }

                function t(a) {
                    var b, c, d, e;
                    for (b = a, c = p(a); n > b; b++)
                        if (j[b]) {
                            if (d = q(b), e = C[b], C[b] = c, !(n > d && j[d].test(e))) break;
                            c = e
                        }
                }

                function u() {
                    var a = B.val(),
                        b = B.caret();
                    if (o && o.length && o.length > a.length) {
                        for (A(!0); b.begin > 0 && !j[b.begin - 1];) b.begin--;
                        if (0 === b.begin)
                            for (; b.begin < l && !j[b.begin];) b.begin++;
                        B.caret(b.begin, b.begin)
                    } else {
                        for (A(!0); b.begin < n && !j[b.begin];) b.begin++;
                        B.caret(b.begin, b.begin)
                    }
                    h()
                }

                function v() {
                    A(), B.val() != E && B.change()
                }

                function w(a) {
                    if (!B.prop("readonly")) {
                        var b, c, e, f = a.which || a.keyCode;
                        o = B.val(), 8 === f || 46 === f || d && 127 === f ? (b = B.caret(), c = b.begin, e = b.end, e - c === 0 && (c = 46 !== f ? r(c) : e = q(c - 1), e = 46 === f ? q(e) : e), y(c, e), s(c, e - 1), a.preventDefault()) : 13 === f ? v.call(this, a) : 27 === f && (B.val(E), B.caret(0, A()), a.preventDefault())
                    }
                }

                function x(b) {
                    if (!B.prop("readonly")) {
                        var c, d, e, g = b.which || b.keyCode,
                            i = B.caret();
                        if (!(b.ctrlKey || b.altKey || b.metaKey || 32 > g) && g && 13 !== g) {
                            if (i.end - i.begin !== 0 && (y(i.begin, i.end), s(i.begin, i.end - 1)), c = q(i.begin - 1), n > c && (d = String.fromCharCode(g), j[c].test(d))) {
                                if (t(c), C[c] = d, z(), e = q(c), f) {
                                    var k = function() {
                                        a.proxy(a.fn.caret, B, e)()
                                    };
                                    setTimeout(k, 0)
                                } else B.caret(e);
                                i.begin <= m && h()
                            }
                            b.preventDefault()
                        }
                    }
                }

                function y(a, b) {
                    var c;
                    for (c = a; b > c && n > c; c++) j[c] && (C[c] = p(c))
                }

                function z() {
                    B.val(C.join(""))
                }

                function A(a) {
                    var b, c, d, e = B.val(),
                        f = -1;
                    for (b = 0, d = 0; n > b; b++)
                        if (j[b]) {
                            for (C[b] = p(b); d++ < e.length;)
                                if (c = e.charAt(d - 1), j[b].test(c)) {
                                    C[b] = c, f = b;
                                    break
                                }
                            if (d > e.length) {
                                y(b + 1, n);
                                break
                            }
                        } else C[b] === e.charAt(d) && d++, k > b && (f = b);
                    return a ? z() : k > f + 1 ? g.autoclear || C.join("") === D ? (B.val() && B.val(""), y(0, n)) : z() : (z(), B.val(B.val().substring(0, f + 1))), k ? b : l
                }
                var B = a(this),
                    C = a.map(c.split(""), function(a, b) {
                        return "?" != a ? i[a] ? p(b) : a : void 0
                    }),
                    D = C.join(""),
                    E = B.val();
                B.data(a.mask.dataName, function() {
                    return a.map(C, function(a, b) {
                        return j[b] && a != p(b) ? a : null
                    }).join("")
                }), B.one("unmask", function() {
                    B.off(".mask").removeData(a.mask.dataName)
                }).on("focus.mask", function() {
                    if (!B.prop("readonly")) {
                        clearTimeout(b);
                        var a;
                        E = B.val(), a = A(), b = setTimeout(function() {
                            B.get(0) === document.activeElement && (z(), a == c.replace("?", "").length ? B.caret(0, a) : B.caret(a))
                        }, 10)
                    }
                }).on("blur.mask", v).on("keydown.mask", w).on("keypress.mask", x).on("input.mask paste.mask", function() {
                    B.prop("readonly") || setTimeout(function() {
                        var a = A(!0);
                        B.caret(a), h()
                    }, 0)
                }), e && f && B.off("input.mask").on("input.mask", u), A()
            })
        }
    })
});
/* End */
/* /local/templates/landing/components/zv/iblock.element.add.form.ajaxfile/calculation/script.js?14895007375601*/
/* /local/templates/landing/bower_components/fine-uploader/dist/jquery.fine-uploader.min.js?1479813372143088*/
/* /local/templates/landing/github/digitalBush/jquery.maskedinput/jquery.maskedinput.min.js?14798133724313*/

//# sourceMappingURL=page_71e10cc2900c5e7ffc69ba225dc01392.map.js