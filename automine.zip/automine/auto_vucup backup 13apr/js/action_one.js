
; /* Start:"a:4:{s:4:"full";s:49:"/local/templates/landing/js/app.js?14895007371094";s:6:"source";s:34:"/local/templates/landing/js/app.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
'use strict';
const Application = (()=>{
	let _instance = null,
		_locale = 'ru',
		_template,
		_config,
		_components,
		_formatter = new Intl.NumberFormat(_locale),
		_default = {
			options: {
				template: {}
			}
		};
	class Application {
		constructor(config = {options:{}}) {
			if(_instance){
				return _instance;
			}
			{
				let {
					options: {
						template: template = _default.options.template
					}
				} = config;
				_config = {
					options: {template}
				}
			}
			_template = new Template(_config.options.template);
			_instance = this;
			return _instance;
		}
		get Template () {
			return _template;
		}
		get Locale () {
			return _locale;
		}
		get Config () {
			return _config;
		}
		get Formatter () {
			return _formatter;
		}
		get isTestMode () {
			return typeof getJasmineRequireObj() !== 'undefined';
		}
	}
	return {
		Init(options){
			if(_instance){
				throw new Error('Could be initiated only once');
			}
			return new Application(options);
		},
		getInstance(){
			return new Application();
		}
	}
})();
class Template {
	constructor(options){}
}
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/local/templates/landing/js/lib/controls.js?1489500737310";s:6:"source";s:43:"/local/templates/landing/js/lib/controls.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
// import Zv from 'zv';
class Controller {
	constructor(scope, options){
		this.scope = scope;
		if(typeof this.scope === "string"){
			this.scope = document.querySelector(this.scope);
		}
		if(!this.scope){
			throw new ElementNotFoundError('Scope element not found');
		}
		this.options = options || {};
	}
}
/* End */
;
; /* Start:"a:4:{s:4:"full";s:55:"/local/templates/landing/js/lib/modal.js?14895007371944";s:6:"source";s:40:"/local/templates/landing/js/lib/modal.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
class Modal extends Controller {
	constructor(...args){
		super(...args);
		this.stateActiveClass = (this.options.statesClasses && this.options.statesClasses.active) || 'active';
		this.options.openSelector = this.options.openSelector || '[data-modal]';
		this.closeElement = this.scope.querySelector(this.options.closeSelector);
		this.initEvents();
	}
	get active(){
		return window.location.hash && this.scope.id==window.location.hash.substr(1);
	}
	set active(v){
		window.location.hash = v?this.scope.id:0;
	}
	initEvents(){
		this.scope.addEventListener('click', (e)=>{
			if(e.target==this.scope){
				this.active = false;
			}
		});
		this.closeElement.addEventListener('click',(e)=>{
			this.active = false;
			e.preventDefault();
		});
	}
}
class Modals extends Controller {
	constructor(...args){
		super(...args);
		this.items = []; //TODO: Учесть возможность динамического добавления окна!!
		this
			.initElements()
			.initEvents();
		this.hasActive;
	}
	initElements(){
		// let itemsNl = this.scope.querySelectorAll(this.options.itemSelector);
		this.scope.querySelectorAll(this.options.itemSelector).forEach((node)=>this.pushItem(node));
		return this;
	}
	initEvents() {
		window.addEventListener('hashchange', ()=> document.body.classList.toggle(this.options.bodyModalStateClass, this.hasActive) );
		return this;
	}
	get hasActive(){
		return this.items.filter((item)=>item.active).length;
	}
	pushItem(node){
		let itemOptions = {
			// itemSelector: this.options.itemSelector,
			stateActiveClass: this.options.itemActiveClass,
			openSelector: this.options.itemOpenSelector,
			closeSelector: this.options.itemCloseSelector
		};
		this.items.push(new Modal(node, itemOptions, this));
	}
	getById (id){
		return this.items.filter((item)=>{
			return item.scope.id == id;
		});
	}
	add(id){
		let node = this.scope.querySelector(id);
		if(node){
			this.pushItem(node);
		}
	}
}
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/local/templates/landing/js/lib/datalist.js?1489500737775";s:6:"source";s:43:"/local/templates/landing/js/lib/datalist.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
class DatalistElement {
	constructor(input){
		this.isSupported = typeof HTMLDataListElement != 'undefined';
		this.items = new Set();
		if(this.isSupported){
			this.element = document.createElement('datalist');
		}else{
			this.element = document.createElement('ul');
			this.element.classList.add('datalist');
		}
		this.element.id = input.getAttribute('list');
	}
	refresh(array){
		this.clear();
		this.items = new Set(array);
		this.items.forEach((title)=>this.append(title));
		return this;
	}
	append(title){
		let item = document.createElement(this.isSupported ?'option':'li');
		item.innerHTML = title;
		this.items.add(title);
		this.element.appendChild(item);
		return this;
	}
	clear(){
		// this.items.clear();
		this.element.innerHTML = '';
		return this;
	}
}
/* End */
;
; /* Start:"a:4:{s:4:"full";s:58:"/local/templates/landing/js/lib/component.js?1489500737849";s:6:"source";s:44:"/local/templates/landing/js/lib/component.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
// import $ from 'jquery';
// import {NotDefinedMethodError} from './utils';

class Component extends Controller{
	constructor(scope, componentSettings){
		super(scope);
		if(componentSettings instanceof ComponentSettings){
			this._settings = componentSettings;
		}
	}
	get settings() { return this._settings; }
}
class ComponentSettings {
	constructor(data){
		this._messages = data.messages ? data.messages : {};
		this._ajaxUrl = data.ajaxUrl ? data.ajaxUrl : '';
		this._componentAjaxUrl = data.componentAjaxUrl ? data.componentAjaxUrl : '';
		this._templatePath = data.templatePath ? data.templatePath : '';
	}
	getMessage(key) {
		return this._messages[key] ? this._messages[key] : '';
	}
	get ajaxUrl() { return this._ajaxUrl; }
	get componentAjaxUrl() { return this._componentAjaxUrl; }
	get templatePath() { return this._templatePath; }
}

/* End */
;; /* /local/templates/landing/js/app.js?14895007371094*/
; /* /local/templates/landing/js/lib/controls.js?1489500737310*/
; /* /local/templates/landing/js/lib/modal.js?14895007371944*/
; /* /local/templates/landing/js/lib/datalist.js?1489500737775*/
; /* /local/templates/landing/js/lib/component.js?1489500737849*/
